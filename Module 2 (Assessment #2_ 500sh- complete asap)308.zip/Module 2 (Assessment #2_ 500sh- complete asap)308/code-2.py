import csv
import random

# Define sample product IDs and review text for Student 3
product_ids = [f'S3P{i:03}' for i in range(1, 21)]  # Create 20 product IDs: S3P001, S3P002, ..., S3P020
ratings = [1, 2, 3, 4, 5]  # Rating from 1 (worst) to 5 (best)
reviews = [
    "Amazing quality!", "I wouldn't recommend this.", "Very satisfied.", 
    "Horrible experience.", "Will buy again.", "Extremely disappointing.", 
    "Loved every bit!", "Not worth it at all.", "Definitely recommend!", 
    "Very unhappy with the purchase.", "Exceptional quality!", "Product was faulty.", 
    "Works as described.", "Terrible quality.", "Great performance!", 
    "Would not buy again.", "Fantastic experience!", "Poorly made.", 
    "Just what I needed.", "Bad customer support."
]

# Generate mock data for 20 reviews for Student 3
data = []
for i in range(20):
    product_id = random.choice(product_ids)
    rating = random.choice(ratings)
    review = random.choice(reviews)
    data.append([product_id, rating, review])

# Export the data to a CSV file for Student 3
with open('spark_data.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["Product ID", "Rating", "Review Text"])  # Write headers
    writer.writerows(data)

print("Data exported to spark_data.csv")
