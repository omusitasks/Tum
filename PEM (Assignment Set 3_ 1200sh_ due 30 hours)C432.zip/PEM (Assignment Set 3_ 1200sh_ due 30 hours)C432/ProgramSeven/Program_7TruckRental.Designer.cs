namespace Program_7
{
    partial class Program_7TruckRental
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.numBeginOdometer = new System.Windows.Forms.NumericUpDown();
            this.numEndOdometer = new System.Windows.Forms.NumericUpDown();
            this.numDaysRented = new System.Windows.Forms.NumericUpDown();
            this.btnCreateRental = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblRentalCharge = new System.Windows.Forms.Label();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.lblBeginOdometer = new System.Windows.Forms.Label();
            this.lblEndOdometer = new System.Windows.Forms.Label();
            this.lblDaysRented = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numBeginOdometer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numEndOdometer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDaysRented)).BeginInit();
            this.SuspendLayout();

            // Customer Name Label
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Location = new System.Drawing.Point(30, 30);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(115, 20);
            this.lblCustomerName.Text = "Customer Name:";

            // Customer Name TextBox
            this.txtCustomerName.Location = new System.Drawing.Point(150, 30);
            this.txtCustomerName.Size = new System.Drawing.Size(150, 27);

            // Begin Odometer Label
            this.lblBeginOdometer.AutoSize = true;
            this.lblBeginOdometer.Location = new System.Drawing.Point(30, 80);
            this.lblBeginOdometer.Name = "lblBeginOdometer";
            this.lblBeginOdometer.Size = new System.Drawing.Size(155, 20);
            this.lblBeginOdometer.Text = "Beginning Odometer:";

            // Begin Odometer NumericUpDown
            this.numBeginOdometer.Location = new System.Drawing.Point(190, 80);
            this.numBeginOdometer.Maximum = 1000000;
            this.numBeginOdometer.Size = new System.Drawing.Size(150, 27);

            // End Odometer Label
            this.lblEndOdometer.AutoSize = true;
            this.lblEndOdometer.Location = new System.Drawing.Point(30, 130);
            this.lblEndOdometer.Name = "lblEndOdometer";
            this.lblEndOdometer.Size = new System.Drawing.Size(136, 20);
            this.lblEndOdometer.Text = "Ending Odometer:";

            // End Odometer NumericUpDown
            this.numEndOdometer.Location = new System.Drawing.Point(190, 130);
            this.numEndOdometer.Maximum = 1000000;
            this.numEndOdometer.Size = new System.Drawing.Size(150, 27);

            // Days Rented Label
            this.lblDaysRented.AutoSize = true;
            this.lblDaysRented.Location = new System.Drawing.Point(30, 180);
            this.lblDaysRented.Name = "lblDaysRented";
            this.lblDaysRented.Size = new System.Drawing.Size(101, 20);
            this.lblDaysRented.Text = "Days Rented:";

            // Days Rented NumericUpDown
            this.numDaysRented.Location = new System.Drawing.Point(150, 180);
            this.numDaysRented.Maximum = 365;
            this.numDaysRented.Size = new System.Drawing.Size(150, 27);

            // Create Truck Rental Button
            this.btnCreateRental.Location = new System.Drawing.Point(30, 240);
            this.btnCreateRental.Name = "btnCreateRental";
            this.btnCreateRental.Size = new System.Drawing.Size(100, 40);
            this.btnCreateRental.Text = "Create Rental";
            this.btnCreateRental.UseVisualStyleBackColor = true;
            this.btnCreateRental.Click += new System.EventHandler(this.btnCreateRental_Click);

            // Clear Button
            this.btnClear.Location = new System.Drawing.Point(150, 240);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(100, 40);
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);

            // Exit Button
            this.btnExit.Location = new System.Drawing.Point(270, 240);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(100, 40);
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);

            // Rental Charge Label
            this.lblRentalCharge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRentalCharge.Location = new System.Drawing.Point(30, 300);
            this.lblRentalCharge.Name = "lblRentalCharge";
            this.lblRentalCharge.Size = new System.Drawing.Size(340, 40);
            this.lblRentalCharge.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // Form Settings
            this.ClientSize = new System.Drawing.Size(400, 400);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.numBeginOdometer);
            this.Controls.Add(this.numEndOdometer);
            this.Controls.Add(this.numDaysRented);
            this.Controls.Add(this.btnCreateRental);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblRentalCharge);
            this.Controls.Add(this.lblCustomerName);
            this.Controls.Add(this.lblBeginOdometer);
            this.Controls.Add(this.lblEndOdometer);
            this.Controls.Add(this.lblDaysRented);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.NumericUpDown numBeginOdometer;
        private System.Windows.Forms.NumericUpDown numEndOdometer;
        private System.Windows.Forms.NumericUpDown numDaysRented;
        private System.Windows.Forms.Button btnCreateRental;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblRentalCharge;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.Label lblBeginOdometer;
        private System.Windows.Forms.Label lblEndOdometer;
        private System.Windows.Forms.Label lblDaysRented;

        #endregion
    }
}
