/*
 * Project:         Program 7
 * Date Created:    September 2024
 * Last Modified:   September 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      TruckRental
 * Description:     Form class for rental charge calculation. .
 */

using System;
using System.Windows.Forms;

namespace Program_7
{
    public partial class Program_7TruckRental : Form
    {
        public Program_7TruckRental()
        {
            InitializeComponent();
        }

        private void btnCreateRental_Click(object sender, EventArgs e)
        {
            // Retrieve user inputs
            string customerName = txtCustomerName.Text;
            int beginOdometer = (int)numBeginOdometer.Value;
            int endOdometer = (int)numEndOdometer.Value;
            int daysRented = (int)numDaysRented.Value;

            // Create TruckRental object
            TruckRental rental = new TruckRental(customerName, endOdometer, beginOdometer, daysRented);

            // Display the rental charge
            lblRentalCharge.Text = $"Rental Charge: {rental.RentalCharge:C}";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Reset all inputs and the output label
            txtCustomerName.Clear();
            numBeginOdometer.Value = 0;
            numEndOdometer.Value = 0;
            numDaysRented.Value = 0;
            lblRentalCharge.Text = string.Empty;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Exit the application
            Application.Exit();
        }
    }
}

