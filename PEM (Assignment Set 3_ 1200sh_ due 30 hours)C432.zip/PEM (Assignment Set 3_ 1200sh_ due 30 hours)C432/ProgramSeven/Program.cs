using System;
using System.Windows.Forms;

namespace Program_7
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Program_7TruckRental()); // The main form is launched here.
        }
    }
}
