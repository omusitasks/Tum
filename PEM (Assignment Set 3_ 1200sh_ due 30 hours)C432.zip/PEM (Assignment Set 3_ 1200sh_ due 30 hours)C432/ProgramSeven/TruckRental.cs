/*
 * Project:         Program 7
 * Date Created:    September 2024
 * Last Modified:   September 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      TruckRental
 * Description:     Class to manage truck rental details, including customer name, odometer readings, 
 *                  rental duration, and rental charge calculation. Provides properties to store user 
 *                  input and a method to compute the total rental cost.
 */


using System;

namespace Program_7
{
    public class TruckRental
    {
        // Private fields
        private int beginOdometerReading;
        private int endOdometerReading;
        private int daysRented;

        // Properties
        public string CustomerName { get; set; }

        public decimal RentalCharge { get; private set; } // Rental charge is calculated internally, hence private setter

        public int BeginOdometerReading
        {
            get { return beginOdometerReading; }
            set
            {
                beginOdometerReading = value;
                CalculateRentalCharge(); // Recalculate rental charge whenever this property is set
            }
        }

        public int EndOdometerReading
        {
            get { return endOdometerReading; }
            set
            {
                endOdometerReading = value;
                CalculateRentalCharge(); // Recalculate rental charge whenever this property is set
            }
        }

        public int DaysRented
        {
            get { return daysRented; }
            set
            {
                daysRented = value;
                CalculateRentalCharge(); // Recalculate rental charge whenever this property is set
            }
        }

        // Default constructor
        public TruckRental()
        {
        }

        // Overloaded constructor
        public TruckRental(string customerName, int endMiles, int beginMiles, int numDays)
        {
            CustomerName = customerName;
            EndOdometerReading = endMiles;
            BeginOdometerReading = beginMiles;
            DaysRented = numDays;
        }

        // Private method to calculate the rental charge
        private void CalculateRentalCharge()
        {
            const decimal ratePerDay = 63.90m;
            const decimal ratePerMile = 0.81m;

            // Calculate number of miles driven
            int milesDriven = EndOdometerReading - BeginOdometerReading;

            // Calculate rental charge based on days rented and miles driven
            RentalCharge = (ratePerDay * DaysRented) + (ratePerMile * milesDriven);
        }
    }
}
