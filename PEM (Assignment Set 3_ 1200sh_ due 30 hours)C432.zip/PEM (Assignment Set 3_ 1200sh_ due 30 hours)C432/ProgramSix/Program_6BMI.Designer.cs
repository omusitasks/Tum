namespace Program_6
{
    partial class Program_6BMI
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblUserName = new System.Windows.Forms.Label();
            this.lblUserWeight = new System.Windows.Forms.Label();
            this.lblUserHeight = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.numUserWeight = new System.Windows.Forms.NumericUpDown();
            this.numUserHeight = new System.Windows.Forms.NumericUpDown();
            this.btnCreateBMI = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblBMIResult = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numUserWeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUserHeight)).BeginInit();
            this.SuspendLayout();
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Location = new System.Drawing.Point(30, 30);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(87, 20);
            this.lblUserName.TabIndex = 0;
            this.lblUserName.Text = "User Name:";
            // 
            // lblUserWeight
            // 
            this.lblUserWeight.AutoSize = true;
            this.lblUserWeight.Location = new System.Drawing.Point(30, 80);
            this.lblUserWeight.Name = "lblUserWeight";
            this.lblUserWeight.Size = new System.Drawing.Size(96, 20);
            this.lblUserWeight.TabIndex = 1;
            this.lblUserWeight.Text = "Weight (lbs):";
            // 
            // lblUserHeight
            // 
            this.lblUserHeight.AutoSize = true;
            this.lblUserHeight.Location = new System.Drawing.Point(30, 130);
            this.lblUserHeight.Name = "lblUserHeight";
            this.lblUserHeight.Size = new System.Drawing.Size(92, 20);
            this.lblUserHeight.TabIndex = 2;
            this.lblUserHeight.Text = "Height (in):";
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(160, 28);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(150, 27);
            this.txtUserName.TabIndex = 3;
            // 
            // numUserWeight
            // 
            this.numUserWeight.Location = new System.Drawing.Point(160, 78);
            this.numUserWeight.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            this.numUserWeight.Name = "numUserWeight";
            this.numUserWeight.Size = new System.Drawing.Size(150, 27);
            this.numUserWeight.TabIndex = 4;
            // 
            // numUserHeight
            // 
            this.numUserHeight.Location = new System.Drawing.Point(160, 128);
            this.numUserHeight.Maximum = new decimal(new int[] { 100, 0, 0, 0 });
            this.numUserHeight.Name = "numUserHeight";
            this.numUserHeight.Size = new System.Drawing.Size(150, 27);
            this.numUserHeight.TabIndex = 5;
            // 
            // btnCreateBMI
            // 
            this.btnCreateBMI.Location = new System.Drawing.Point(30, 180);
            this.btnCreateBMI.Name = "btnCreateBMI";
            this.btnCreateBMI.Size = new System.Drawing.Size(100, 40);
            this.btnCreateBMI.TabIndex = 6;
            this.btnCreateBMI.Text = "Create BMI";
            this.btnCreateBMI.UseVisualStyleBackColor = true;
            this.btnCreateBMI.Click += new System.EventHandler(this.btnCreateBMI_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(150, 180);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(100, 40);
            this.btnClear.TabIndex = 7;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(270, 180);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(100, 40);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblBMIResult
            // 
            this.lblBMIResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBMIResult.Location = new System.Drawing.Point(30, 240);
            this.lblBMIResult.Name = "lblBMIResult";
            this.lblBMIResult.Size = new System.Drawing.Size(340, 40);
            this.lblBMIResult.TabIndex = 9;
            this.lblBMIResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Program_6BMI
            // 
            this.ClientSize = new System.Drawing.Size(400, 300);
            this.Controls.Add(this.lblBMIResult);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCreateBMI);
            this.Controls.Add(this.numUserHeight);
            this.Controls.Add(this.numUserWeight);
            this.Controls.Add(this.txtUserName);
            this.Controls.Add(this.lblUserHeight);
            this.Controls.Add(this.lblUserWeight);
            this.Controls.Add(this.lblUserName);
            this.Name = "Program_6BMI";
            this.Text = "BMI Calculator";
            ((System.ComponentModel.ISupportInitialize)(this.numUserWeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUserHeight)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Label lblUserWeight;
        private System.Windows.Forms.Label lblUserHeight;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.NumericUpDown numUserWeight;
        private System.Windows.Forms.NumericUpDown numUserHeight;
        private System.Windows.Forms.Button btnCreateBMI;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblBMIResult;
    }
}
