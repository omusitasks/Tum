/*
 * Project:         Program 6
 * Date Created:    September 2024
 * Last Modified:   September 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      BMI
 * Description:     Class for BMI calculation with properties for user details and method to calculate BMI.
 */

namespace Program_6
{
    /// <summary>
    /// Class to calculate BMI for a user.
    /// </summary>
    public class BMI
    {
        // Private fields
        private string userName;
        private int userWeight; // in pounds
        private int userHeight; // in inches

        /// <summary>
        /// Public property for the user name.
        /// </summary>
        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }

        /// <summary>
        /// Public property for the user weight (in pounds).
        /// </summary>
        public int UserWeight
        {
            get { return userWeight; }
            set { userWeight = value; }
        }

        /// <summary>
        /// Public property for the user height (in inches).
        /// </summary>
        public int UserHeight
        {
            get { return userHeight; }
            set { userHeight = value; }
        }

        /// <summary>
        /// Constructor to initialize user properties.
        /// </summary>
        /// <param name="name">User name</param>
        /// <param name="weight">User weight in pounds</param>
        /// <param name="height">User height in inches</param>
        public BMI(string name, int weight, int height)
        {
            UserName = name;
            UserWeight = weight;
            UserHeight = height;
        }

        /// <summary>
        /// Method to calculate the BMI.
        /// </summary>
        /// <returns>The calculated BMI</returns>
        public double CalculateBMI()
        {
            return (UserWeight * 703) / (double)(UserHeight * UserHeight);
        }
    }
}
