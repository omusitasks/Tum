/*
 * Project:         Program 6
 * Date Created:    September 2024
 * Last Modified:   September 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      Program_6BMI
 * Description:     Form class for BMI calculation.
 */

using System;
using System.Windows.Forms;

namespace Program_6
{
    public partial class Program_6BMI : Form
    {
        public Program_6BMI()
        {
            InitializeComponent();
        }

        private void btnCreateBMI_Click(object sender, EventArgs e)
        {
            // Read user input
            string userName = txtUserName.Text;
            int userWeight = (int)numUserWeight.Value;
            int userHeight = (int)numUserHeight.Value;

            // Instantiate BMI object and calculate BMI
            BMI userBMI = new BMI(userName, userWeight, userHeight);
            double calculatedBMI = userBMI.CalculateBMI();

            // Display the BMI result formatted
            lblBMIResult.Text = $"BMI: {calculatedBMI:F2}";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Reset all input fields and result label
            txtUserName.Text = string.Empty;
            numUserWeight.Value = 0;
            numUserHeight.Value = 0;
            lblBMIResult.Text = string.Empty;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Exit the application
            Application.Exit();
        }
    }
}
