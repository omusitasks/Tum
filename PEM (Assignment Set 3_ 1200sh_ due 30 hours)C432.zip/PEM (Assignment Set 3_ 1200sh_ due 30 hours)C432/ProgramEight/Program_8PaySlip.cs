/*
 * Project:         Program 8
 * Date Created:    September 2024
 * Last Modified:   September 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      Program_8PaySlip
 * Description:     Form class for employee pay slip management.
 */

using System;
using System.Windows.Forms;

namespace Program_8
{
    public partial class Program_8PaySlip : Form
    {
        public Program_8PaySlip()
        {
            InitializeComponent();
        }

        private void btnCreatePaySlip_Click(object sender, EventArgs e)
        {
            // Get input values
            string employeeName = txtEmployeeName.Text;
            decimal hoursWorked = numHoursWorked.Value;
            decimal payRate = numPayRate.Value;

            // Create a new PaySlip object
            PaySlip newPaySlip = new PaySlip(employeeName, hoursWorked, payRate);

            // Display the net pay
            lblNetPay.Text = $"Net Pay: {newPaySlip.NetPay:C}";
        }

        private void btnDisplaySummary_Click(object sender, EventArgs e)
        {
            // Display total number of pay slips, total gross pay, total net pay, and average net pay
            lblSummary.Text = $"Total Pay Slips: {PaySlip.TotalPaySlips}\n" +
                              $"Total Gross Pay: {PaySlip.TotalGrossPay:C}\n" +
                              $"Total Net Pay: {PaySlip.TotalNetPay:C}\n" +
                              $"Average Net Pay: {PaySlip.CalculateAverageNetPay():C}";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Clear input fields and labels
            txtEmployeeName.Clear();
            numHoursWorked.Value = 0;
            numPayRate.Value = 0;
            lblNetPay.Text = string.Empty;
            lblSummary.Text = string.Empty;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Exit the application
            Application.Exit();
        }
    }
}
