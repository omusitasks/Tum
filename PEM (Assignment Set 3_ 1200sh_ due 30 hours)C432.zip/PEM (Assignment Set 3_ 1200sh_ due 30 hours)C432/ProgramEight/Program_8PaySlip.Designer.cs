namespace Program_8
{
    partial class Program_8PaySlip
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.txtEmployeeName = new System.Windows.Forms.TextBox();
            this.numHoursWorked = new System.Windows.Forms.NumericUpDown();
            this.numPayRate = new System.Windows.Forms.NumericUpDown();
            this.btnCreatePaySlip = new System.Windows.Forms.Button();
            this.btnDisplaySummary = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblNetPay = new System.Windows.Forms.Label();
            this.lblSummary = new System.Windows.Forms.Label();

            // Adding labels for each input control
            this.lblEmployeeName = new System.Windows.Forms.Label();
            this.lblHoursWorked = new System.Windows.Forms.Label();
            this.lblPayRate = new System.Windows.Forms.Label();

            ((System.ComponentModel.ISupportInitialize)(this.numHoursWorked)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPayRate)).BeginInit();
            this.SuspendLayout();

            // 
            // lblEmployeeName
            // 
            this.lblEmployeeName.AutoSize = true;
            this.lblEmployeeName.Location = new System.Drawing.Point(30, 10);
            this.lblEmployeeName.Name = "lblEmployeeName";
            this.lblEmployeeName.Size = new System.Drawing.Size(113, 20);
            this.lblEmployeeName.TabIndex = 9;
            this.lblEmployeeName.Text = "Employee Name";
            // 
            // txtEmployeeName
            // 
            this.txtEmployeeName.Location = new System.Drawing.Point(30, 30);
            this.txtEmployeeName.Name = "txtEmployeeName";
            this.txtEmployeeName.Size = new System.Drawing.Size(200, 27);
            this.txtEmployeeName.TabIndex = 0;
            // 
            // lblHoursWorked
            // 
            this.lblHoursWorked.AutoSize = true;
            this.lblHoursWorked.Location = new System.Drawing.Point(30, 50);
            this.lblHoursWorked.Name = "lblHoursWorked";
            this.lblHoursWorked.Size = new System.Drawing.Size(103, 20);
            this.lblHoursWorked.TabIndex = 10;
            this.lblHoursWorked.Text = "Hours Worked";
            // 
            // numHoursWorked
            // 
            this.numHoursWorked.Location = new System.Drawing.Point(30, 70);
            this.numHoursWorked.Maximum = new decimal(new int[] { 200, 0, 0, 0 });
            this.numHoursWorked.Name = "numHoursWorked";
            this.numHoursWorked.Size = new System.Drawing.Size(120, 27);
            this.numHoursWorked.TabIndex = 1;
            // 
            // lblPayRate
            // 
            this.lblPayRate.AutoSize = true;
            this.lblPayRate.Location = new System.Drawing.Point(30, 90);
            this.lblPayRate.Name = "lblPayRate";
            this.lblPayRate.Size = new System.Drawing.Size(66, 20);
            this.lblPayRate.TabIndex = 11;
            this.lblPayRate.Text = "Pay Rate";
            // 
            // numPayRate
            // 
            this.numPayRate.DecimalPlaces = 2;
            this.numPayRate.Location = new System.Drawing.Point(30, 110);
            this.numPayRate.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            this.numPayRate.Name = "numPayRate";
            this.numPayRate.Size = new System.Drawing.Size(120, 27);
            this.numPayRate.TabIndex = 2;
            // 
            // btnCreatePaySlip
            // 
            this.btnCreatePaySlip.Location = new System.Drawing.Point(30, 150);
            this.btnCreatePaySlip.Name = "btnCreatePaySlip";
            this.btnCreatePaySlip.Size = new System.Drawing.Size(150, 40);
            this.btnCreatePaySlip.TabIndex = 3;
            this.btnCreatePaySlip.Text = "Create Pay Slip";
            this.btnCreatePaySlip.UseVisualStyleBackColor = true;
            this.btnCreatePaySlip.Click += new System.EventHandler(this.btnCreatePaySlip_Click);
            // 
            // btnDisplaySummary
            // 
            this.btnDisplaySummary.Location = new System.Drawing.Point(200, 150);
            this.btnDisplaySummary.Name = "btnDisplaySummary";
            this.btnDisplaySummary.Size = new System.Drawing.Size(150, 40);
            this.btnDisplaySummary.TabIndex = 4;
            this.btnDisplaySummary.Text = "Display Summary";
            this.btnDisplaySummary.UseVisualStyleBackColor = true;
            this.btnDisplaySummary.Click += new System.EventHandler(this.btnDisplaySummary_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(30, 200);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(150, 40);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(200, 200);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(150, 40);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblNetPay
            // 
            this.lblNetPay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNetPay.Location = new System.Drawing.Point(30, 250);
            this.lblNetPay.Name = "lblNetPay";
            this.lblNetPay.Size = new System.Drawing.Size(320, 40);
            this.lblNetPay.TabIndex = 7;
            this.lblNetPay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSummary
            // 
            this.lblSummary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSummary.Location = new System.Drawing.Point(30, 300);
            this.lblSummary.Name = "lblSummary";
            this.lblSummary.Size = new System.Drawing.Size(320, 100);
            this.lblSummary.TabIndex = 8;
            this.lblSummary.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Program_8Form
            // 
            this.ClientSize = new System.Drawing.Size(400, 450);
            this.Controls.Add(this.lblSummary);
            this.Controls.Add(this.lblNetPay);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnDisplaySummary);
            this.Controls.Add(this.btnCreatePaySlip);
            this.Controls.Add(this.numPayRate);
            this.Controls.Add(this.lblPayRate);
            this.Controls.Add(this.numHoursWorked);
            this.Controls.Add(this.lblHoursWorked);
            this.Controls.Add(this.txtEmployeeName);
            this.Controls.Add(this.lblEmployeeName);
            this.Name = "Program_8Form";
            this.Text = "Pay Slip Manager";
            ((System.ComponentModel.ISupportInitialize)(this.numHoursWorked)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPayRate)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.TextBox txtEmployeeName;
        private System.Windows.Forms.NumericUpDown numHoursWorked;
        private System.Windows.Forms.NumericUpDown numPayRate;
        private System.Windows.Forms.Button btnCreatePaySlip;
        private System.Windows.Forms.Button btnDisplaySummary;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblNetPay;
        private System.Windows.Forms.Label lblSummary;

        // New labels added for better form clarity
        private System.Windows.Forms.Label lblEmployeeName;
        private System.Windows.Forms.Label lblHoursWorked;
        private System.Windows.Forms.Label lblPayRate;

        #endregion
    }
}
