/*
 * Project:         Program 8
 * Date Created:    September 2024
 * Last Modified:   September 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      PaySlip
 * Description:     Class to calculate employee pay slips with static methods to track totals and averages.
 */

using System;

namespace Program_8
{
    public class PaySlip
    {
        // Instance properties (read-only)
        public string EmployeeName { get; }
        public decimal HoursWorked { get; }
        public decimal PayRate { get; }
        public decimal NetPay { get; private set; }

        // Static properties (auto-implemented)
        public static decimal TotalGrossPay { get; private set; }
        public static decimal TotalNetPay { get; private set; }
        public static int TotalPaySlips { get; private set; }

        // Constructor
        public PaySlip(string employeeName, decimal hoursWorked, decimal payRate)
        {
            EmployeeName = employeeName;
            HoursWorked = hoursWorked;
            PayRate = payRate;
            NetPay = CalculateNetPay();
        }

        // Private method to calculate net pay
        private decimal CalculateNetPay()
        {
            const decimal FederalTaxRate = 0.1329m;
            const decimal StateTaxRate = 0.0355m;
            const decimal SocialSecurityTaxRate = 0.0717m;
            const decimal MedicareTaxRate = 0.0168m;

            decimal grossPay = HoursWorked * PayRate;
            decimal federalTax = grossPay * FederalTaxRate;
            decimal stateTax = grossPay * StateTaxRate;
            decimal socialSecurityTax = grossPay * SocialSecurityTaxRate;
            decimal medicareTax = grossPay * MedicareTaxRate;

            decimal netPay = grossPay - federalTax - stateTax - socialSecurityTax - medicareTax;

            // Update static properties
            TotalGrossPay += grossPay;
            TotalNetPay += netPay;
            TotalPaySlips++;

            return netPay;
        }

        // Static method to calculate average net pay
        public static decimal CalculateAverageNetPay()
        {
            if (TotalPaySlips == 0)
                return 0;

            return TotalNetPay / TotalPaySlips;
        }
    }
}
