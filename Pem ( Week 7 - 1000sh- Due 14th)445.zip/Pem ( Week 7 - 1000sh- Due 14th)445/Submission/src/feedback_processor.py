import pandas as pd

def process_feedback(file_path):
    # Read the feedback data
    feedback = pd.read_excel(file_path)
    print("Feedback Data Loaded Successfully.")

    # Group by Priority and summarize features
    summary = feedback.groupby("Priority")["Feature"].apply(list)
    print("\nFeature Summary by Priority:")
    print(summary)

    # Save the processed feedback summary
    summary.to_excel("../docs/Feedback_Summary.xlsx", index=True)
    print("Processed feedback summary saved to '../docs/Feedback_Summary.xlsx'.")

# Specify the input file path
file_path = "../data/feedback_analysis.xlsx"
process_feedback(file_path)
