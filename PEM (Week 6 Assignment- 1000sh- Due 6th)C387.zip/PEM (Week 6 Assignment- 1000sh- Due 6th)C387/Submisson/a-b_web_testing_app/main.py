### FILE: main.py
from flask import Flask, render_template, request, redirect, session, jsonify
from pymongo import MongoClient
import random
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# MongoDB setup
client = MongoClient('mongodb://localhost:27017/')
db = client['ab_testing']
interactions = db['interactions']

# Routes
@app.route('/')
def intro():
    """Render the static intro page."""
    return render_template('intro.html')

@app.route('/login', methods=['POST'])
def login():
    """Simulate user login and redirect to home."""
    if 'version' not in session:
        session['version'] = random.choice(['A', 'B'])  # Assign user to version A or B
    return redirect('/home')

@app.route('/home')
def home():
    """Render version A or B of the home page based on session."""
    version = session.get('version', 'A')
    return render_template(f'home_{version}.html', version=version)

@app.route('/track', methods=['POST'])
def track():
    """Track button clicks and save data to MongoDB."""
    data = {
        'ip_address': request.remote_addr,
        'timestamp': datetime.now(),
        'page_version': session.get('version', 'A'),
        'button_id': request.json.get('button_id')
    }
    interactions.insert_one(data)
    return jsonify({'status': 'success'})

if __name__ == '__main__':
    app.run(debug=True)
