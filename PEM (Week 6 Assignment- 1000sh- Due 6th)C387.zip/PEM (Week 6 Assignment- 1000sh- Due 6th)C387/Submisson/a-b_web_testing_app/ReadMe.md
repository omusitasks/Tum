# Project Setup

1. **Install Dependencies**:
   - Install Python and MongoDB.
   - Install Python packages:
     pip install flask pymongo

2. **Start MongoDB:**:
   Run MongoDB locally: mongod

3. **Run the App**:
   Start the Flask server: python app.py


4. **Access the App:**:
   Open a web browser and go to http://127.0.0.1:5000.


# How It Works
- Intro Page: The user lands on a simple introduction page and logs in.
- A/B Testing Logic:
  * Users are randomly assigned to version A or B of the home page upon login.
  * The assignment is stored in their session for stickiness.
- Interaction Tracking:
  * Button clicks on home pages send data (button ID, version, timestamp) to the backend.
  * The data is stored in MongoDB for analysis.