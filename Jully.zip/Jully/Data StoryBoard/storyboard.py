import matplotlib.pyplot as plt

def create_horizontal_storyboard():
    fig, axs = plt.subplots(3, 3, figsize=(20, 15))
    fig.suptitle('Data Storyboard: Boosting Sales with Strategic Insights', fontsize=16)

    # Introduction
    axs[0, 0].axis('off')
    axs[0, 0].text(0.5, 0.5, 'Introduction\n\nObjective: To provide actionable insights from recent sales data\nTarget Audience: Marketing Managers', 
                   ha='center', va='center', fontsize=12)

    # Trends: Line Chart
    axs[0, 1].plot([1, 2, 3, 4], [10, 20, 15, 25], marker='o')
    axs[0, 1].set_title('Overall Sales Growth')
    axs[0, 1].set_xlabel('Time')
    axs[0, 1].set_ylabel('Sales')

    # Trends: Bar Chart
    axs[0, 2].bar(['Q1', 'Q2', 'Q3', 'Q4'], [15, 25, 20, 30], color='skyblue')
    axs[0, 2].set_title('Seasonal Sales Variations')
    axs[0, 2].set_xlabel('Quarter')
    axs[0, 2].set_ylabel('Sales')

    # Customer Demographics: Pie Chart
    axs[1, 0].pie([35, 25, 20, 20], labels=['18-25', '26-35', '36-45', '46+'], autopct='%1.1f%%', colors=['gold', 'lightgreen', 'lightcoral', 'lightskyblue'])
    axs[1, 0].set_title('Sales by Age Group')

    # Customer Demographics: Bar Chart
    axs[1, 1].bar(['Male', 'Female'], [55, 45], color=['blue', 'pink'])
    axs[1, 1].set_title('Sales by Gender')
    axs[1, 1].set_xlabel('Gender')
    axs[1, 1].set_ylabel('Sales')

    # Product Categories: Stacked Bar Chart
    categories = ['Apparel', 'Footwear', 'Equipment']
    online_sales = [20, 15, 5]
    instore_sales = [30, 25, 15]
    axs[1, 2].bar(categories, online_sales, color='lightblue', label='Online')
    axs[1, 2].bar(categories, instore_sales, bottom=online_sales, color='lightgreen', label='In-store')
    axs[1, 2].set_title('Sales by Product Category')
    axs[1, 2].set_ylabel('Sales')
    axs[1, 2].legend()

    # Product Categories: Column Chart
    axs[2, 0].bar(['Product A', 'Product B', 'Product C'], [40, 35, 25], color='orange')
    axs[2, 0].set_title('Best-Selling Products')
    axs[2, 0].set_xlabel('Product')
    axs[2, 0].set_ylabel('Sales')

    # Sales Channels: Pie Chart
    axs[2, 1].pie([60, 40], labels=['Online', 'In-store'], autopct='%1.1f%%', colors=['lightcoral', 'lightskyblue'])
    axs[2, 1].set_title('Online vs. In-Store Sales')

    # Hide the last subplot (empty space)
    plt.subplots_adjust(hspace=0.4)
    axs[2, 2].axis('off')

    plt.show()

# Create the horizontal storyboard
create_horizontal_storyboard()
