import csv
import random

# Define sample product IDs and review text
product_ids = [f'P{i:03}' for i in range(1, 21)]  # Create 20 product IDs: P001, P002, ..., P020
ratings = [1, 2, 3, 4, 5]  # Rating from 1 (worst) to 5 (best)
reviews = [
    "Great product!", "Not satisfied.", "Excellent quality.", 
    "Terrible experience.", "Would buy again.", "Very bad.", 
    "Loved it.", "Worst product ever.", "Highly recommended!", 
    "Not worth the price.", "Amazing!", "Defective item.", 
    "Works perfectly.", "Disappointed.", "Superb performance.", 
    "Bad quality.", "Fantastic.", "Terrible design.", 
    "Exactly as described.", "Awful customer service."
]

# Generate mock data for 20 reviews
data = []
for i in range(20):
    product_id = random.choice(product_ids)
    rating = random.choice(ratings)
    review = random.choice(reviews)
    data.append([product_id, rating, review])

# Export the data to a CSV file
with open('spark.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["Product ID", "Rating", "Review Text"])  # Write headers
    writer.writerows(data)

print("Data exported to spark.csv")
