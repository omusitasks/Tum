# import speech_recognition as sr

# def transcribe_audio(file_path):
#     recognizer = sr.Recognizer()

#     with sr.AudioFile(file_path) as source:
#         print("Transcribing...")
#         audio_data = recognizer.record(source)
#         try:
#             # Use offline recognition (CMU Sphinx)
#             text = recognizer.recognize_sphinx(audio_data)
#             print("Transcription:", text)
#             return text
#         except sr.UnknownValueError:
#             print("Could not understand the audio")
#         except sr.RequestError:
#             print("Sphinx recognition service error")

# # Example usage
# transcribe_audio("extracted_audio.wav")


import whisper

model = whisper.load_model("small")  # Change to "tiny" if needed
result = model.transcribe("Jyothi-Michael_Interview.mp4")

print(result["text"])  # Print transcription before saving
with open("real.txt", "w", encoding="utf-8") as f:
    f.write(result["text"])

print("Transcription saved as transcription.txt")
