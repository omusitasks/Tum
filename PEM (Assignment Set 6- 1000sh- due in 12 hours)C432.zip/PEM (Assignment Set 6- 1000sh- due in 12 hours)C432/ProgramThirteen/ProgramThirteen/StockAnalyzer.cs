/*
 * Project:         Assignment Set 6 - Program 14
 * Date:            October 2024
 * Developed By:    LV
 * Class Name:      StockAnalyzer
 * Description:     Provides methods to analyze stock prices including finding 
 *                  largest absolute price change, smallest percentage gain, 
 *                  number of negative price changes, and longest price gain streak.
 */

using System;

namespace CIS605AS6
{
    public class StockAnalyzer
    {
        #region "Properties"

        public string TickerSymbol { get; private set; }
        public decimal[] StockPrices { get; private set; }

        #endregion

        #region "Constructor"

        public StockAnalyzer(string symbol, decimal[] prices)
        {
            TickerSymbol = symbol;
            StockPrices = prices;
        }

        #endregion

        #region "Methods"

        /* Method: FindLargestAbsolutePriceChange
         * Purpose: Finds the largest absolute price change between two consecutive days.
         * Returns: decimal - Largest absolute price change.
         */
        public decimal FindLargestAbsolutePriceChange()
        {
            decimal largestChange = 0;
            for (int i = 1; i < StockPrices.Length; i++)
            {
                decimal change = Math.Abs(StockPrices[i] - StockPrices[i - 1]);
                if (change > largestChange)
                {
                    largestChange = change;
                }
            }
            return largestChange;
        }

        /* Method: FindSmallestPercentageGainInPrice
         * Purpose: Finds the smallest percentage gain in price between two consecutive days.
         * Returns: string - Smallest percentage gain formatted with '%' and 5 decimal places.
         */
        public string FindSmallestPercentageGainInPrice()
        {
            decimal smallestGain = decimal.MaxValue;
            for (int i = 1; i < StockPrices.Length; i++)
            {
                decimal gain = (StockPrices[i] - StockPrices[i - 1]) / StockPrices[i - 1];
                if (gain < smallestGain)
                {
                    smallestGain = gain;
                }
            }
            return $"{smallestGain:P5}";
        }

        /* Method: FindNumTimesNegativePriceChange
         * Purpose: Counts the number of times the price decreased between two consecutive days.
         * Returns: int - Number of times a negative price change occurred.
         */
        public int FindNumTimesNegativePriceChange()
        {
            int negativeCount = 0;
            for (int i = 1; i < StockPrices.Length; i++)
            {
                if (StockPrices[i] < StockPrices[i - 1])
                {
                    negativeCount++;
                }
            }
            return negativeCount;
        }

        /* Method: FindLongestPriceGainStreak
         * Purpose: Finds the longest streak of consecutive price gains.
         * Returns: int - Length of the longest gain streak in days.
         */
        public int FindLongestPriceGainStreak()
        {
            int longestStreak = 0;
            int currentStreak = 0;

            for (int i = 1; i < StockPrices.Length; i++)
            {
                if (StockPrices[i] > StockPrices[i - 1])
                {
                    currentStreak++;
                    if (currentStreak > longestStreak)
                    {
                        longestStreak = currentStreak;
                    }
                }
                else
                {
                    currentStreak = 0;
                }
            }
            return longestStreak;
        }

        #endregion
    }
}
