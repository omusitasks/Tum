﻿/*
 * Project:         Assignment Set 6 - Program 15
 * Date:            October 2024
 * Developed By:    LV
 * Class Name:      ScoreCard
 * Assumption:      The scorecard is for a specific tournament and year
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIS605AS6
{
    public class ScoreCard
    {
        #region "Constants"

        const string PGATour = "2024 PGA Championship", CourseName = "Vallahalla Golf Club";

        int[] CoursePars = { 4, 4, 3, 4, 4, 4, 5, 3, 4, 5, 3, 4, 4, 3, 4, 4, 4, 5 };

        #endregion

        #region "Properties"

        public string PlayerName { get; private set; }
        public int[,] ScoresByRound { get; private set; }

        #endregion

        #region "Constructor"

        public ScoreCard(string name, int[,] scores)
        {
            PlayerName = name;
            ScoresByRound = scores;
        }

        #endregion

        #region "Methods"

        // Method to calculate and return the player's status after each hole for a given round.
        public int[] CalcStatusAfterHole(int round)
        {
            int[] status = new int[CoursePars.Length];
            status[0] = ScoresByRound[round - 1, 0] - CoursePars[0];

            for (int i = 1; i < CoursePars.Length; i++)
            {
                status[i] = status[i - 1] + (ScoresByRound[round - 1, i] - CoursePars[i]);
            }

            return status;
        }

        // Method to calculate and return the player's average score for holes of a specific par (i.e., 3, 4 or 5).
        public double CalcAverageScoreByPar(int par)
        {
            int totalScore = 0, count = 0;

            for (int round = 0; round < ScoresByRound.GetLength(0); round++)
            {
                for (int hole = 0; hole < CoursePars.Length; hole++)
                {
                    if (CoursePars[hole] == par)
                    {
                        totalScore += ScoresByRound[round, hole];
                        count++;
                    }
                }
            }

            // Calculate average score for holes with the given par
            return count > 0 ? (double)totalScore / count : 0;
        }

        // Method to find and return the number of holes for which the player's score was "consistent" across all rounds.
        public int FindNumberOfHolesWithConsistentScore()
        {
            int consistentHoles = 0;

            for (int hole = 0; hole < CoursePars.Length; hole++)
            {
                bool isConsistent = true;
                int firstRoundScore = ScoresByRound[0, hole];

                for (int round = 1; round < ScoresByRound.GetLength(0); round++)
                {
                    if (ScoresByRound[round, hole] != firstRoundScore)
                    {
                        isConsistent = false;
                        break;
                    }
                }

                if (isConsistent)
                {
                    consistentHoles++;
                }
            }

            return consistentHoles;
        }

        // Method to calculate and return the player's overall performance by score type (Eagles, Birdies, Pars, Bogeys, Double Bogeys).
        public string CalcPerformanceByScoreType()
        {
            int eagles = 0, birdies = 0, pars = 0, bogeys = 0, doubleBogeys = 0;

            for (int round = 0; round < ScoresByRound.GetLength(0); round++)
            {
                for (int hole = 0; hole < CoursePars.Length; hole++)
                {
                    int difference = ScoresByRound[round, hole] - CoursePars[hole];

                    switch (difference)
                    {
                        case -2:
                            eagles++;
                            break;
                        case -1:
                            birdies++;
                            break;
                        case 0:
                            pars++;
                            break;
                        case 1:
                            bogeys++;
                            break;
                        case 2:
                            doubleBogeys++;
                            break;
                    }
                }
            }

            return $"Eagles: {eagles}, Birdies: {birdies}, Pars: {pars}, Bogeys: {bogeys}, Double Bogeys: {doubleBogeys}";
        }

        #endregion
    }
}
