#nullable disable
/*
 * Project:         Assignment Set 6 - Program 14
 * Date:            October 2024
 * Developed By:    LV
 * Class Name:      Program14 - Presentation Layer
 * Purpose:         UI and event handling for stock analysis using StockAnalyzer class.
 */

using System;
using System.Windows.Forms;

namespace CIS605AS6
{
    public partial class Program14 : Form
    {
        #region "Done"

        private StockAnalyzer aAnalyzer;

        public Program14()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            string symbol = txtSymbol.Text;
            string[] stringPrices = txtPrices.Text.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
            decimal[] prices = Array.ConvertAll(stringPrices, decimal.Parse);

            aAnalyzer = new StockAnalyzer(symbol, prices);

            grpStockInfo.Enabled = false;
            grpAnalysis.Enabled = true;
        }

        #endregion

        #region "To Do"

        /* Event Handler: btnLargest_Click
         * Purpose: Displays the largest absolute price change in lblLargest.
         */
        private void btnLargest_Click(object sender, EventArgs e)
        {
            decimal largestChange = aAnalyzer.FindLargestAbsolutePriceChange();
            lblLargest.Text = largestChange.ToString("C");
        }

        /* Event Handler: btnSmallest_Click
         * Purpose: Displays the smallest percentage gain in lblSmallest.
         */
        private void btnSmallest_Click(object sender, EventArgs e)
        {
            string smallestGain = aAnalyzer.FindSmallestPercentageGainInPrice();
            lblSmallest.Text = smallestGain;
        }

        /* Event Handler: btnNegative_Click
         * Purpose: Displays the count of negative price changes in lblNegative.
         */
        private void btnNegative_Click(object sender, EventArgs e)
        {
            int negativeCount = aAnalyzer.FindNumTimesNegativePriceChange();
            lblNegative.Text = negativeCount.ToString();
        }

        /* Event Handler: btnLongest_Click
         * Purpose: Displays the longest price gain streak in lblLongest.
         */
        private void btnLongest_Click(object sender, EventArgs e)
        {
            int longestStreak = aAnalyzer.FindLongestPriceGainStreak();
            lblLongest.Text = longestStreak.ToString();
        }

        #endregion

        #region "Done"

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtSymbol.Clear();
            txtPrices.Clear();

            foreach (Control aControl in grpAnalysis.Controls)
            {
                if (aControl is Label)
                    aControl.Text = null;
            }

            grpStockInfo.Enabled = true;
            grpAnalysis.Enabled = false;
            txtSymbol.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult aResult = MessageBox.Show("Do you wish to exit?", "Confirm Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (aResult == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {
                txtSymbol.Focus();
            }
        }

        #endregion
    }
}
