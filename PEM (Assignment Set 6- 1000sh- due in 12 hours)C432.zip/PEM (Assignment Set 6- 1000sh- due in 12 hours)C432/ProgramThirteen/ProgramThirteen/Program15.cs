﻿#nullable disable
/*
 * Project:         Assignment Set 6 - Program 15
 * Date:            October 2024
 * Developed By:    LV
 * Class Name:      Program15 - Presentation Layer
 * Purpose:         Create and use Scorecard Class
 * Uses:            ScoreCard class
*/

using System;
using System.Windows.Forms;

namespace CIS605AS6
{
    public partial class Program15 : Form
    {
        #region "Done"

        // Declare class-level object variable
        private ScoreCard aCard;

        public Program15()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            // Assign player name to pName
            string pName = txtName.Text;

            // Assign the four text boxes to an array
            TextBox[] roundBoxes = { txtRound1, txtRound2, txtRound3, txtRound4 };

            // Use a jagged array to store the scores of each round as an array
            int[][] roundScores = new int[4][];

            for (int round = 0; round < 4; ++round)
            {
                // Split each hole score in the round using tab (\t) as the split character
                string[] tempStrScores = roundBoxes[round].Text.Split(new char[] { '\t' }, StringSplitOptions.RemoveEmptyEntries);

                // Convert the string array to an int and assign to roundScores array
                int[] tempIntScores = Array.ConvertAll(tempStrScores, int.Parse);

                roundScores[round] = tempIntScores;
            }

            // Create a two-dimensional array with the data from the jagged array
            int[,] scoresByRound = new int[4, 18];
            for (int row = 0; row < 4; ++row)
            {
                for (int col = 0; col < 18; ++col)
                {
                    scoresByRound[row, col] = roundScores[row][col];
                }
            }

            // Instantiate ScoreCard object
            aCard = new ScoreCard(pName, scoresByRound);

            // Disable/enable controls
            grpScoreInfo.Enabled = false;
            grpStats.Enabled = true;
        }

        #endregion

        #region "To Do"

        // Complete this method to display the player's status after each hole
        private void btnStatusAfterHole_Click(object sender, EventArgs e)
        {
            if (aCard != null)
            {
                // Get the selected round number from the NumericUpDown control
                int round = (int)nudRound.Value;

                // Call the CalcStatusAfterHole method
                int[] statusAfterHoles = aCard.CalcStatusAfterHole(round);

                // Display the results in lstAfterHoleStatus
                lstAfterHoleStatus.Items.Clear();
                for (int i = 0; i < statusAfterHoles.Length; i++)
                {
                    lstAfterHoleStatus.Items.Add($"Hole {i + 1}: {statusAfterHoles[i]}");
                }
            }
        }

        // Complete this method to display the average score for holes of a specific par
        private void btnAverageScore_Click(object sender, EventArgs e)
        {
            if (aCard != null)
            {
                // Get the selected par value from the NumericUpDown control
                int par = (int)nudPar.Value;

                // Call the CalcAverageScoreByPar method
                double averageScore = aCard.CalcAverageScoreByPar(par);

                // Display the returned result in lblAverageScore
                lblAverageScore.Text = $"Average Score for Par {par}: {averageScore:F2}";
            }
        }

        // Complete this method to find and display the number of holes with a consistent score
        private void btnConsistentHoles_Click(object sender, EventArgs e)
        {
            if (aCard != null)
            {
                // Call the FindNumberOfHolesWithConsistentScore method
                int consistentHolesCount = aCard.FindNumberOfHolesWithConsistentScore();

                // Display the result in lblConsistentScoreHoles
                lblConsistentScoreHoles.Text = $"Consistent Score Holes: {consistentHolesCount}";
            }
        }

        // Complete this method to calculate and display the player's overall performance by score type
        private void btnPerformance_Click(object sender, EventArgs e)
        {
            if (aCard != null)
            {
                // Call the CalcPerformanceByScoreType method
                string performanceSummary = aCard.CalcPerformanceByScoreType();

                // Display the result in lblPerformance
                lblPerformance.Text = performanceSummary;
            }
        }

        #endregion

        #region "Done"

        private void btnReset_Click(object sender, EventArgs e)
        {
            // Reset the form for fresh inputs
            foreach (Control aControl in grpScoreInfo.Controls)
            {
                if (aControl is TextBox)
                    aControl.Text = null;
            }

            lstAfterHoleStatus.Items.Clear();
            nudRound.Value = nudRound.Minimum;
            nudPar.Value = nudPar.Minimum;
            lblAverageScore.Text = null;
            lblConsistentScoreHoles.Text = null;
            lblPerformance.Text = null;

            // Enable/disable controls
            grpScoreInfo.Enabled = true;
            grpStats.Enabled = false;

            // Set focus
            txtName.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Declare variable of type DialogResult
            DialogResult aResult;

            // Assign the return value to the variable
            aResult = MessageBox.Show("Do you wish to exit?", "Confirm Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);

            // Take action based on the value of aResult
            if (aResult == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {
                txtName.Focus();
            }
        }

        #endregion
    }
}
