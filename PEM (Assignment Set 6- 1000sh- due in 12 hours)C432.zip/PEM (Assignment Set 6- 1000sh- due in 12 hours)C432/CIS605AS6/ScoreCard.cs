﻿/*
 * Project:         Assignment Set 6 - Program 15
 * Date:            October 2024
 * Developed By:    LV
 * Class Name:      ScoreCard
 * Description:     Represents a player's scorecard in a golf tournament.
 * Assumption:      The scorecard is for a specific tournament and year.
*/

using System;
using System.Linq;

namespace CIS605AS6
{
    public class ScoreCard
    {
        #region "Constants"

        const string PGATour = "2024 PGA Championship", CourseName = "Valhalla Golf Club";
        int[] CoursePars = { 4, 4, 3, 4, 4, 4, 5, 3, 4, 5, 3, 4, 4, 3, 4, 4, 4, 5 };

        #endregion

        #region "Properties"

        public string PlayerName { get; private set; }
        public int[,] ScoresByRound { get; private set; }

        #endregion

        #region "Constructor"

        public ScoreCard(string name, int[,] scores)
        {
            PlayerName = name;
            ScoresByRound = scores;
        }

        #endregion

        #region "Methods"

        public int[] CalcStatusAfterHole(int round)
        {
            int[] statusAfterHole = new int[18];
            statusAfterHole[0] = ScoresByRound[round, 0] - CoursePars[0];

            for (int hole = 1; hole < 18; hole++)
            {
                statusAfterHole[hole] = statusAfterHole[hole - 1] + (ScoresByRound[round, hole] - CoursePars[hole]);
            }

            return statusAfterHole;
        }

        public double CalcAverageScoreByPar(int par)
        {
            int totalScore = 0;
            int count = 0;

            for (int hole = 0; hole < 18; hole++)
            {
                if (CoursePars[hole] == par)
                {
                    for (int round = 0; round < 4; round++)
                    {
                        totalScore += ScoresByRound[round, hole];
                    }
                    count++;
                }
            }

            return (double)totalScore / (count * 4);
        }

        public int FindNumberOfHolesWithConsistentScore()
        {
            int consistentScoreHoles = 0;

            for (int hole = 0; hole < 18; hole++)
            {
                bool isConsistent = true;
                int firstScore = ScoresByRound[0, hole];

                for (int round = 1; round < 4; round++)
                {
                    if (ScoresByRound[round, hole] != firstScore)
                    {
                        isConsistent = false;
                        break;
                    }
                }

                if (isConsistent)
                {
                    consistentScoreHoles++;
                }
            }

            return consistentScoreHoles;
        }

        public string CalcPerformanceByScoreType()
        {
            int eagles = 0, birdies = 0, pars = 0, bogeys = 0, doubleBogeys = 0;

            for (int round = 0; round < 4; round++)
            {
                for (int hole = 0; hole < 18; hole++)
                {
                    int scoreDiff = ScoresByRound[round, hole] - CoursePars[hole];

                    if (scoreDiff == -2) eagles++;
                    else if (scoreDiff == -1) birdies++;
                    else if (scoreDiff == 0) pars++;
                    else if (scoreDiff == 1) bogeys++;
                    else if (scoreDiff == 2) doubleBogeys++;
                }
            }

            return $"Eagles: {eagles}, Birdies: {birdies}, Pars: {pars}, Bogeys: {bogeys}, Double Bogeys: {doubleBogeys}";
        }

        #endregion
    }
}
