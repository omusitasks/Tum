﻿#nullable disable
/*
 * Project:         Assignment Set 6 - Program 15
 * Date:            October 2024
 * Developed By:    LV
 * Class Name:      Program15 - Presentation Layer
 * Purpose:         Create and use Scorecard Class
 * Uses:            ScoreCard class
*/

using System;
using System.Windows.Forms;

namespace CIS605AS6
{
    public partial class Program15 : Form
    {
        private ScoreCard aCard;

        public Program15()
        {
            InitializeComponent();
        }

        private void btnStatusAfterHole_Click(object sender, EventArgs e)
        {
            int round = (int)nudRound.Value - 1;
            int[] statusAfterHole = aCard.CalcStatusAfterHole(round);

            lstAfterHoleStatus.DataSource = statusAfterHole;
        }

        private void btnAverageScore_Click(object sender, EventArgs e)
        {
            int par = (int)nudPar.Value;
            double averageScore = aCard.CalcAverageScoreByPar(par);

            lblAverageScore.Text = $"Average Score: {averageScore:F2}";
        }

        private void btnConsistentHoles_Click(object sender, EventArgs e)
        {
            int consistentScoreHoles = aCard.FindNumberOfHolesWithConsistentScore();

            lblConsistentScoreHoles.Text = $"Consistent Score Holes: {consistentScoreHoles}";
        }

        private void btnPerformance_Click(object sender, EventArgs e)
        {
            string performance = aCard.CalcPerformanceByScoreType();

            lblPerformance.Text = performance;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            foreach (Control aControl in grpScoreInfo.Controls)
            {
                if (aControl is TextBox)
                    aControl.Text = null;
            }

            lstAfterHoleStatus.DataSource = null;
            nudRound.Value = nudRound.Minimum;
            nudPar.Value = nudPar.Minimum;

            lblAverageScore.Text = null;
            lblConsistentScoreHoles.Text = null;
            lblPerformance.Text = null;

            grpScoreInfo.Enabled = true;
            grpStats.Enabled = false;

            txtName.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult aResult = MessageBox.Show("Do you wish to exit?", "Confirm Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);

            if (aResult == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {
                txtName.Focus();
            }
        }
    }
}
