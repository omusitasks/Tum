/*
 * Project:         Program 5
 * Date Created:    September 2024
 * Last Modified:   September 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      PaintJob
 * Description:     Instance class containing method for estimating the cost of a paint job.
 */

using System;

namespace Program_5
{
    /// <summary>
    /// Class for estimating paint job costs.
    /// </summary>
    public class PaintJob
    {
        // Constants for paint coverage and labor cost per square foot
        private const double PAINT_COVERAGE_PER_GALLON = 390; // square feet
        private const double LABOR_COST_PER_SQUARE_FOOT = 3.05; // dollars

        /// <summary>
        /// Calculates the estimated cost of the paint job.
        /// </summary>
        /// <param name="squareFootage">The total square footage to be painted.</param>
        /// <param name="costPerGallon">The cost of a gallon of paint.</param>
        /// <returns>The estimated total cost of the paint job.</returns>
        public double CalculateEstimatedCost(double squareFootage, double costPerGallon)
        {
            // Calculate paint and labor costs
            double paintCost = (squareFootage / PAINT_COVERAGE_PER_GALLON) * costPerGallon;
            double laborCost = squareFootage * LABOR_COST_PER_SQUARE_FOOT;

            // Return the total estimated cost
            return paintCost + laborCost;
        }
    }
}
