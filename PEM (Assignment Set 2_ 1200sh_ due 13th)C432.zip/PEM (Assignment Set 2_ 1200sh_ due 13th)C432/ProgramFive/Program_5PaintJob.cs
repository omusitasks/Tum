/*
 * Project:         Program 5
 * Date Created:    September 2024
 * Last Modified:   September 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      Program_5PaintJob
 * Description:     Presentation Layer class for calculating paint job costs.
 */

using System;
using System.Windows.Forms;

namespace Program_5
{
    public partial class Program_5PaintJob : Form
    {
        /// <summary>
        /// Initializes a new instance of the Program_5PaintJob class.
        /// </summary>
        public Program_5PaintJob()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the click event for btnCalculate to display the estimated cost.
        /// </summary>
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Get the input values
            double squareFootage = (double)numSquareFootage.Value;
            double costPerGallon = (double)numCostPerGallon.Value;

            // Instantiate PaintJob and calculate the cost
            PaintJob paintJob = new PaintJob();
            double estimatedCost = paintJob.CalculateEstimatedCost(squareFootage, costPerGallon);

            // Display the result
            MessageBox.Show($"Estimated Cost: {estimatedCost:C}", "Paint Job Estimate");
        }

        /// <summary>
        /// Handles the click event for btnClear to reset the input fields.
        /// </summary>
        private void btnClear_Click(object sender, EventArgs e)
        {
            numSquareFootage.Value = 0;
            numCostPerGallon.Value = 0;
        }

        /// <summary>
        /// Handles the click event for btnExit to close the application.
        /// </summary>
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
