namespace Program_5
{
    partial class Program_5PaintJob
    {
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.numSquareFootage = new System.Windows.Forms.NumericUpDown();
            this.numCostPerGallon = new System.Windows.Forms.NumericUpDown();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblDeveloper = new System.Windows.Forms.Label();
            this.lblSquareFootage = new System.Windows.Forms.Label();
            this.lblCostPerGallon = new System.Windows.Forms.Label();

            // numSquareFootage
            this.numSquareFootage.DecimalPlaces = 2;
            this.numSquareFootage.Location = new System.Drawing.Point(180, 40);
            this.numSquareFootage.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            this.numSquareFootage.Name = "numSquareFootage";
            this.numSquareFootage.Size = new System.Drawing.Size(120, 22);

            // numCostPerGallon
            this.numCostPerGallon.DecimalPlaces = 2;
            this.numCostPerGallon.Location = new System.Drawing.Point(180, 80);
            this.numCostPerGallon.Maximum = new decimal(new int[] { 500, 0, 0, 0 });
            this.numCostPerGallon.Name = "numCostPerGallon";
            this.numCostPerGallon.Size = new System.Drawing.Size(120, 22);

            // btnCalculate
            this.btnCalculate.Location = new System.Drawing.Point(30, 130);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(80, 30);
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);

            // btnClear
            this.btnClear.Location = new System.Drawing.Point(130, 130);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(80, 30);
            this.btnClear.Text = "Clear";
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);

            // btnExit
            this.btnExit.Location = new System.Drawing.Point(230, 130);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(80, 30);
            this.btnExit.Text = "Exit";
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);

            // lblDeveloper
            this.lblDeveloper.AutoSize = true;
            this.lblDeveloper.Location = new System.Drawing.Point(100, 180);
            this.lblDeveloper.Name = "lblDeveloper";
            this.lblDeveloper.Size = new System.Drawing.Size(150, 17);
            this.lblDeveloper.Text = "Developed by Pragnya Thandra";

            // lblSquareFootage
            this.lblSquareFootage.AutoSize = true;
            this.lblSquareFootage.Location = new System.Drawing.Point(30, 40);
            this.lblSquareFootage.Text = "Square Footage";

            // lblCostPerGallon
            this.lblCostPerGallon.AutoSize = true;
            this.lblCostPerGallon.Location = new System.Drawing.Point(30, 80);
            this.lblCostPerGallon.Text = "Cost per Gallon";

            // Program_5PaintJob
            this.ClientSize = new System.Drawing.Size(350, 250);
            this.Controls.Add(this.numSquareFootage);
            this.Controls.Add(this.numCostPerGallon);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblDeveloper);
            this.Controls.Add(this.lblSquareFootage);
            this.Controls.Add(this.lblCostPerGallon);
            this.Text = "Paint Job Calculator";
        }

        private System.Windows.Forms.NumericUpDown numSquareFootage;
        private System.Windows.Forms.NumericUpDown numCostPerGallon;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblDeveloper;
        private System.Windows.Forms.Label lblSquareFootage;
        private System.Windows.Forms.Label lblCostPerGallon;
    }
}
