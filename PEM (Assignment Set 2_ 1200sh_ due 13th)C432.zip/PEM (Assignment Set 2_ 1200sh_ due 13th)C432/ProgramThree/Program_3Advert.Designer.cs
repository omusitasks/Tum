namespace Program_3
{
    partial class Program_3Advert
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblOrganizationName = new System.Windows.Forms.Label();
            this.lblTagline = new System.Windows.Forms.Label();
            this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
            this.rbtnBlue = new System.Windows.Forms.RadioButton();
            this.rbtnGreen = new System.Windows.Forms.RadioButton();
            this.rbtnRed = new System.Windows.Forms.RadioButton();
            this.rbtnOrange = new System.Windows.Forms.RadioButton();
            this.chkShowName = new System.Windows.Forms.CheckBox();
            this.chkShowTagline = new System.Windows.Forms.CheckBox();
            this.chkShowLogo = new System.Windows.Forms.CheckBox();
            this.chkShowDeveloper = new System.Windows.Forms.CheckBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblDeveloper = new System.Windows.Forms.Label();
            this.toolTipLogo = new System.Windows.Forms.ToolTip(this.components);
            this.lblPickColor = new System.Windows.Forms.Label();
            this.lblShowHide = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).BeginInit();
            this.SuspendLayout();

            // 
            // lblOrganizationName
            // 
            this.lblOrganizationName.AutoSize = true;
            this.lblOrganizationName.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Bold);
            this.lblOrganizationName.Location = new System.Drawing.Point(50, 20);
            this.lblOrganizationName.Name = "lblOrganizationName";
            this.lblOrganizationName.Size = new System.Drawing.Size(300, 50);
            this.lblOrganizationName.Text = "105.9 FM WQXR";
            this.lblOrganizationName.Visible = true;

            // 
            // lblTagline
            // 
            this.lblTagline.AutoSize = true;
            this.lblTagline.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Italic);
            this.lblTagline.Location = new System.Drawing.Point(220, 50);
            this.lblTagline.Text = "Tune in and be moved";
            this.lblTagline.Visible = true;

            // 
            // pictureBoxLogo
            // 
            this.pictureBoxLogo.Location = new System.Drawing.Point(20, 100);
            this.pictureBoxLogo.Name = "pictureBoxLogo";
            this.pictureBoxLogo.Size = new System.Drawing.Size(300, 120);
            this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogo.TabIndex = 2;
            this.pictureBoxLogo.TabStop = false;
            this.toolTipLogo.SetToolTip(this.pictureBoxLogo, "Our logo");
            this.pictureBoxLogo.Visible = true;

            // 
            // rbtnBlue
            // 
            this.rbtnBlue.AutoSize = true;
            this.rbtnBlue.Location = new System.Drawing.Point(30, 270);
            this.rbtnBlue.Name = "rbtnBlue";
            this.rbtnBlue.Size = new System.Drawing.Size(55, 25);
            this.rbtnBlue.TabIndex = 3;
            this.rbtnBlue.TabStop = true;
            this.rbtnBlue.Text = "&Blue";
            this.rbtnBlue.UseVisualStyleBackColor = true;
            this.rbtnBlue.CheckedChanged += new System.EventHandler(this.radioButtonColor_CheckedChanged);

            // 
            // rbtnGreen
            // 
            this.rbtnGreen.AutoSize = true;
            this.rbtnGreen.Location = new System.Drawing.Point(100, 270);
            this.rbtnGreen.Name = "rbtnGreen";
            this.rbtnGreen.Size = new System.Drawing.Size(70, 25);
            this.rbtnGreen.TabIndex = 4;
            this.rbtnGreen.TabStop = true;
            this.rbtnGreen.Text = "&Green";
            this.rbtnGreen.UseVisualStyleBackColor = true;
            this.rbtnGreen.CheckedChanged += new System.EventHandler(this.radioButtonColor_CheckedChanged);

            // 
            // rbtnRed
            // 
            this.rbtnRed.AutoSize = true;
            this.rbtnRed.Location = new System.Drawing.Point(180, 270);
            this.rbtnRed.Name = "rbtnRed";
            this.rbtnRed.Size = new System.Drawing.Size(55, 25);
            this.rbtnRed.TabIndex = 5;
            this.rbtnRed.TabStop = true;
            this.rbtnRed.Text = "&Red";
            this.rbtnRed.UseVisualStyleBackColor = true;
            this.rbtnRed.CheckedChanged += new System.EventHandler(this.radioButtonColor_CheckedChanged);

            // 
            // rbtnOrange
            // 
            this.rbtnOrange.AutoSize = true;
            this.rbtnOrange.Location = new System.Drawing.Point(260, 270);
            this.rbtnOrange.Name = "rbtnOrange";
            this.rbtnOrange.Size = new System.Drawing.Size(80, 25);
            this.rbtnOrange.TabIndex = 6;
            this.rbtnOrange.TabStop = true;
            this.rbtnOrange.Text = "&Orange";
            this.rbtnOrange.UseVisualStyleBackColor = true;
            this.rbtnOrange.CheckedChanged += new System.EventHandler(this.radioButtonColor_CheckedChanged);

            // 
            // chkShowName
            // 
            this.chkShowName.AutoSize = true;
            this.chkShowName.Checked = true;
            this.chkShowName.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShowName.Location = new System.Drawing.Point(350, 150);
            this.chkShowName.Name = "chkShowName";
            this.chkShowName.Size = new System.Drawing.Size(70, 25);
            this.chkShowName.TabIndex = 7;
            this.chkShowName.Text = "Name";
            this.chkShowName.UseVisualStyleBackColor = true;
            this.chkShowName.CheckedChanged += new System.EventHandler(this.checkBoxToggle_CheckedChanged);

            // 
            // chkShowTagline
            // 
            this.chkShowTagline.AutoSize = true;
            this.chkShowTagline.Checked = true;
            this.chkShowTagline.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShowTagline.Location = new System.Drawing.Point(350, 180);
            this.chkShowTagline.Name = "chkShowTagline";
            this.chkShowTagline.Size = new System.Drawing.Size(80, 25);
            this.chkShowTagline.TabIndex = 8;
            this.chkShowTagline.Text = "Tagline";
            this.chkShowTagline.UseVisualStyleBackColor = true;
            this.chkShowTagline.CheckedChanged += new System.EventHandler(this.checkBoxToggle_CheckedChanged);

            // 
            // chkShowLogo
            // 
            this.chkShowLogo.AutoSize = true;
            this.chkShowLogo.Checked = true;
            this.chkShowLogo.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShowLogo.Location = new System.Drawing.Point(350, 210);
            this.chkShowLogo.Name = "chkShowLogo";
            this.chkShowLogo.Size = new System.Drawing.Size(65, 25);
            this.chkShowLogo.TabIndex = 9;
            this.chkShowLogo.Text = "Logo";
            this.chkShowLogo.UseVisualStyleBackColor = true;
            this.chkShowLogo.CheckedChanged += new System.EventHandler(this.checkBoxToggle_CheckedChanged);

            // 
            // chkShowDeveloper
            // 
            this.chkShowDeveloper.AutoSize = true;
            this.chkShowDeveloper.Checked = true;
            this.chkShowDeveloper.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShowDeveloper.Location = new System.Drawing.Point(350, 240);
            this.chkShowDeveloper.Name = "chkShowDeveloper";
            this.chkShowDeveloper.Size = new System.Drawing.Size(100, 25);
            this.chkShowDeveloper.TabIndex = 10;
            this.chkShowDeveloper.Text = "Developer";
            this.chkShowDeveloper.UseVisualStyleBackColor = true;
            this.chkShowDeveloper.CheckedChanged += new System.EventHandler(this.checkBoxToggle_CheckedChanged);

            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(180, 310);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(100, 30);
            this.btnExit.TabIndex = 11;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);

            // 
            // lblDeveloper
            // 
            this.lblDeveloper.AutoSize = true;
            this.lblDeveloper.Location = new System.Drawing.Point(20, 230);
            this.lblDeveloper.Name = "lblDeveloper";
            this.lblDeveloper.Size = new System.Drawing.Size(220, 20);
            this.lblDeveloper.TabIndex = 12;
            this.lblDeveloper.Text = "Developer: Pragnya Thandra";

            // 
            // lblPickColor
            // 
            this.lblPickColor.AutoSize = true;
            this.lblPickColor.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblPickColor.Location = new System.Drawing.Point(20, 250);
            this.lblPickColor.Name = "lblPickColor";
            this.lblPickColor.Size = new System.Drawing.Size(95, 20);
            this.lblPickColor.TabIndex = 13;
            this.lblPickColor.Text = "Pick Color";

            // 
            // lblShowHide
            // 
            this.lblShowHide.AutoSize = true;
            this.lblShowHide.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblShowHide.Location = new System.Drawing.Point(350, 120);
            this.lblShowHide.Name = "lblShowHide";
            this.lblShowHide.Size = new System.Drawing.Size(115, 20);
            this.lblShowHide.TabIndex = 14;
            this.lblShowHide.Text = "Show/Hide";

            // 
            // Program_3Advert
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.ClientSize = new System.Drawing.Size(500, 360);
            this.Controls.Add(this.lblPickColor);
            this.Controls.Add(this.lblShowHide);
            this.Controls.Add(this.lblDeveloper);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.chkShowDeveloper);
            this.Controls.Add(this.chkShowLogo);
            this.Controls.Add(this.chkShowTagline);
            this.Controls.Add(this.chkShowName);
            this.Controls.Add(this.rbtnOrange);
            this.Controls.Add(this.rbtnRed);
            this.Controls.Add(this.rbtnGreen);
            this.Controls.Add(this.rbtnBlue);
            this.Controls.Add(this.pictureBoxLogo);
            this.Controls.Add(this.lblTagline);
            this.Controls.Add(this.lblOrganizationName);
            this.Name = "Program_3Advert";
            this.Text = "Program 3 - Advertisement";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblOrganizationName;
        private System.Windows.Forms.Label lblTagline;
        private System.Windows.Forms.PictureBox pictureBoxLogo;
        private System.Windows.Forms.RadioButton rbtnBlue;
        private System.Windows.Forms.RadioButton rbtnGreen;
        private System.Windows.Forms.RadioButton rbtnRed;
        private System.Windows.Forms.RadioButton rbtnOrange;
        private System.Windows.Forms.CheckBox chkShowName;
        private System.Windows.Forms.CheckBox chkShowTagline;
        private System.Windows.Forms.CheckBox chkShowLogo;
        private System.Windows.Forms.CheckBox chkShowDeveloper;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblDeveloper;
        private System.Windows.Forms.ToolTip toolTipLogo;
        private System.Windows.Forms.Label lblPickColor;
        private System.Windows.Forms.Label lblShowHide;
    }
}
