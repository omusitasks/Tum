/*
 * Project:         Program 3
 * Date Created:    August 2024
 * Last Modified:   August 2024
 * Developed By:    LV
 * Class Name:      Program_3Advert
 * Description:     Displays an advertising/promotion screen with customizable options.
 */

using System;
using System.Drawing;
using System.Windows.Forms;
using System.Net;

namespace Program_3
{
    public partial class Program_3Advert : Form
    {
        public Program_3Advert()
        {
            InitializeComponent();
            // Initialize with default radio button color
            lblTagline.ForeColor = Color.Blue;
            LoadImageFromUrl();
        }

        private void radioButtonColor_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnBlue.Checked)
                lblTagline.ForeColor = Color.Blue;
            else if (rbtnGreen.Checked)
                lblTagline.ForeColor = Color.Green;
            else if (rbtnRed.Checked)
                lblTagline.ForeColor = Color.Red;
            else if (rbtnOrange.Checked)
                lblTagline.ForeColor = Color.Orange;
        }

        private void checkBoxToggle_CheckedChanged(object sender, EventArgs e)
        {
            lblOrganizationName.Visible = chkShowName.Checked;
            lblTagline.Visible = chkShowTagline.Checked;
            pictureBoxLogo.Visible = chkShowLogo.Checked;
            lblDeveloper.Visible = chkShowDeveloper.Checked;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Method to load image from the given URL
        private void LoadImageFromUrl()
        {
            try
            {
                using (WebClient client = new WebClient())
                {
                    string imageUrl = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQcjo30y8eRF33cjOROo9ihpsdDDlFstv9YeA&s";
                    byte[] imageData = client.DownloadData(imageUrl);
                    using (var stream = new System.IO.MemoryStream(imageData))
                    {
                        pictureBoxLogo.Image = Image.FromStream(stream);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading image: {ex.Message}", "Image Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
