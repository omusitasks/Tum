/*
 * Project:         Program 4
 * Date Created:    September 2024
 * Last Modified:   September 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      Loan
 * Description:     Static class containing method for loan payment calculations.
 */

using System;

namespace Program_4
{
    /// <summary>
    /// Static class to calculate the monthly payment for a loan.
    /// </summary>
    public static class Loan
    {
        /// <summary>
        /// Calculates the monthly payment for a loan.
        /// </summary>
        /// <param name="loanAmount">The total loan amount.</param>
        /// <param name="durationMonths">The duration of the loan in months.</param>
        /// <param name="annualInterestRate">The annual interest rate in percentage.</param>
        /// <returns>The calculated monthly payment.</returns>
        public static decimal CalculateMonthlyPayment(decimal loanAmount, int durationMonths, decimal annualInterestRate)
        {
            const int monthsPerYear = 12;
            decimal monthlyInterestRate = annualInterestRate / (100 * monthsPerYear);
            decimal numerator = loanAmount * monthlyInterestRate * (decimal)Math.Pow((double)(1 + monthlyInterestRate), durationMonths);
            decimal denominator = (decimal)Math.Pow((double)(1 + monthlyInterestRate), durationMonths) - 1;
            return numerator / denominator;
        }
    }
}
