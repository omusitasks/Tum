/*
 * Project:         Program 4
 * Date Created:    September 2024
 * Last Modified:   September 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      Program_4Loan
 * Description:     Form class for loan calculator.
 */

using System;
using System.Windows.Forms;

namespace Program_4
{
    public partial class Program_4Loan : Form
    {
        public Program_4Loan()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Read user input
            decimal loanAmount = numLoanAmount.Value;
            int durationMonths = (int)numDuration.Value;
            decimal annualInterestRate = numInterestRate.Value;

            // Call the static method to calculate the monthly payment
            decimal monthlyPayment = Loan.CalculateMonthlyPayment(loanAmount, durationMonths, annualInterestRate);

            // Display the result formatted as currency
            lblMonthlyPayment.Text = $"Monthly Payment: {monthlyPayment:C}";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Reset all input fields and the monthly payment label
            numLoanAmount.Value = 0;
            numDuration.Value = 0;
            numInterestRate.Value = 0;
            lblMonthlyPayment.Text = string.Empty;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Exit the application
            Application.Exit();
        }
    }
}
