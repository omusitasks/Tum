/*
 * Project:         Program_9Conference.Designer.cs
 * Date Created:    October 2024
 * Last Modified:   October 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      ConferenceManagement
 * Description:     User interface for entering conference details and displaying calculated charges.
 */



using System;
using System.Windows.Forms;

namespace Program_9
{
    partial class Program_9Conference
    {
        private System.ComponentModel.IContainer components = null;

        
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Required method for Designer support.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtConferenceName = new System.Windows.Forms.TextBox();
            this.numAttendees = new System.Windows.Forms.NumericUpDown();
            this.numNights = new System.Windows.Forms.NumericUpDown();
            this.rdoSingle = new System.Windows.Forms.RadioButton();
            this.rdoDouble = new System.Windows.Forms.RadioButton();
            this.rdoSuite = new System.Windows.Forms.RadioButton();
            this.chkInternetAccess = new System.Windows.Forms.CheckBox();
            this.chkRecCenterAccess = new System.Windows.Forms.CheckBox();
            this.btnCreateConference = new System.Windows.Forms.Button();
            this.btnModifyConference = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblAccommodationCharge = new System.Windows.Forms.Label();
            this.lblOptionalServicesCharge = new System.Windows.Forms.Label();
            this.lblDiscount = new System.Windows.Forms.Label();
            this.lblTotalCharge = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numAttendees)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNights)).BeginInit();
            this.SuspendLayout();
            // 
            // txtConferenceName
            // 
            this.txtConferenceName.Location = new System.Drawing.Point(12, 29);
            this.txtConferenceName.Name = "txtConferenceName";
            this.txtConferenceName.Size = new System.Drawing.Size(350, 20);
            this.txtConferenceName.TabIndex = 0;
            // 
            // numAttendees
            // 
            this.numAttendees.Location = new System.Drawing.Point(12, 70);
            this.numAttendees.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.numAttendees.Maximum = new decimal(new int[] {
            850,
            0,
            0,
            0});
            this.numAttendees.Name = "numAttendees";
            this.numAttendees.Size = new System.Drawing.Size(120, 20);
            this.numAttendees.TabIndex = 1;
            this.numAttendees.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // numNights
            // 
            this.numNights.Location = new System.Drawing.Point(12, 111);
            this.numNights.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numNights.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numNights.Name = "numNights";
            this.numNights.Size = new System.Drawing.Size(120, 20);
            this.numNights.TabIndex = 2;
            this.numNights.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // rdoSingle
            // 
            this.rdoSingle.AutoSize = true;
            this.rdoSingle.Location = new System.Drawing.Point(12, 150);
            this.rdoSingle.Name = "rdoSingle";
            this.rdoSingle.Size = new System.Drawing.Size(56, 17);
            this.rdoSingle.TabIndex = 3;
            this.rdoSingle.TabStop = true;
            this.rdoSingle.Text = "Single";
            this.rdoSingle.UseVisualStyleBackColor = true;
            // 
            // rdoDouble
            // 
            this.rdoDouble.AutoSize = true;
            this.rdoDouble.Location = new System.Drawing.Point(12, 173);
            this.rdoDouble.Name = "rdoDouble";
            this.rdoDouble.Size = new System.Drawing.Size(63, 17);
            this.rdoDouble.TabIndex = 4;
            this.rdoDouble.TabStop = true;
            this.rdoDouble.Text = "Double";
            this.rdoDouble.UseVisualStyleBackColor = true;
            // 
            // rdoSuite
            // 
            this.rdoSuite.AutoSize = true;
            this.rdoSuite.Location = new System.Drawing.Point(12, 196);
            this.rdoSuite.Name = "rdoSuite";
            this.rdoSuite.Size = new System.Drawing.Size(50, 17);
            this.rdoSuite.TabIndex = 5;
            this.rdoSuite.TabStop = true;
            this.rdoSuite.Text = "Suite";
            this.rdoSuite.UseVisualStyleBackColor = true;
            // 
            // chkInternetAccess
            // 
            this.chkInternetAccess.AutoSize = true;
            this.chkInternetAccess.Location = new System.Drawing.Point(12, 220);
            this.chkInternetAccess.Name = "chkInternetAccess";
            this.chkInternetAccess.Size = new System.Drawing.Size(102, 17);
            this.chkInternetAccess.TabIndex = 6;
            this.chkInternetAccess.Text = "Internet Access";
            this.chkInternetAccess.UseVisualStyleBackColor = true;
            // 
            // chkRecCenterAccess
            // 
            this.chkRecCenterAccess.AutoSize = true;
            this.chkRecCenterAccess.Location = new System.Drawing.Point(12, 243);
            this.chkRecCenterAccess.Name = "chkRecCenterAccess";
            this.chkRecCenterAccess.Size = new System.Drawing.Size(133, 17);
            this.chkRecCenterAccess.TabIndex = 7;
            this.chkRecCenterAccess.Text = "Recreation Center Access";
            this.chkRecCenterAccess.UseVisualStyleBackColor = true;
            // 
            // btnCreateConference
            // 
            this.btnCreateConference.Location = new System.Drawing.Point(12, 280);
            this.btnCreateConference.Name = "btnCreateConference";
            this.btnCreateConference.Size = new System.Drawing.Size(120, 23);
            this.btnCreateConference.TabIndex = 8;
            this.btnCreateConference.Text = "Create Conference";
            this.btnCreateConference.UseVisualStyleBackColor = true;
            this.btnCreateConference.Click += new System.EventHandler(this.btnCreateConference_Click);
            // 
            // btnModifyConference
            // 
            this.btnModifyConference.Enabled = false;
            this.btnModifyConference.Location = new System.Drawing.Point(150, 280);
            this.btnModifyConference.Name = "btnModifyConference";
            this.btnModifyConference.Size = new System.Drawing.Size(120, 23);
            this.btnModifyConference.TabIndex = 9;
            this.btnModifyConference.Text = "Modify Conference";
            this.btnModifyConference.UseVisualStyleBackColor = true;
            this.btnModifyConference.Click += new System.EventHandler(this.btnModifyConference_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(12, 320);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(120, 23);
            this.btnClear.TabIndex = 10;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(150, 320);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(120, 23);
            this.btnExit.TabIndex = 11;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblAccommodationCharge
            // 
            this.lblAccommodationCharge.AutoSize = true;
            this.lblAccommodationCharge.Location = new System.Drawing.Point(12, 360);
            this.lblAccommodationCharge.Name = "lblAccommodationCharge";
            this.lblAccommodationCharge.Size = new System.Drawing.Size(136, 13);
            this.lblAccommodationCharge.TabIndex = 12;
            this.lblAccommodationCharge.Text = "Accommodation Charge: $0.00";
            // 
            // lblOptionalServicesCharge
            // 
            this.lblOptionalServicesCharge.AutoSize = true;
            this.lblOptionalServicesCharge.Location = new System.Drawing.Point(12, 380);
            this.lblOptionalServicesCharge.Name = "lblOptionalServicesCharge";
            this.lblOptionalServicesCharge.Size = new System.Drawing.Size(140, 13);
            this.lblOptionalServicesCharge.TabIndex = 13;
            this.lblOptionalServicesCharge.Text = "Optional Services Charge: $0.00";
            // 
            // lblDiscount
            // 
            this.lblDiscount.AutoSize = true;
            this.lblDiscount.Location = new System.Drawing.Point(12, 400);
            this.lblDiscount.Name = "lblDiscount";
            this.lblDiscount.Size = new System.Drawing.Size(103, 13);
            this.lblDiscount.TabIndex = 14;
            this.lblDiscount.Text = "Discount: $0.00";
            // 
            // lblTotalCharge
            // 
            this.lblTotalCharge.AutoSize = true;
            this.lblTotalCharge.Location = new System.Drawing.Point(12, 420);
            this.lblTotalCharge.Name = "lblTotalCharge";
            this.lblTotalCharge.Size = new System.Drawing.Size(90, 13);
            this.lblTotalCharge.TabIndex = 15;
            this.lblTotalCharge.Text = "Total Charge: $0.00";
            // 
            // Program_9Conference
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(374, 461);
            this.Controls.Add(this.lblTotalCharge);
            this.Controls.Add(this.lblDiscount);
            this.Controls.Add(this.lblOptionalServicesCharge);
            this.Controls.Add(this.lblAccommodationCharge);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnModifyConference);
            this.Controls.Add(this.btnCreateConference);
            this.Controls.Add(this.chkRecCenterAccess);
            this.Controls.Add(this.chkInternetAccess);
            this.Controls.Add(this.rdoSuite);
            this.Controls.Add(this.rdoDouble);
            this.Controls.Add(this.rdoSingle);
            this.Controls.Add(this.numNights);
            this.Controls.Add(this.numAttendees);
            this.Controls.Add(this.txtConferenceName);
            this.Name = "Program_9Conference";
            this.Text = "Conference Charge Calculator";
            ((System.ComponentModel.ISupportInitialize)(this.numAttendees)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNights)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.TextBox txtConferenceName;
        private System.Windows.Forms.NumericUpDown numAttendees;
        private System.Windows.Forms.NumericUpDown numNights;
        private System.Windows.Forms.RadioButton rdoSingle;
        private System.Windows.Forms.RadioButton rdoDouble;
        private System.Windows.Forms.RadioButton rdoSuite;
        private System.Windows.Forms.CheckBox chkInternetAccess;
        private System.Windows.Forms.CheckBox chkRecCenterAccess;
        private System.Windows.Forms.Button btnCreateConference;
        private System.Windows.Forms.Button btnModifyConference;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblAccommodationCharge;
        private System.Windows.Forms.Label lblOptionalServicesCharge;
        private System.Windows.Forms.Label lblDiscount;
        private System.Windows.Forms.Label lblTotalCharge;
    }
}
