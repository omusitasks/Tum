/*
 * Project:         Program 9
 * Date Created:    October 2024
 * Last Modified:   October 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      Program_9Conference
 * Description:     A class that calculates conference charges for CSU Conference Services based on 
 *                  accommodation type, number of attendees, nights of stay, and optional services.
 */


using System;
using System.Windows.Forms;

namespace Program_9
{
    /// <summary>
    /// Program_9Conference form handles user input and displays conference charge details.
    /// </summary>
    public partial class Program_9Conference : Form
    {
        private Conference currentConference; // Declare the currentConference variable

        public Program_9Conference()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the Create Conference button click event.
        /// </summary>
        private void btnCreateConference_Click(object sender, EventArgs e)
        {
            // Get input values
            string confName = txtConferenceName.Text;
            int attendees = (int)numAttendees.Value;
            int nights = (int)numNights.Value;
            AccommodationType accommodation = GetSelectedAccommodation();
            bool internetAccess = chkInternetAccess.Checked;
            bool recreationAccess = chkRecCenterAccess.Checked;

            // Instantiate Conference object
            currentConference = new Conference(confName, attendees, nights, accommodation, internetAccess, recreationAccess);

            // Display calculated charges
            lblAccommodationCharge.Text = $"Accommodation Charge: {currentConference.AccommodationCharge:C}";
            lblOptionalServicesCharge.Text = $"Optional Services Charge: {currentConference.OptionalServicesCharge:C}";
            lblDiscount.Text = $"Discount: {currentConference.Discount:C}";
            lblTotalCharge.Text = $"Total Charge: {currentConference.TotalCharge:C}";

            // Disable Create Conference and enable Modify
            btnCreateConference.Enabled = false;
            txtConferenceName.Enabled = false;
            btnModifyConference.Enabled = true;
        }

        /// <summary>
        /// Handles the Modify Conference button click event.
        /// </summary>
        private void btnModifyConference_Click(object sender, EventArgs e)
        {
            // Modify conference with new input values
            currentConference.NumberOfAttendees = (int)numAttendees.Value;
            currentConference.NumberOfNights = (int)numNights.Value;
            currentConference.AccommodationChoice = GetSelectedAccommodation();
            currentConference.InternetAccess = chkInternetAccess.Checked;
            currentConference.RecreationCenterAccess = chkRecCenterAccess.Checked;

            // Display updated charges
            lblAccommodationCharge.Text = $"Accommodation Charge: {currentConference.AccommodationCharge:C}";
            lblOptionalServicesCharge.Text = $"Optional Services Charge: {currentConference.OptionalServicesCharge:C}";
            lblDiscount.Text = $"Discount: {currentConference.Discount:C}";
            lblTotalCharge.Text = $"Total Charge: {currentConference.TotalCharge:C}";

            // Disable Modify Conference
            btnModifyConference.Enabled = false;
        }

        /// <summary>
        /// Clears input and output fields and resets the form.
        /// </summary>
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtConferenceName.Clear();
            numAttendees.Value = 15;
            numNights.Value = 3;
            rdoSingle.Checked = true;
            chkInternetAccess.Checked = false;
            chkRecCenterAccess.Checked = false;

            lblAccommodationCharge.Text = string.Empty;
            lblOptionalServicesCharge.Text = string.Empty;
            lblDiscount.Text = string.Empty;
            lblTotalCharge.Text = string.Empty;

            btnCreateConference.Enabled = true;
            txtConferenceName.Enabled = true;
            btnModifyConference.Enabled = false;
        }

        /// <summary>
        /// Handles the Exit button click event.
        /// </summary>
        private void btnExit_Click(object sender, EventArgs e)
        {
            // Confirm before exiting
            if (MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        /// <summary>
        /// Helper method to get the selected accommodation type.
        /// </summary>
        /// <returns>Selected AccommodationType.</returns>
        private AccommodationType GetSelectedAccommodation()
        {
            if (rdoSingle.Checked) return AccommodationType.Single;
            if (rdoDouble.Checked) return AccommodationType.Double;
            return AccommodationType.Suite;
        }
    }
}
