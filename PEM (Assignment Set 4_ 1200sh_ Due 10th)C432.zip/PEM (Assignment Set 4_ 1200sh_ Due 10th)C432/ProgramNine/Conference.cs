
/*
 * Project:         Program 9
 * Date Created:    October 2024
 * Last Modified:   October 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      ConferenceForm
 * Description:     Form for entering conference details and displaying charges.
 */

using System;

namespace Program_9
{
    /// <summary>
    /// Enum for AccommodationType: Single, Double, Suite.
    /// </summary>
    public enum AccommodationType
    {
        Single,
        Double,
        Suite
    }

    /// <summary>
    /// The Conference class calculates and manages conference charges based on user input.
    /// </summary>
    public class Conference
    {
        // Auto-implemented properties
        public string ConferenceName { get; set; }
        public decimal AccommodationCharge { get; private set; }
        public decimal OptionalServicesCharge { get; private set; }
        public decimal Discount { get; private set; }
        public decimal TotalCharge { get; private set; }

        // Private fields with properties
        private int numberOfAttendees;
        public int NumberOfAttendees
        {
            get => numberOfAttendees;
            set
            {
                numberOfAttendees = value;
                CalcConferenceCharges();
            }
        }

        private int numberOfNights;
        public int NumberOfNights
        {
            get => numberOfNights;
            set
            {
                numberOfNights = value;
                CalcConferenceCharges();
            }
        }

        private AccommodationType accommodationChoice;
        public AccommodationType AccommodationChoice
        {
            get => accommodationChoice;
            set
            {
                accommodationChoice = value;
                CalcConferenceCharges();
            }
        }

        private bool internetAccess;
        public bool InternetAccess
        {
            get => internetAccess;
            set
            {
                internetAccess = value;
                CalcConferenceCharges();
            }
        }

        private bool recreationCenterAccess;
        public bool RecreationCenterAccess
        {
            get => recreationCenterAccess;
            set
            {
                recreationCenterAccess = value;
                CalcConferenceCharges();
            }
        }

        /// <summary>
        /// Constructor for Conference class.
        /// </summary>
        /// <param name="confName">Name of the conference.</param>
        /// <param name="numAttendees">Number of attendees.</param>
        /// <param name="numNights">Number of nights.</param>
        /// <param name="accommodation">Type of accommodation.</param>
        /// <param name="internet">Internet access.</param>
        /// <param name="recCenter">Recreation center access.</param>
        public Conference(string confName, int numAttendees, int numNights, AccommodationType accommodation, bool internet, bool recCenter)
        {
            ConferenceName = confName;
            NumberOfAttendees = numAttendees;
            NumberOfNights = numNights;
            AccommodationChoice = accommodation;
            InternetAccess = internet;
            RecreationCenterAccess = recCenter;
        }

        /// <summary>
        /// Returns the accommodation rate based on type.
        /// </summary>
        /// <returns>The accommodation rate for the chosen accommodation type.</returns>
        private decimal ReturnAccommodationRate()
        {
            switch (AccommodationChoice)
            {
                case AccommodationType.Single:
                    return 76.45m;
                case AccommodationType.Double:
                    return 51.93m;
                case AccommodationType.Suite:
                    return 116.72m;
                default:
                    throw new InvalidOperationException("Invalid accommodation type.");
            }
        }

        /// <summary>
        /// Calculates the charges for the conference, including accommodation, optional services, and discounts.
        /// </summary>
        private void CalcConferenceCharges()
        {
            decimal rate = ReturnAccommodationRate();
            AccommodationCharge = rate * NumberOfAttendees * NumberOfNights;

            decimal internetCharge = InternetAccess ? 8.22m * NumberOfAttendees * NumberOfNights : 0m;
            decimal recCenterCharge = RecreationCenterAccess ? 7.74m * NumberOfAttendees * NumberOfNights : 0m;
            OptionalServicesCharge = internetCharge + recCenterCharge;

            Discount = (NumberOfAttendees >= 60 && NumberOfNights >= 7) ?
                (AccommodationCharge * 0.15m + OptionalServicesCharge * 0.0825m) : 0m;

            TotalCharge = (AccommodationCharge + OptionalServicesCharge) - Discount;
        }
    }
}
