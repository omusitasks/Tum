/*
 * Project:         Program_9Conference.Designer.cs
 * Date Created:    October 2024
 * Last Modified:   October 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      Program
 * Description:     Main entry point for the Conference application.
 */



using System;
using System.Windows.Forms;

namespace Program_9
{
    static class Program
    {
        /// <summary>
        /// Main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Program_9Conference());
        }
    }
}
