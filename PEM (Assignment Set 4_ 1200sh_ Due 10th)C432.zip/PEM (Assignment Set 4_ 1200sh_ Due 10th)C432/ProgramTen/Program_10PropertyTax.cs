using System;
using System.Windows.Forms;

namespace Program_10PropertyTax
{
    public partial class Program_10PropertyTax : Form
    {
        public Program_10PropertyTax()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate inputs
                string ownerName = txtOwnerName.Text;
                int buildingSize = int.Parse(txtBuildingSize.Text);
                int landSize = int.Parse(txtLandSize.Text);
                int yearBuilt = int.Parse(txtYearBuilt.Text);

                if (string.IsNullOrWhiteSpace(ownerName) || ownerName.Length > 30)
                {
                    MessageBox.Show("Property owner name is required and must be 30 characters or less.");
                    return;
                }

                if (buildingSize <= 0 || landSize <= 0 || yearBuilt <= 0)
                {
                    MessageBox.Show("Building size, land size, and year built must be positive.");
                    return;
                }

                if (yearBuilt > DateTime.Now.Year)
                {
                    MessageBox.Show("Year built cannot be in the future.");
                    return;
                }

                // Get the location type
                LocationType location = (LocationType)Enum.Parse(typeof(LocationType), cmbLocation.SelectedItem.ToString());

                // Instantiate PropertyTax object
                PropertyTax propertyTax = new PropertyTax(ownerName, buildingSize, landSize, yearBuilt, location);

                // Display results
                lblBuildingAge.Text = propertyTax.BuildingAge.ToString();
                lblBuildingTax.Text = propertyTax.BuildingTax.ToString("C");
                lblLandTax.Text = propertyTax.LandTax.ToString("C");
                lblBuildingTaxDeduction.Text = propertyTax.BuildingTaxDeduction.ToString("C");
                lblLandTaxDeduction.Text = propertyTax.LandTaxDeduction.ToString("C");
                lblTotalPropertyTax.Text = propertyTax.TotalPropertyTax.ToString("C");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Clear all input and output fields
            txtOwnerName.Clear();
            txtBuildingSize.Clear();
            txtLandSize.Clear();
            txtYearBuilt.Clear();
            lblBuildingAge.Text = string.Empty;
            lblBuildingTax.Text = string.Empty;
            lblLandTax.Text = string.Empty;
            lblBuildingTaxDeduction.Text = string.Empty;
            lblLandTaxDeduction.Text = string.Empty;
            lblTotalPropertyTax.Text = string.Empty;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
