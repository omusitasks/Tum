
using System;

namespace Program_10PropertyTax
{

    public enum LocationType
    {
        City,
        Suburb,
        Rural
    }


    public class PropertyTax
    {
        // Read-only fields
        public string PropertyOwnerName { get; }
        public int BuildingSquareFootage { get; }
        public int LandSquareFootage { get; }
        public int YearBuilt { get; }
        public LocationType PropertyLocation { get; }

        // Auto-implemented properties
        public int BuildingAge { get; private set; }
        public decimal BuildingTax { get; private set; }
        public decimal BuildingTaxDeduction { get; private set; }
        public decimal LandTax { get; private set; }
        public decimal LandTaxDeduction { get; private set; }
        public decimal TotalPropertyTax { get; private set; }

        // Constructor
        public PropertyTax(string ownerName, int buildingSize, int landSize, int yearBuilt, LocationType whereLocated)
        {
            PropertyOwnerName = ownerName;
            BuildingSquareFootage = buildingSize;
            LandSquareFootage = landSize;
            YearBuilt = yearBuilt;
            PropertyLocation = whereLocated;

            BuildingAge = DateTime.Now.Year - YearBuilt;

            CalcTotalPropertyTax();
        }

        // Private methods for calculations
        private void CalcBuildingTax()
        {
            if (BuildingSquareFootage <= 1000)
            {
                BuildingTax = BuildingSquareFootage * 1.11m;
            }
            else if (BuildingSquareFootage <= 2000)
            {
                BuildingTax = 1110 + (BuildingSquareFootage - 1000) * 1.13m;
            }
            else if (BuildingSquareFootage <= 3000)
            {
                BuildingTax = 2240 + (BuildingSquareFootage - 2000) * 1.15m;
            }
            else if (BuildingSquareFootage <= 4000)
            {
                BuildingTax = 3390 + (BuildingSquareFootage - 3000) * 1.17m;
            }
            else
            {
                BuildingTax = 4560 + (BuildingSquareFootage - 4000) * 1.19m;
            }
        }

        private void CalcBuildingTaxDeduction()
        {
            if (BuildingAge > 15)
            {
                BuildingTaxDeduction = BuildingAge * 0.004m * BuildingTax;
            }
            else
            {
                BuildingTaxDeduction = 0;
            }
        }

        private void CalcLandTax()
        {
            if (LandSquareFootage <= 10000)
            {
                LandTax = LandSquareFootage * 0.12m;
            }
            else if (LandSquareFootage <= 20000)
            {
                LandTax = 1200 + (LandSquareFootage - 10000) * 0.14m;
            }
            else if (LandSquareFootage <= 30000)
            {
                LandTax = 2600 + (LandSquareFootage - 20000) * 0.16m;
            }
            else if (LandSquareFootage <= 40000)
            {
                LandTax = 4200 + (LandSquareFootage - 30000) * 0.18m;
            }
            else
            {
                LandTax = 6000 + (LandSquareFootage - 40000) * 0.20m;
            }
        }

        private void CalcLandTaxDeduction()
        {
            if (PropertyLocation == LocationType.Rural)
            {
                if (LandSquareFootage <= 28000)
                {
                    LandTaxDeduction = LandTax * 0.0375m;
                }
                else
                {
                    LandTaxDeduction = LandTax * 0.0215m;
                }
            }
            else
            {
                LandTaxDeduction = 0;
            }
        }

        private void CalcTotalPropertyTax()
        {
            CalcBuildingTax();
            CalcLandTax();
            CalcBuildingTaxDeduction();
            CalcLandTaxDeduction();
            TotalPropertyTax = BuildingTax + LandTax - BuildingTaxDeduction - LandTaxDeduction;
        }
    }

}
