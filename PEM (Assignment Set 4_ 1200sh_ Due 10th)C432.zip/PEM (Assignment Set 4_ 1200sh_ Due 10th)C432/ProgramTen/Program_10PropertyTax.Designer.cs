// 
// Program_10PropertyTax.Designer.cs
// 

namespace Program_10PropertyTax
{
    partial class Program_10PropertyTax
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        // Input Controls
        private System.Windows.Forms.Label lblOwnerName;
        private System.Windows.Forms.TextBox txtOwnerName;
        private System.Windows.Forms.Label lblBuildingSize;
        private System.Windows.Forms.TextBox txtBuildingSize;
        private System.Windows.Forms.Label lblLandSize;
        private System.Windows.Forms.TextBox txtLandSize;
        private System.Windows.Forms.Label lblYearBuilt;
        private System.Windows.Forms.TextBox txtYearBuilt;
        private System.Windows.Forms.Label lblLocation;
        private System.Windows.Forms.ComboBox cmbLocation;

        // Buttons
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;

        // Output Labels
        private System.Windows.Forms.GroupBox grpResults;
        private System.Windows.Forms.Label lblBuildingAgeLabel;
        private System.Windows.Forms.Label lblBuildingAge;
        private System.Windows.Forms.Label lblBuildingTaxLabel;
        private System.Windows.Forms.Label lblBuildingTax;
        private System.Windows.Forms.Label lblLandTaxLabel;
        private System.Windows.Forms.Label lblLandTax;
        private System.Windows.Forms.Label lblBuildingTaxDeductionLabel;
        private System.Windows.Forms.Label lblBuildingTaxDeduction;
        private System.Windows.Forms.Label lblLandTaxDeductionLabel;
        private System.Windows.Forms.Label lblLandTaxDeduction;
        private System.Windows.Forms.Label lblTotalPropertyTaxLabel;
        private System.Windows.Forms.Label lblTotalPropertyTax;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Method required for Designer support.
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            // Initialize Controls

            // Labels and TextBoxes for Inputs
            this.lblOwnerName = new System.Windows.Forms.Label();
            this.txtOwnerName = new System.Windows.Forms.TextBox();
            this.lblBuildingSize = new System.Windows.Forms.Label();
            this.txtBuildingSize = new System.Windows.Forms.TextBox();
            this.lblLandSize = new System.Windows.Forms.Label();
            this.txtLandSize = new System.Windows.Forms.TextBox();
            this.lblYearBuilt = new System.Windows.Forms.Label();
            this.txtYearBuilt = new System.Windows.Forms.TextBox();
            this.lblLocation = new System.Windows.Forms.Label();
            this.cmbLocation = new System.Windows.Forms.ComboBox();

            // Buttons
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();

            // GroupBox for Results
            this.grpResults = new System.Windows.Forms.GroupBox();
            this.lblBuildingAgeLabel = new System.Windows.Forms.Label();
            this.lblBuildingAge = new System.Windows.Forms.Label();
            this.lblBuildingTaxLabel = new System.Windows.Forms.Label();
            this.lblBuildingTax = new System.Windows.Forms.Label();
            this.lblLandTaxLabel = new System.Windows.Forms.Label();
            this.lblLandTax = new System.Windows.Forms.Label();
            this.lblBuildingTaxDeductionLabel = new System.Windows.Forms.Label();
            this.lblBuildingTaxDeduction = new System.Windows.Forms.Label();
            this.lblLandTaxDeductionLabel = new System.Windows.Forms.Label();
            this.lblLandTaxDeduction = new System.Windows.Forms.Label();
            this.lblTotalPropertyTaxLabel = new System.Windows.Forms.Label();
            this.lblTotalPropertyTax = new System.Windows.Forms.Label();

            // 
            // lblOwnerName
            // 
            this.lblOwnerName.AutoSize = true;
            this.lblOwnerName.Location = new System.Drawing.Point(30, 20);
            this.lblOwnerName.Name = "lblOwnerName";
            this.lblOwnerName.Size = new System.Drawing.Size(116, 17);
            this.lblOwnerName.TabIndex = 0;
            this.lblOwnerName.Text = "Property Owner:";

            // 
            // txtOwnerName
            // 
            this.txtOwnerName.Location = new System.Drawing.Point(180, 17);
            this.txtOwnerName.MaxLength = 30;
            this.txtOwnerName.Name = "txtOwnerName";
            this.txtOwnerName.Size = new System.Drawing.Size(200, 22);
            this.txtOwnerName.TabIndex = 1;

            // 
            // lblBuildingSize
            // 
            this.lblBuildingSize.AutoSize = true;
            this.lblBuildingSize.Location = new System.Drawing.Point(30, 60);
            this.lblBuildingSize.Name = "lblBuildingSize";
            this.lblBuildingSize.Size = new System.Drawing.Size(140, 17);
            this.lblBuildingSize.TabIndex = 2;
            this.lblBuildingSize.Text = "Building Square Foot:";

            // 
            // txtBuildingSize
            // 
            this.txtBuildingSize.Location = new System.Drawing.Point(180, 57);
            this.txtBuildingSize.Name = "txtBuildingSize";
            this.txtBuildingSize.Size = new System.Drawing.Size(200, 22);
            this.txtBuildingSize.TabIndex = 3;

            // 
            // lblLandSize
            // 
            this.lblLandSize.AutoSize = true;
            this.lblLandSize.Location = new System.Drawing.Point(30, 100);
            this.lblLandSize.Name = "lblLandSize";
            this.lblLandSize.Size = new System.Drawing.Size(127, 17);
            this.lblLandSize.TabIndex = 4;
            this.lblLandSize.Text = "Land Square Foot:";

            // 
            // txtLandSize
            // 
            this.txtLandSize.Location = new System.Drawing.Point(180, 97);
            this.txtLandSize.Name = "txtLandSize";
            this.txtLandSize.Size = new System.Drawing.Size(200, 22);
            this.txtLandSize.TabIndex = 5;

            // 
            // lblYearBuilt
            // 
            this.lblYearBuilt.AutoSize = true;
            this.lblYearBuilt.Location = new System.Drawing.Point(30, 140);
            this.lblYearBuilt.Name = "lblYearBuilt";
            this.lblYearBuilt.Size = new System.Drawing.Size(76, 17);
            this.lblYearBuilt.TabIndex = 6;
            this.lblYearBuilt.Text = "Year Built:";

            // 
            // txtYearBuilt
            // 
            this.txtYearBuilt.Location = new System.Drawing.Point(180, 137);
            this.txtYearBuilt.Name = "txtYearBuilt";
            this.txtYearBuilt.Size = new System.Drawing.Size(200, 22);
            this.txtYearBuilt.TabIndex = 7;

            // 
            // lblLocation
            // 
            this.lblLocation.AutoSize = true;
            this.lblLocation.Location = new System.Drawing.Point(30, 180);
            this.lblLocation.Name = "lblLocation";
            this.lblLocation.Size = new System.Drawing.Size(69, 17);
            this.lblLocation.TabIndex = 8;
            this.lblLocation.Text = "Location:";

            // 
            // cmbLocation
            // 
            this.cmbLocation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLocation.FormattingEnabled = true;
            this.cmbLocation.Items.AddRange(new object[] {
            "City",
            "Suburb",
            "Rural"});
            this.cmbLocation.Location = new System.Drawing.Point(180, 177);
            this.cmbLocation.Name = "cmbLocation";
            this.cmbLocation.Size = new System.Drawing.Size(200, 24);
            this.cmbLocation.TabIndex = 9;

            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(30, 220);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(100, 30);
            this.btnCalculate.TabIndex = 10;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);

            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(150, 220);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(100, 30);
            this.btnClear.TabIndex = 11;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);

            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(270, 220);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(100, 30);
            this.btnExit.TabIndex = 12;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);

            // 
            // grpResults
            // 
            this.grpResults.Controls.Add(this.lblBuildingAgeLabel);
            this.grpResults.Controls.Add(this.lblBuildingAge);
            this.grpResults.Controls.Add(this.lblBuildingTaxLabel);
            this.grpResults.Controls.Add(this.lblBuildingTax);
            this.grpResults.Controls.Add(this.lblLandTaxLabel);
            this.grpResults.Controls.Add(this.lblLandTax);
            this.grpResults.Controls.Add(this.lblBuildingTaxDeductionLabel);
            this.grpResults.Controls.Add(this.lblBuildingTaxDeduction);
            this.grpResults.Controls.Add(this.lblLandTaxDeductionLabel);
            this.grpResults.Controls.Add(this.lblLandTaxDeduction);
            this.grpResults.Controls.Add(this.lblTotalPropertyTaxLabel);
            this.grpResults.Controls.Add(this.lblTotalPropertyTax);
            this.grpResults.Location = new System.Drawing.Point(30, 270);
            this.grpResults.Name = "grpResults";
            this.grpResults.Size = new System.Drawing.Size(340, 220);
            this.grpResults.TabIndex = 13;
            this.grpResults.TabStop = false;
            this.grpResults.Text = "Tax Calculation Results";

            // 
            // lblBuildingAgeLabel
            // 
            this.lblBuildingAgeLabel.AutoSize = true;
            this.lblBuildingAgeLabel.Location = new System.Drawing.Point(10, 30);
            this.lblBuildingAgeLabel.Name = "lblBuildingAgeLabel";
            this.lblBuildingAgeLabel.Size = new System.Drawing.Size(93, 17);
            this.lblBuildingAgeLabel.TabIndex = 0;
            this.lblBuildingAgeLabel.Text = "Building Age:";

            // 
            // lblBuildingAge
            // 
            this.lblBuildingAge.AutoSize = true;
            this.lblBuildingAge.Location = new System.Drawing.Point(200, 30);
            this.lblBuildingAge.Name = "lblBuildingAge";
            this.lblBuildingAge.Size = new System.Drawing.Size(0, 17);
            this.lblBuildingAge.TabIndex = 1;

            // 
            // lblBuildingTaxLabel
            // 
            this.lblBuildingTaxLabel.AutoSize = true;
            this.lblBuildingTaxLabel.Location = new System.Drawing.Point(10, 60);
            this.lblBuildingTaxLabel.Name = "lblBuildingTaxLabel";
            this.lblBuildingTaxLabel.Size = new System.Drawing.Size(91, 17);
            this.lblBuildingTaxLabel.TabIndex = 2;
            this.lblBuildingTaxLabel.Text = "Building Tax:";

            // 
            // lblBuildingTax
            // 
            this.lblBuildingTax.AutoSize = true;
            this.lblBuildingTax.Location = new System.Drawing.Point(200, 60);
            this.lblBuildingTax.Name = "lblBuildingTax";
            this.lblBuildingTax.Size = new System.Drawing.Size(0, 17);
            this.lblBuildingTax.TabIndex = 3;

            // 
            // lblLandTaxLabel
            // 
            this.lblLandTaxLabel.AutoSize = true;
            this.lblLandTaxLabel.Location = new System.Drawing.Point(10, 90);
            this.lblLandTaxLabel.Name = "lblLandTaxLabel";
            this.lblLandTaxLabel.Size = new System.Drawing.Size(68, 17);
            this.lblLandTaxLabel.TabIndex = 4;
            this.lblLandTaxLabel.Text = "Land Tax:";

            // 
            // lblLandTax
            // 
            this.lblLandTax.AutoSize = true;
            this.lblLandTax.Location = new System.Drawing.Point(200, 90);
            this.lblLandTax.Name = "lblLandTax";
            this.lblLandTax.Size = new System.Drawing.Size(0, 17);
            this.lblLandTax.TabIndex = 5;

            // 
            // lblBuildingTaxDeductionLabel
            // 
            this.lblBuildingTaxDeductionLabel.AutoSize = true;
            this.lblBuildingTaxDeductionLabel.Location = new System.Drawing.Point(10, 120);
            this.lblBuildingTaxDeductionLabel.Name = "lblBuildingTaxDeductionLabel";
            this.lblBuildingTaxDeductionLabel.Size = new System.Drawing.Size(168, 17);
            this.lblBuildingTaxDeductionLabel.TabIndex = 6;
            this.lblBuildingTaxDeductionLabel.Text = "Building Tax Deduction:";

            // 
            // lblBuildingTaxDeduction
            // 
            this.lblBuildingTaxDeduction.AutoSize = true;
            this.lblBuildingTaxDeduction.Location = new System.Drawing.Point(200, 120);
            this.lblBuildingTaxDeduction.Name = "lblBuildingTaxDeduction";
            this.lblBuildingTaxDeduction.Size = new System.Drawing.Size(0, 17);
            this.lblBuildingTaxDeduction.TabIndex = 7;

            // 
            // lblLandTaxDeductionLabel
            // 
            this.lblLandTaxDeductionLabel.AutoSize = true;
            this.lblLandTaxDeductionLabel.Location = new System.Drawing.Point(10, 150);
            this.lblLandTaxDeductionLabel.Name = "lblLandTaxDeductionLabel";
            this.lblLandTaxDeductionLabel.Size = new System.Drawing.Size(152, 17);
            this.lblLandTaxDeductionLabel.TabIndex = 8;
            this.lblLandTaxDeductionLabel.Text = "Land Tax Deduction:";

            // 
            // lblLandTaxDeduction
            // 
            this.lblLandTaxDeduction.AutoSize = true;
            this.lblLandTaxDeduction.Location = new System.Drawing.Point(200, 150);
            this.lblLandTaxDeduction.Name = "lblLandTaxDeduction";
            this.lblLandTaxDeduction.Size = new System.Drawing.Size(0, 17);
            this.lblLandTaxDeduction.TabIndex = 9;

            // 
            // lblTotalPropertyTaxLabel
            // 
            this.lblTotalPropertyTaxLabel.AutoSize = true;
            this.lblTotalPropertyTaxLabel.Location = new System.Drawing.Point(10, 180);
            this.lblTotalPropertyTaxLabel.Name = "lblTotalPropertyTaxLabel";
            this.lblTotalPropertyTaxLabel.Size = new System.Drawing.Size(129, 17);
            this.lblTotalPropertyTaxLabel.TabIndex = 10;
            this.lblTotalPropertyTaxLabel.Text = "Total Property Tax:";

            // 
            // lblTotalPropertyTax
            // 
            this.lblTotalPropertyTax.AutoSize = true;
            this.lblTotalPropertyTax.Location = new System.Drawing.Point(200, 180);
            this.lblTotalPropertyTax.Name = "lblTotalPropertyTax";
            this.lblTotalPropertyTax.Size = new System.Drawing.Size(0, 17);
            this.lblTotalPropertyTax.TabIndex = 11;

            // 
            // Program_10PropertyTax
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 510);
            this.Controls.Add(this.grpResults);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.cmbLocation);
            this.Controls.Add(this.lblLocation);
            this.Controls.Add(this.txtYearBuilt);
            this.Controls.Add(this.lblYearBuilt);
            this.Controls.Add(this.txtLandSize);
            this.Controls.Add(this.lblLandSize);
            this.Controls.Add(this.txtBuildingSize);
            this.Controls.Add(this.lblBuildingSize);
            this.Controls.Add(this.txtOwnerName);
            this.Controls.Add(this.lblOwnerName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Program_10PropertyTax";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Property Tax Calculator";

            // Add Controls to GroupBox
            this.grpResults.ResumeLayout(false);
            this.grpResults.PerformLayout();

            // Add GroupBox and other controls to Form
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}
