class Student:
    def __init__(self, name, student_id, major):
        self.name = name
        self.student_id = student_id
        self.major = major

class Course:
    def __init__(self, code, name, professor):
        self.code = code
        self.name = name
        self.professor = professor

class Enrollment:
    def __init__(self, student, course):
        self.student = student
        self.course = course

class UniversitySystem:
    def __init__(self):
        self.students = []
        self.courses = []
        self.enrollments = []

    def add_student(self, name, student_id, major):
        student = Student(name, student_id, major)
        self.students.append(student)

    def add_course(self, code, name, professor):
        course = Course(code, name, professor)
        self.courses.append(course)

    def enroll_student(self, student_id, course_code):
        student = next((student for student in self.students if student.student_id == student_id), None)
        course = next((course for course in self.courses if course.code == course_code), None)
        if student and course:
            enrollment = Enrollment(student, course)
            self.enrollments.append(enrollment)
        else:
            print("Error: Student or course not found.")

    def get_student_transcript(self, student_id):
        student = next((student for student in self.students if student.student_id == student_id), None)
        if student:
            student_transcript = []
            for enrollment in self.enrollments:
                if enrollment.student == student:
                    student_transcript.append({'course': enrollment.course.name, 'grade': 'A'})
            return student_transcript
        else:
            print("Error: Student not found.")

# Example of usage
university_system = UniversitySystem()

university_system.add_student("John Doe", "12345", "Computer Science")
university_system.add_student("Jane Smith", "67890", "Electrical Engineering")

university_system.add_course("CS101", "Introduction to Computer Science", "Prof. Smith")
university_system.add_course("EE201", "Circuits and Electronics", "Prof. Johnson")

university_system.enroll_student("12345", "CS101")
university_system.enroll_student("67890", "CS101")
university_system.enroll_student("67890", "EE201")

transcript_john = university_system.get_student_transcript("12345")
transcript_jane = university_system.get_student_transcript("67890")

print(transcript_john)
print(transcript_jane)

