class DatabaseConnector:

    def connect(self, database_url):
        print(f"Connected to the database: {database_url}")


class DataStorage:

    def __init__(self, connector):
        self.connector = connector

    def save_data(self, data):
        print(f"Data saved to the storage: {data}")
        # Save data logic goes here
        self.connector.connect("example_database")


class DataAnalyzer:

    def __init__(self, storage):
        self.storage = storage

    def analyze_data(self, data):
        print("Analyzing data...")
        self.storage.save_data(data)
        # Analysis logic goes here


# Usage
connector = DatabaseConnector()
storage = DataStorage(connector)
analyzer = DataAnalyzer(storage)
analyzer.analyze_data("Complex data analysis result")
