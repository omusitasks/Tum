public class DatabaseConnector {

    public void connect(String databaseUrl) {
        System.out.println("Connected to the database: " + databaseUrl);
    }
}

public class DataStorage {

    private final DatabaseConnector connector;

    public DataStorage(DatabaseConnector connector) {
        this.connector = connector;
    }

    public void saveData(String data) {
        System.out.println("Data saved to the storage: " + data);
        // Save data logic goes here
        connector.connect("example_database");
    }
}

public class DataAnalyzer {

    private final DataStorage storage;

    public DataAnalyzer() {
        this.storage = new DataStorage(new DatabaseConnector());
    }

    public void analyzeData(String data) {
        System.out.println("Analyzing data...");
        storage.saveData(data);
        // Analysis logic goes here
    }

    public static void main(String[] args) {
        DataAnalyzer analyzer = new DataAnalyzer();
        analyzer.analyzeData("Complex data analysis result");
    }
}
