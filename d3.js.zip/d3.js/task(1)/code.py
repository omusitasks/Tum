import pandas as pd
from sklearn.cluster import KMeans

# Load the dataset
data = pd.read_csv('cars_dataset.csv')

# Select the columns for clustering
columns_for_clustering = ['MPG', 'Cylinders', 'Weight', 'Acceleration']
X = data[columns_for_clustering]

# Perform K-means clustering with 4 clusters
kmeans = KMeans(n_clusters=4, random_state=42)
data['Cluster'] = kmeans.fit_predict(X)

# Export the clustered data to a new CSV file
data.to_csv('clustered_cars.csv', index=False)

# Printing count in each cluster
cluster_counts = data['Cluster'].value_counts()
print(cluster_counts)
