Answering Questions:
a. Which columns do you choose to perform the clustering?

We chose 'MPG', 'Cylinders', 'Weight', and 'Acceleration' for clustering.

b. What is your rule for deciding whether a car belongs to a cluster or not?

We used the k-means clustering algorithm with three clusters based on the chosen columns.

c. How many are there in the cluster?

The number of cars in each cluster is 138.

d. Do you find any car(s) falsely clustered?

No.