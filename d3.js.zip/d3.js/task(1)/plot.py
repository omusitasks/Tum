import pandas as pd
import matplotlib.pyplot as plt
import mpld3
from mpld3 import plugins
from io import BytesIO

# Function to fetch data from CSV
def fetch_data():
    try:
        url = 'clustered_cars.csv'
        data = pd.read_csv(url)
        return data
    except Exception as e:
        print('Error fetching data:', str(e))
        return None

# Draw chart with fetched data
def draw_chart(data):
    if data is None:
        return
    
    cluster0 = data[data['Cluster'] == 0]
    cluster1 = data[data['Cluster'] == 1]
    cluster2 = data[data['Cluster'] == 2]
    
    fig, ax = plt.subplots()
    scatter0 = ax.scatter(cluster0['MPG'], cluster0['Weight'], label='Cluster 0', color='red', alpha=0.5)
    scatter1 = ax.scatter(cluster1['MPG'], cluster1['Weight'], label='Cluster 1', color='blue', alpha=0.5)
    scatter2 = ax.scatter(cluster2['MPG'], cluster2['Weight'], label='Cluster 2', color='yellow', alpha=0.5)

    ax.set_xlabel('MPG')
    ax.set_ylabel('Weight')
    ax.set_title('Cars Clustering Visualization')
    ax.legend()

    # Use multiple columns for tooltips
    tooltip0 = plugins.PointHTMLTooltip(scatter0, labels=format_tooltip(cluster0), voffset=10, hoffset=10)
    tooltip1 = plugins.PointHTMLTooltip(scatter1, labels=format_tooltip(cluster1), voffset=10, hoffset=10)
    tooltip2 = plugins.PointHTMLTooltip(scatter2, labels=format_tooltip(cluster2), voffset=10, hoffset=10)

    plugins.connect(fig, tooltip0, tooltip1, tooltip2)

    html_fig = mpld3.fig_to_html(fig)

    with open('cars_clustering_visualization.html', 'w') as f:
        f.write(html_fig)

# Format tooltip
def format_tooltip(cluster):
    tooltip_labels = []
    for index, row in cluster.iterrows():
        tooltip_labels.append(f"<b>Model:</b> {row['Model']}<br>"
                              f"<b>Cylinders:</b> {row['Cylinders']}<br>"
                              f"<b>Displacement:</b> {row['Displacement']}<br>"
                              f"<b>Horsepower:</b> {row['Horsepower']}<br>"
                              f"<b>Weight:</b> {row['Weight']}<br>"
                              f"<b>Acceleration:</b> {row['Acceleration']}<br>"
                              f"<b>Year:</b> {row['Year']}<br>"
                              f"<b>Origin:</b> {row['Origin']}<br>"
                              )
    return tooltip_labels

# Main function
def main():
    data = fetch_data()
    draw_chart(data)

if __name__ == "__main__":
    main()
