
"""FA24_Assignment3_Pandas.ipynb


import pandas as pd
# read finance data from csv
finance_data = pd.read_csv('/content/drive/MyDrive/Colab Notebooks/finance_data.csv')
# read text data from csv
text_data = pd.read_csv('/content/drive/MyDrive/Colab Notebooks/text_data.csv')

# look at the data sample
finance_data.head()
text_data.head()

"""**Question 1: If a row in finance_data has null sic_two_digit, that means the financial data could not be effectively extracted from the database. Write code to remove the rows in finance_data if sic_two_digit is null.**

**Question 2: After we describe the data, we notice that the revenue column has remaining null values. Write code to fill the null values in revenue with the average of non-null revenue values.**

**Question 3: After further examination of the data, we find that there is a wrong entry in the ticker column. Write code to replace the ticker which equals 'BFB' to 'BF.B' in text_data.**

**Question 4: Write code to identify the row(s) in text_data whose ticker is not in finance_data.**

**Question 5: Write code to merge finance_data and text_data on three columns: ticker, year, and quarter. Name the merged DataFrame "merged_data".**

*Hint: If two rows in finance_data and text_data have equal values on all of the three fields (i.e., ticker, year, and quarter), we merge the rows.*

**Question 6: Write code to count the number of rows for each unique sic_two_digit in merged_data**

**Question 7: Add a new column labeled as industry to merged_data. If sic_two_digit is 36, industry equals 'Electronics'. If sic_two_digit is 28, industry equals 'Chemicals'. If sic_two_digit is 73, industry is 'Business Services'. For other sic_two_digit values, industry is 'Others'**

**Question 8: Write code to answer the following question: for each industry (i.e., Electronics, Chemicals, Business Services and Others), what is the average revenue and average total_word_count?**

**Question 9: Write code to answer the following question: what is the correlation between a company's return on asset and its compound sentiment score?**

*Hint: Return on asset is net income divided by total assets.*

**Question 10: Plot a scatter plot with return on asset and compound sentiment score on the x-axis and y-axis, respectively. Explain the pattern that you see in the plot.**
"""