import pandas as pd

# Historical Sales Data
sales_data = {
    'Month': ['Jan-2023', 'Jan-2023', 'Jan-2023', 'Feb-2023', 'Feb-2023', 'Feb-2023', 'Mar-2023', 'Mar-2023', 'Mar-2023', 'Apr-2023', 'Apr-2023', 'Apr-2023', 'May-2023', 'May-2023', 'May-2023', 'Jun-2023', 'Jun-2023', 'Jun-2023', 'Jul-2023', 'Jul-2023', 'Jul-2023', 'Aug-2023', 'Aug-2023', 'Aug-2023', 'Sep-2023', 'Sep-2023', 'Sep-2023', 'Oct-2023', 'Oct-2023', 'Oct-2023', 'Nov-2023', 'Nov-2023', 'Nov-2023', 'Dec-2023', 'Dec-2023', 'Dec-2023'],
    'Product Category': ['Apparel', 'Footwear', 'Equipment', 'Apparel', 'Footwear', 'Equipment', 'Apparel', 'Footwear', 'Equipment', 'Apparel', 'Footwear', 'Equipment', 'Apparel', 'Footwear', 'Equipment', 'Apparel', 'Footwear', 'Equipment', 'Apparel', 'Footwear', 'Equipment', 'Apparel', 'Footwear', 'Equipment', 'Apparel', 'Footwear', 'Equipment', 'Apparel', 'Footwear', 'Equipment', 'Apparel', 'Footwear', 'Equipment', 'Apparel', 'Footwear', 'Equipment'],
    'Brand': ['Nike', 'Adidas', 'Wilson', 'Under Armour', 'New Balance', 'Spalding', 'The North Face', 'Brooks', 'Rawlings', 'Columbia', 'Asics', 'Easton', 'Patagonia', 'Saucony', 'Marucci', "Arc'teryx", 'Hoka One One', 'Mizuno', 'Outdoor Research', 'Altra', 'Louisville Slugger', 'Mountain Hardwear', 'On Running', 'DeMarini', 'Marmot', 'Salomon', 'Victrix', 'Patagonia', 'Hoka One One', 'Easton', 'The North Face', 'Brooks', 'Rawlings', 'Columbia', 'Asics', 'Spalding'],
    'Store Location': ['Chicago', 'New York', 'Los Angeles', 'Chicago', 'New York', 'Los Angeles', 'Chicago', 'New York', 'Los Angeles', 'Chicago', 'New York', 'Los Angeles', 'Chicago', 'New York', 'Los Angeles', 'Chicago', 'New York', 'Los Angeles', 'Chicago', 'New York', 'Los Angeles', 'Chicago', 'New York', 'Los Angeles', 'Chicago', 'New York', 'Los Angeles', 'Chicago', 'New York', 'Los Angeles', 'Chicago', 'New York', 'Los Angeles', 'Chicago', 'New York', 'Los Angeles'],
    'Units Sold': [120, 80, 50, 100, 75, 40, 85, 60, 35, 110, 90, 65, 70, 55, 42, 95, 82, 58, 68, 48, 30, 102, 79, 61, 80, 65, 45, 98, 87, 62, 115, 92, 70, 89, 71, 53]
}
sales_df = pd.DataFrame(sales_data)
sales_df.to_csv('C:/Users/omusi/Downloads/tum/August/Case Study Analysis -Whatsapp/historical_sales_data.csv', index=False)

# Inventory Data By Product
inventory_data = {
    'Product ID': ['ABC001', 'ABC002', 'ABC003', 'ABC004', 'ABC005', 'ABC006', 'ABC007', 'ABC008', 'ABC009', 'ABC010', 'ABC011', 'ABC012', 'ABC013', 'ABC014', 'ABC015', 'ABC016', 'ABC017', 'ABC018', 'ABC019', 'ABC020'],
    'Product Name': ["Running Shoes (Men's)", 'Tennis Racket', 'Baseball Jersey (Youth)', "Yoga Pants (Women's)", "Basketball (Men's)", "Sports Bra (Women's)", 'Baseball Bat (Aluminum)', 'Baseball Glove (Youth)', 'Soccer Ball', 'Yoga Mat', 'Water Bottle (Stainless Steel)', "Running Shorts (Men's)", 'Tennis Balls (Can)', 'Badminton Racket', 'Fitness Tracker', 'Hiking Backpack', 'Camping Tent', 'Sleeping Bag', 'Bicycle Helmet', 'Bicycle (Adult)'],
    'Units on Hand': [25, 10, 40, 15, 32, 20, 18, 25, 48, 12, 35, 17, 85, 6, 22, 10, 5, 8, 14, 3],
    'Purchase Price': ['$75.00', '$120.00', '$25.00', '$40.00', '$85.00', '$30.00', '$55.00', '$22.00', '$38.00', '$45.00', '$15.00', '$28.00', '$5.00', '$60.00', '$99.00', '$130.00', '$180.00', '$125.00', '$50.00', '$450.00'],
    'Lead Time (Days)': [30, 45, 20, 15, 40, 25, 35, 15, 20, 10, 20, 18, 15, 40, 30, 50, 60, 45, 25, 90]
}
inventory_df = pd.DataFrame(inventory_data)
inventory_df.to_csv('C:/Users/omusi/Downloads/tum/August/Case Study Analysis -Whatsapp/inventory_data_by_product.csv', index=False)

# Customer Demographics
customer_data = {
    'Customer ID': ['CUST021', 'CUST022', 'CUST023', 'CUST024', 'CUST025', 'CUST026', 'CUST027', 'CUST028', 'CUST029', 'CUST030'],
    'Age': [65, 33, 19, 48, 27, 70, 52, 14, 31, 20],
    'Location': ['Seattle', 'Miami', 'Atlanta', 'Dallas', 'San Francisco', 'Houston', 'Phoenix', 'Austin', 'Denver', 'Boston'],
    'Gender': ['Male', 'Female', 'Male', 'Female', 'Male', 'Male', 'Female', 'Male', 'Female', 'Male'],
    'Purchase History': [
        'Golf Clubs (Senior Flex), Golf Balls',
        "Running Shoes (Women's), Fitness Tracker",
        "Basketball (Men's), Basketball Shorts",
        'Tennis Apparel, Tennis Racket',
        'Baseball Bat (Composite), Baseball Cleats',
        'Walking Shoes, Comfortable Clothing',
        'Yoga Mat, Resistance Bands (Light)',
        'Baseball Jersey (Youth), Baseball Hat',
        'Hiking Boots, Backpack',
        'Bicycle (Adult), Bicycle Helmet, Cycling Shorts'
    ]
}
customer_df = pd.DataFrame(customer_data)
customer_df.to_csv('C:/Users/omusi/Downloads/tum/August/Case Study Analysis -Whatsapp/customer_demographics.csv', index=False)

# Paths to exported CSV files
print("Historical Sales Data exported to: C:/Users/omusi/Downloads/tum/August/Case Study Analysis -Whatsapp/historical_sales_data.csv")
print("Inventory Data By Product exported to: C:/Users/omusi/Downloads/tum/August/Case Study Analysis -Whatsapp/inventory_data_by_product.csv")
print("Customer Demographics exported to: C:/Users/omusi/Downloads/tum/August/Case Study Analysis -Whatsapp/customer_demographics.csv")
