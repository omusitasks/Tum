-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2024 at 08:17 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tumabc`
--

-- --------------------------------------------------------

--
-- Table structure for table `historical_sales_data`
--

CREATE TABLE `historical_sales_data` (
  `Month` varchar(8) DEFAULT NULL,
  `Product_Category` varchar(9) DEFAULT NULL,
  `Brand` varchar(18) DEFAULT NULL,
  `Store_Location` varchar(11) DEFAULT NULL,
  `Units_Sold` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `historical_sales_data`
--

INSERT INTO `historical_sales_data` (`Month`, `Product_Category`, `Store_Location`, `Total_Units_Sold`) VALUES
('Apr-2023', 'Apparel', 'Chicago', 110),
('Apr-2023', 'Equipment', 'Los Angeles', 65),
('Apr-2023', 'Footwear', 'New York', 90),
('Aug-2023', 'Apparel', 'Chicago', 102),
('Aug-2023', 'Equipment', 'Los Angeles', 61),
('Aug-2023', 'Footwear', 'New York', 79),
('Dec-2023', 'Apparel', 'Chicago', 89),
('Dec-2023', 'Equipment', 'Los Angeles', 53),
('Dec-2023', 'Footwear', 'New York', 71),
('Feb-2023', 'Apparel', 'Chicago', 100),
('Feb-2023', 'Equipment', 'Los Angeles', 40),
('Feb-2023', 'Footwear', 'New York', 75),
('Jan-2023', 'Apparel', 'Chicago', 120),
('Jan-2023', 'Equipment', 'Los Angeles', 50),
('Jan-2023', 'Footwear', 'New York', 80),
('Jul-2023', 'Apparel', 'Chicago', 68),
('Jul-2023', 'Equipment', 'Los Angeles', 30),
('Jul-2023', 'Footwear', 'New York', 48),
('Jun-2023', 'Apparel', 'Chicago', 95),
('Jun-2023', 'Equipment', 'Los Angeles', 58),
('Jun-2023', 'Footwear', 'New York', 82),
('Mar-2023', 'Apparel', 'Chicago', 85),
('Mar-2023', 'Equipment', 'Los Angeles', 35),
('Mar-2023', 'Footwear', 'New York', 60),
('May-2023', 'Apparel', 'Chicago', 70),
('May-2023', 'Equipment', 'Los Angeles', 42),
('May-2023', 'Footwear', 'New York', 55),
('Nov-2023', 'Apparel', 'Chicago', 115),
('Nov-2023', 'Equipment', 'Los Angeles', 70),
('Nov-2023', 'Footwear', 'New York', 92),
('Oct-2023', 'Apparel', 'Chicago', 98),
('Oct-2023', 'Equipment', 'Los Angeles', 62),
('Oct-2023', 'Footwear', 'New York', 87),
('Sep-2023', 'Apparel', 'Chicago', 80),
('Sep-2023', 'Equipment', 'Los Angeles', 45),
('Sep-2023', 'Footwear', 'New York', 65);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
