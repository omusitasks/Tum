-- Step 1: Analyze Historical Sales Data

-- SQL Query to analyze monthly sales by product category and store location:

SELECT 
    Month, 
    Product_Category, 
    Store_Location, 
    SUM(Units_Sold) AS Total_Units_Sold
FROM 
    historical_sales_data
GROUP BY 
    Month, Product_Category, Store_Location
ORDER BY 
    Month, Product_Category, Store_Location;


-- SQL Query to get current inventory levels and lead times:

SELECT 
    Product_ID, 
    Product_Name, 
    Units_on_Hand, 
    Lead_Time
FROM 
    inventory_data_by_product;

-- SQL Query to get customer demographics and their purchase history:

SELECT 
    Customer_ID, 
    Age, 
    Location, 
    Gender, 
    Purchase_History
FROM 
    customer_demographics;


-- Monthly Sales Trend by Product Category:

SELECT 
    Month, 
    Product_Category, 
    SUM(Units_Sold) AS Total_Units_Sold
FROM 
    historical_sales_data
GROUP BY 
    Month, Product_Category
ORDER BY 
    Month, Product_Category;


-- Inventory Levels by Product:

SELECT 
    Product_ID, 
    Product_Name, 
    Units_on_Hand, 
    Lead_Time_Days
FROM 
    inventory_data_by_product;


-- Customer Demographics and Purchase History:

SELECT 
    Age, 
    Gender, 
    COUNT(Customer_ID) AS Total_Customers
FROM 
    customer_demographics
GROUP BY 
    Age, Gender
ORDER BY 
    Age, Gender;


-- 1. Here we Check for Missing Values
-- Customer Demographics Data:

SELECT 
    COUNT(*) AS Total_Records,
    SUM(CASE WHEN Customer_ID IS NULL THEN 1 ELSE 0 END) AS Missing_Customer_ID,
    SUM(CASE WHEN Age IS NULL THEN 1 ELSE 0 END) AS Missing_Age,
    SUM(CASE WHEN Location IS NULL THEN 1 ELSE 0 END) AS Missing_Location,
    SUM(CASE WHEN Gender IS NULL THEN 1 ELSE 0 END) AS Missing_Gender,
    SUM(CASE WHEN Purchase_History IS NULL THEN 1 ELSE 0 END) AS Missing_Purchase_History
FROM 
    customer_demographics;

-- 0 MISSING VALUES 

-- Historical Sales Data:
SELECT 
    COUNT(*) AS Total_Records,
    SUM(CASE WHEN Month IS NULL THEN 1 ELSE 0 END) AS Missing_Month,
    SUM(CASE WHEN Product_Category IS NULL THEN 1 ELSE 0 END) AS Missing_Product_Category,
    SUM(CASE WHEN Brand IS NULL THEN 1 ELSE 0 END) AS Missing_Brand,
    SUM(CASE WHEN Store_Location IS NULL THEN 1 ELSE 0 END) AS Missing_Store_Location,
    SUM(CASE WHEN Units_Sold IS NULL THEN 1 ELSE 0 END) AS Missing_Units_Sold
FROM 
    historical_sales_data;
--  0 MISSING VALUES


-- Inventory Data:
SELECT 
    COUNT(*) AS Total_Records,
    SUM(CASE WHEN Product_ID IS NULL THEN 1 ELSE 0 END) AS Missing_Product_ID,
    SUM(CASE WHEN Product_Name IS NULL THEN 1 ELSE 0 END) AS Missing_Product_Name,
    SUM(CASE WHEN Units_on_Hand IS NULL THEN 1 ELSE 0 END) AS Missing_Units_on_Hand,
    SUM(CASE WHEN Purchase_Price IS NULL THEN 1 ELSE 0 END) AS Missing_Purchase_Price,
    SUM(CASE WHEN Lead_Time_Days IS NULL THEN 1 ELSE 0 END) AS Missing_Lead_Time_Days
FROM 
    inventory_data_by_product;
-- 0 MISSING VALUES


-- 2. Lets' Check for Inconsistent Values
-- Customer Demographics Data:

-- Inconsistent Age Values:
SELECT 
    Customer_ID, 
    Age
FROM 
    customer_demographics
WHERE 
    Age < 0 OR Age > 120;

-- Inconsistent Gender Values:
SELECT 
    DISTINCT Gender
FROM 
    customer_demographics
WHERE 
    Gender NOT IN ('Male', 'Female', 'Other');


-- Historical Sales Data:

-- Inconsistent Month Format:
SELECT 
    DISTINCT Month
FROM 
    historical_sales_data
WHERE 
    Month NOT LIKE '%-%';


-- Negative Units Sold:
SELECT 
    Month, 
    Product_Category, 
    Brand, 
    Store_Location, 
    Units_Sold
FROM 
    historical_sales_data
WHERE 
    Units_Sold < 0;


-- Inventory Data:

-- Negative Units on Hand:
SELECT 
    Product_ID, 
    Product_Name, 
    Units_on_Hand
FROM 
    inventory_data_by_product
WHERE 
    Units_on_Hand < 0;


-- 3. Check for Duplicate Records
-- Customer Demographics Data:
SELECT 
    Customer_ID, 
    COUNT(*) AS Duplicate_Count
FROM 
    customer_demographics
GROUP BY 
    Customer_ID
HAVING 
    COUNT(*) > 1;


-- Historical Sales Data:
SELECT 
    Month, 
    Product_Category, 
    Brand, 
    Store_Location, 
    COUNT(*) AS Duplicate_Count
FROM 
    historical_sales_data
GROUP BY 
    Month, Product_Category, Brand, Store_Location
HAVING 
    COUNT(*) > 1;


-- Inventory Data:
SELECT 
    Product_ID, 
    COUNT(*) AS Duplicate_Count
FROM 
    inventory_data_by_product
GROUP BY 
    Product_ID
HAVING 
    COUNT(*) > 1;

