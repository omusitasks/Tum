﻿
/*
 * Project:         Program 1
 * Date Created:    August 2024
 * Last Modified:   August 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      MyFavorites
 * Description:     Static class containing methods that return favorite items.
 */

using System;

namespace Program_1
{
    /// <summary>
    /// Static class that provides methods to return favorite items.
    /// </summary>
    public static class MyFavorites
    {
        /// <summary>
        /// Returns the developer's favorite quote.
        /// </summary>
        /// <returns>A string containing the favorite quote.</returns>
        public static string DisplayFavoriteQuote()
        {
            return "The only way to do great work is to love what you do. - Steve Jobs";
        }

        /// <summary>
        /// Returns the developer's favorite song.
        /// </summary>
        /// <returns>A string containing the favorite song.</returns>
        public static string DisplayFavoriteSong()
        {
            return "\"Imagine\" by John Lennon";
        }

        /// <summary>
        /// Returns the developer's favorite food.
        /// </summary>
        /// <returns>A string containing the favorite food.</returns>
        public static string DisplayFavoriteFood()
        {
            return "Sushi";
        }
    }
}










/*
 * Project:         Module 1; Example 2
 * Date:            August 2024
 * Developed By:    LV
 * Class Name:      Abacus
 * Description:     Business Logic class for a simple calculator
 * Purpose:         Demonstrate examples of methods
*/

//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Program_1
//{
//    static class MyFavorites
//    {
//        // Add two numbers and return the result

//        public static int Add(int num1, int num2)
//        {
//            return num1 + num2;
//        }

//        // Subtract one number from another and return the result

//        public static int Subtract(int num1, int num2)
//        {
//            return num1 - num2;
//        }

//        // Multiply two numbers and return the result

//        public static int Multiply(int num1, int num2)
//        {
//            return num1 * num2;
//        }
//    }
//}
