﻿namespace Program_1
{
    partial class Program_1MyFavorites
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Cleans up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Method required for Designer support - do not modify the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblDisplay = new System.Windows.Forms.Label();
            this.btnQuote = new System.Windows.Forms.Button();
            this.btnSong = new System.Windows.Forms.Button();
            this.btnFood = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblDeveloper = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(120, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(160, 37);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Thandra's Favorites";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDisplay
            // 
            this.lblDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDisplay.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblDisplay.Location = new System.Drawing.Point(30, 80);
            this.lblDisplay.Name = "lblDisplay";
            this.lblDisplay.Size = new System.Drawing.Size(340, 100);
            this.lblDisplay.TabIndex = 1;
            this.lblDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnQuote
            // 
            this.btnQuote.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnQuote.Location = new System.Drawing.Point(30, 200);
            this.btnQuote.Name = "btnQuote";
            this.btnQuote.Size = new System.Drawing.Size(100, 40);
            this.btnQuote.TabIndex = 2;
            this.btnQuote.Text = "Quote";
            this.btnQuote.UseVisualStyleBackColor = true;
            this.btnQuote.Click += new System.EventHandler(this.btnQuote_Click);
            // 
            // btnSong
            // 
            this.btnSong.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnSong.Location = new System.Drawing.Point(150, 200);
            this.btnSong.Name = "btnSong";
            this.btnSong.Size = new System.Drawing.Size(100, 40);
            this.btnSong.TabIndex = 3;
            this.btnSong.Text = "Song";
            this.btnSong.UseVisualStyleBackColor = true;
            this.btnSong.Click += new System.EventHandler(this.btnSong_Click);
            // 
            // btnFood
            // 
            this.btnFood.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnFood.Location = new System.Drawing.Point(270, 200);
            this.btnFood.Name = "btnFood";
            this.btnFood.Size = new System.Drawing.Size(100, 40);
            this.btnFood.TabIndex = 4;
            this.btnFood.Text = "Food";
            this.btnFood.UseVisualStyleBackColor = true;
            this.btnFood.Click += new System.EventHandler(this.btnFood_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnExit.Location = new System.Drawing.Point(150, 260);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(100, 40);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblDeveloper
            // 
            this.lblDeveloper.AutoSize = true;
            this.lblDeveloper.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblDeveloper.Location = new System.Drawing.Point(130, 320);
            this.lblDeveloper.Name = "lblDeveloper";
            this.lblDeveloper.Size = new System.Drawing.Size(140, 23);
            this.lblDeveloper.TabIndex = 6;
            this.lblDeveloper.Text = "Developed by Pragnya Thandra";
            this.lblDeveloper.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Program_1MyFavorites
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(400, 360);
            this.Controls.Add(this.lblDeveloper);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnFood);
            this.Controls.Add(this.btnSong);
            this.Controls.Add(this.btnQuote);
            this.Controls.Add(this.lblDisplay);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Program_1MyFavorites";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thandra's Favorites";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblDisplay;
        private System.Windows.Forms.Button btnQuote;
        private System.Windows.Forms.Button btnSong;
        private System.Windows.Forms.Button btnFood;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblDeveloper;
    }
}
