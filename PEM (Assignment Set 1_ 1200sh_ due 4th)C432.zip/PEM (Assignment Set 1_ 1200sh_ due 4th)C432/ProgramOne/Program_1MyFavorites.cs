﻿
/*
 * Project:         Program 1
 * Date Created:    August 2024
 * Last Modified:   August 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      Program_1MyFavorites
 * Description:     Presentation Layer class that displays favorite items using methods from MyFavorites class.
 */

using System;
using System.Windows.Forms;

namespace Program_1
{
    /// <summary>
    /// Form class that interacts with the user to display favorite items.
    /// </summary>
    public partial class Program_1MyFavorites : Form
    {
        /// <summary>
        /// Initializes a new instance of the Program_1MyFavorites class.
        /// </summary>
        public Program_1MyFavorites()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the Click event of btnQuote to display the favorite quote.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">An EventArgs that contains no event data.</param>
        private void btnQuote_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = MyFavorites.DisplayFavoriteQuote();
        }

        /// <summary>
        /// Handles the Click event of btnSong to display the favorite song.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">An EventArgs that contains no event data.</param>
        private void btnSong_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = MyFavorites.DisplayFavoriteSong();
        }

        /// <summary>
        /// Handles the Click event of btnFood to display the favorite food.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">An EventArgs that contains no event data.</param>
        private void btnFood_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = MyFavorites.DisplayFavoriteFood();
        }

        /// <summary>
        /// Handles the Click event of btnExit to close the form.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">An EventArgs that contains no event data.</param>
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}






