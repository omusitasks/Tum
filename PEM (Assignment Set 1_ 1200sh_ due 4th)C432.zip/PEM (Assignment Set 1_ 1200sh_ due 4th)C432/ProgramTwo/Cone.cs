﻿/*
 * Project:         Program 2
 * Date Created:    August 2024
 * Last Modified:   August 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      Cone
 * Description:     Static class containing methods for cone calculations.
 */

using System;

namespace Program_2
{
    /// <summary>
    /// Static class that provides methods for calculating the surface area and volume of a cone.
    /// </summary>
    public static class Cone
    {
        /// <summary>
        /// Calculates the surface area of a cone given its radius and height.
        /// </summary>
        /// <param name="radius">The radius of the cone's base.</param>
        /// <param name="height">The height of the cone.</param>
        /// <returns>The surface area of the cone.</returns>
        public static double CalculateArea(int radius, int height)
        {
            return Math.PI * radius * (radius + Math.Sqrt(Math.Pow(radius, 2) + Math.Pow(height, 2)));
        }

        /// <summary>
        /// Calculates the volume of a cone given its radius and height.
        /// </summary>
        /// <param name="radius">The radius of the cone's base.</param>
        /// <param name="height">The height of the cone.</param>
        /// <returns>The volume of the cone.</returns>
        public static double CalculateVolume(int radius, int height)
        {
            return (1.0 / 3.0) * Math.PI * Math.Pow(radius, 2) * height;
        }
    }
}
