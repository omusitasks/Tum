﻿/*
 * Project:         Program 2
 * Date Created:    August 2024
 * Last Modified:   August 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      Program_2Cone
 * Description:     Presentation Layer class that interacts with the user to calculate cone area and volume.
 */

using System;
using System.Windows.Forms;

namespace Program_2
{
    /// <summary>
    /// Form class that interacts with the user to calculate cone area and volume.
    /// </summary>
    public partial class Program_2Cone : Form
    {
        /// <summary>
        /// Initializes a new instance of the Program_2Cone class.
        /// </summary>
        public Program_2Cone()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the Click event of btnArea to display the calculated area.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">An EventArgs that contains no event data.</param>
        private void btnArea_Click(object sender, EventArgs e)
        {
            int radius = int.Parse(txtRadius.Text);
            int height = int.Parse(txtHeight.Text);
            double area = Cone.CalculateArea(radius, height);
            lblDisplay.Text = $"Surface Area: {area:F2}";
        }

        /// <summary>
        /// Handles the Click event of btnVolume to display the calculated volume.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">An EventArgs that contains no event data.</param>
        private void btnVolume_Click(object sender, EventArgs e)
        {
            int radius = int.Parse(txtRadius.Text);
            int height = int.Parse(txtHeight.Text);
            double volume = Cone.CalculateVolume(radius, height);
            lblDisplay.Text = $"Volume: {volume:F2}";
        }

        /// <summary>
        /// Handles the Click event of btnExit to close the form.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">An EventArgs that contains no event data.</param>
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
