import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix

# Load dataset
data = pd.read_csv("Dry_Eye_Dataset.csv")

# Standardize column names: remove spaces, hyphens, and convert to lowercase
data.columns = data.columns.str.strip().str.replace(" ", "_").str.replace("-", "_").str.lower()

# Convert 'Y' → 1 and 'N' → 0 for categorical columns
binary_columns = [
    'sleep_disorder', 'wake_up_during_night', 'feel_sleepy_during_day', 
    'caffeine_consumption', 'alcohol_consumption', 'smoking', 'medical_issue', 
    'ongoing_medication', 'smart_device_before_bed', 'blue_light_filter', 
    'discomfort_eye_strain', 'redness_in_eye', 'itchiness_irritation_in_eye', 'dry_eye_disease'
]

for col in binary_columns:
    if col in data.columns:
        data[col] = data[col].map({'Y': 1, 'N': 0})

# Split Blood Pressure into Systolic & Diastolic
if "blood_pressure" in data.columns:
    data[['bp_sys', 'bp_dia']] = data['blood_pressure'].str.split('/', expand=True)
    data[['bp_sys', 'bp_dia']] = data[['bp_sys', 'bp_dia']].apply(pd.to_numeric, errors='coerce')
    data.drop(columns=['blood_pressure'], inplace=True)  # Drop original column

# Define Cybersecurity Risk Variable (Binary Classification)
data['cyber_risk'] = ((data['stress_level'] >= 4) & (data['sleep_duration'] < 6) & (data['average_screen_time'] > 8)).astype(int)

# Selecting Features for Cybersecurity Risk Prediction
relevant_features = [
    "age", "sleep_duration", "sleep_quality", "stress_level", 
    'bp_sys', 'bp_dia', 'heart_rate', 'daily_steps', 'physical_activity',
    'smart_device_before_bed', 'average_screen_time', 'blue_light_filter'
]

existing_features = [col for col in relevant_features if col in data.columns]
if not existing_features:
    raise ValueError("None of the selected features are present in the dataset. Check column names.")

# Define Target Variable
if "cyber_risk" in data.columns:
    y = data["cyber_risk"]
else:
    raise ValueError("Column 'cyber_risk' not found. Please check dataset.")

# Prepare Features for Model
X = data[existing_features]

# Split Data into Training and Testing Sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train Machine Learning Model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)

# Model Evaluation
conf_matrix = confusion_matrix(y_test, y_pred)
accuracy = accuracy_score(y_test, y_pred)

# Display Confusion Matrix with Borders
print("\n" + "―" * 57)
print("|               Confusion Matrix              |")
print("―" * 57)
print("|                     | Positive Condition | Negative Condition |")
print("|---------------------|-------------------|-------------------|")
print("| Positive Test       | True Positive: {:.3f} | False Positive: {:.3f} |".format(
    conf_matrix[1, 1] / len(y_test), conf_matrix[0, 1] / len(y_test)))
print("| Negative Test       | False Negative: {:.3f} | True Negative: {:.3f} |".format(
    conf_matrix[1, 0] / len(y_test), conf_matrix[0, 0] / len(y_test)))
print("―" * 57)
print("| Accuracy: {:.3f}                                        |".format(accuracy))
print("―" * 57)

# Hypothesis Testing: Stress Level vs. Cybersecurity Risk
group1 = data[data["cyber_risk"] == 1]["stress_level"]
group2 = data[data["cyber_risk"] == 0]["stress_level"]

t_stat, p_value = stats.ttest_ind(group1, group2, nan_policy='omit')
mean_diff = group1.mean() - group2.mean()
se_diff = np.sqrt(group1.var()/len(group1) + group2.var()/len(group2))
cohens_d = mean_diff / np.sqrt((group1.var() + group2.var()) / 2)
df = len(group1) + len(group2) - 2

# Display T-Test Results in Required Format
print("\n" + "―" * 91)
print("|               Independent Samples T-Test               |")
print("―" * 91)
print("| Variable       |     t      |     df     |     p      | Mean Diff  | SE Diff   | Cohen’s d  |")
print("|---------------|------------|------------|------------|------------|------------|------------|")
print("| Stress Level  |   {:.3f}   |   {:.3f}   |   {:.3f}   |   {:.3f}   |   {:.3f}   |   {:.3f}   |".format(
    t_stat, df, p_value, mean_diff, se_diff, cohens_d))
print("―" * 91)

# Notes Section
print("\n" + "―" * 67)
print("| Note. Student’s t-test.                                        |")
print("| Note. For all tests, the alternative hypothesis specifies      |")
print("|       that group Cyber Risk = 1 has higher stress than group   |")
print("|       Cyber Risk = 0.                                          |")
print("―" * 67)

# Visualization
sns.boxplot(x=data['cyber_risk'], y=data['stress_level'])
plt.title("Stress Levels vs. Cybersecurity Risk")
plt.xlabel("Cyber Risk (0 = No, 1 = Yes)")
plt.ylabel("Stress Level")
plt.show()


