import pandas as pd
import numpy as np
from scipy.stats import pearsonr
from factor_analyzer import FactorAnalyzer
from statsmodels.stats.inter_rater import fleiss_kappa
import pingouin as pg

def cronbach_alpha(data):
    """Compute Cronbach's Alpha for reliability analysis."""
    k = data.shape[1]  # Number of items
    variances = data.var(axis=0, ddof=1)  # Variance for each column
    total_variance = data.sum(axis=1).var(ddof=1)  # Variance of total score
    alpha = (k / (k - 1)) * (1 - variances.sum() / total_variance)
    return alpha

# Load the dataset
data = pd.read_csv("cybersecurity_survey_data.csv")
data.drop(columns=["Participant_ID"], inplace=True)  # Remove ID column

# Compute Cronbach's Alpha for reliability
cronbach_score = cronbach_alpha(data)

# Descriptive Statistics
descriptive_stats = data.describe().T

# Inter-item Correlations
correlations = data.corr()

# Exploratory Factor Analysis (EFA) - Determine the number of factors
fa = FactorAnalyzer(n_factors=data.shape[1], rotation="varimax")
fa.fit(data)

# Determine the number of factors using eigenvalues > 1 (Kaiser criterion)
eigenvalues, _ = fa.get_eigenvalues()
n_factors = sum(eigenvalues > 1)

# Re-run Factor Analysis with optimal factors
fa = FactorAnalyzer(n_factors=n_factors, rotation="varimax")
fa.fit(data)
factor_loadings = pd.DataFrame(fa.loadings_, columns=[f"Factor {i+1}" for i in range(n_factors)], index=data.columns)

# Fleiss' Kappa for inter-rater agreement (reshaped properly)
rating_matrix = np.apply_along_axis(lambda x: np.bincount(x, minlength=6), axis=1, arr=data.values)
fleiss_kappa_score = fleiss_kappa(rating_matrix, method='fleiss')

# Formatting results similar to JASP
results = {
    "Cronbach's Alpha": cronbach_score,
    "Factor Loadings": factor_loadings,
    "Descriptive Statistics": descriptive_stats,
    "Inter-item Correlations": correlations,
    "Fleiss' Kappa": fleiss_kappa_score
}

# Print results in a structured format
for key, value in results.items():
    print(f"\n=== {key} ===")
    if isinstance(value, pd.DataFrame):
        print(value.round(3).to_string())  # Format DataFrames
    else:
        print(round(value, 3))  # Round single values


# # Function to calculate Cronbach's Alpha
# def cronbach_alpha(df):
#     items = df.shape[1]  # Number of items
#     variances = df.var(axis=0, ddof=1)
#     total_variance = df.sum(axis=1).var(ddof=1)
#     alpha = (items / (items - 1)) * (1 - variances.sum() / total_variance)
#     return alpha

# cronbach_alpha_value = cronbach_alpha(survey_data)
# print(f"Cronbach's Alpha: {cronbach_alpha_value:.3f}")

# # Exploratory Factor Analysis (EFA)
# fa = FactorAnalyzer(n_factors=2, rotation='varimax')
# fa.fit(survey_data)

# # Factor loadings
# factor_loadings = pd.DataFrame(fa.loadings_, index=survey_data.columns, columns=['Factor 1', 'Factor 2'])
# print("Factor Loadings:")
# print(factor_loadings)

# # Eigenvalues
# eigenvalues, _ = fa.get_eigenvalues()
# print("\nEigenvalues:")
# print(eigenvalues)

# # Pearson Correlation Matrix
# correlation_matrix = survey_data.corr(method='pearson')
# print("\nCorrelation Matrix:")
# print(correlation_matrix)
