import pandas as pd
import numpy as np
import statsmodels.api as sm
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.stats import chi2_contingency
from sklearn.preprocessing import LabelEncoder
from statsmodels.formula.api import logit

# Load the dataset
df = pd.read_csv("Dry_Eye_Dataset.csv")

# Convert categorical variables to numerical format
df['Dry Eye Disease'] = df['Dry Eye Disease'].map({'Y': 1, 'N': 0})

# Descriptive Statistics (Formatted like JASP)
desc_stats = df.describe(include='all').transpose()
print("\nDescriptive Statistics:")
print(desc_stats)

# Logistic Regression: Predicting Dry Eye Disease from Sleep Duration
model = logit("Q('Dry Eye Disease') ~ Q('Sleep duration')", data=df).fit()
print("\nLogistic Regression Summary:")
print(model.summary())

# Chi-Square Test: Checking dependence between Sleep Duration Categories and DED
df['Sleep Duration Category'] = pd.qcut(df['Sleep duration'], q=3, labels=["Short", "Medium", "Long"])
crosstab = pd.crosstab(df['Sleep Duration Category'], df['Dry Eye Disease'])
chi2, p, dof, expected = chi2_contingency(crosstab)
print("\nChi-Square Test Results:")
print(f"Chi2: {chi2:.3f}, p-value: {p:.3f}")

# JASP-Style Visualizations
sns.boxplot(x=df['Dry Eye Disease'], y=df['Sleep duration'])
plt.title("Sleep Duration by Dry Eye Disease Status")
plt.show()

sns.heatmap(crosstab, annot=True, cmap='Blues', fmt='d')
plt.title("Chi-Square Test Heatmap")
plt.xlabel("Dry Eye Disease")
plt.ylabel("Sleep Duration Category")
plt.show()