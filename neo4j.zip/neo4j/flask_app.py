from flask import Flask, request, render_template, redirect, url_for
from py2neo import Graph, Node, Relationship
from pymongo import MongoClient
import random

app = Flask(__name__)

# Establish connection to Neo4j
graph = Graph("bolt://44.204.170.234:7687", user="neo4j", password="damping-airfields-instrumentation")

# Establish connection to MongoDB Atlas
mongo_client = MongoClient("mongodb+srv://mybuzz66:buzzstudent@twitter-recommendation.v3x0uto.mongodb.net/?retryWrites=true&w=majority")
mongo_db = mongo_client["twitter-recommendation"]
recommended_posts_collection = mongo_db["recommended-posts"]

# List of names
names = [
    "Sarah", "Michael", "Emily", "David", "Jessica",
    "Matthew", "Olivia", "Daniel", "Sophia", "Christopher",
    "Ashley", "Joshua", "Elizabeth", "Andrew", "Madison",
    "James", "Samantha", "Jacob", "Emma", "William"
]

# Home route
@app.route('/')
def index():
    return render_template('index.html')

# Function to create a new user and make them follow another random user
def create_user_and_follow():
    # Choose a random name from the list
    random_name = random.choice(names)
    
    # Check if the user already exists, if not, create a new user node
    user = graph.nodes.match("Person", name=random_name).first()
    if not user:
        user = Node("Person", name=random_name)
        graph.create(user)
    
    # Choose a random existing user to follow
    existing_user = random.choice(list(graph.nodes.match("Person")))
    
    # Make the new user follow the existing user
    graph.create(Relationship(user, "FOLLOWS", existing_user))

# Tweet submission route
@app.route('/tweet', methods=['POST'])
def tweet():
    # Get the tweet content from the form
    tweet_content = request.form['tweet_content']
    
    # Create a new tweet node
    new_tweet = Node("Tweet", content=tweet_content, likes=0)
    graph.create(new_tweet)
    
    # Create a new user and make them follow another user
    create_user_and_follow()
    
    # Relate the new user to the new tweet
    user = graph.nodes.match("Person").order_by("rand()").first()
    graph.create(Relationship(user, "TWEETED", new_tweet))
    
    # Store the user and tweet data in MongoDB
    user_data = {"name": user["name"], "tweet_content": tweet_content}
    recommended_posts_collection.insert_one(user_data)
    
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
