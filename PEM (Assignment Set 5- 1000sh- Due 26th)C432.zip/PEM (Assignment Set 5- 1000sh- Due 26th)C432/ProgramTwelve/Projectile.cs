/*
 * Project:         Program 5
 * Date Created:    September 2024
 * Last Modified:   September 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      PaintJob
 * Description:     Instance class containing method for estimating the cost of a paint job.
 */
using System;

namespace Program_12
{
    /// <summary>
    /// Class Name:      Projectile
    /// Description:     Calculates the maximum height and time to land of a projectile based on initial height and velocity.
    /// Developer:       Pragnya Thandra
    /// Date Created:    September 2024
    /// Last Modified:   September 2024
    /// </summary>
    public class Projectile
    {
        // Properties
        public int InitialHeight { get; private set; }
        public int InitialVelocity { get; private set; }
        public double MaxHeight { get; private set; }
        public double LandTime { get; private set; }

        // Constructor
        public Projectile(int initialHeight, int initialVelocity)
        {
            InitialHeight = initialHeight;
            InitialVelocity = initialVelocity;
            MaxHeight = CalcMaxHeight();
            LandTime = CalcLandTime();
        }

        // Private method to calculate the height at a specific time
        private double FindHeight(double atTime)
        {
            return InitialHeight + (InitialVelocity * atTime) - (16 * Math.Pow(atTime, 2));
        }

        // Private method to calculate maximum height
        private double CalcMaxHeight()
        {
            double timeToMaxHeight = InitialVelocity / 32.0;
            return FindHeight(timeToMaxHeight);
        }

        // Private method to calculate the landing time
        private double CalcLandTime()
        {
            double time = 0;
            while (FindHeight(time) > 0)
            {
                time += 0.1;
            }
            return time;
        }
    }
}
