namespace Program_12
{
    partial class Program_12Projectile
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.numInitialHeight = new System.Windows.Forms.NumericUpDown();
            this.numInitialVelocity = new System.Windows.Forms.NumericUpDown();
            this.btnCalculateProjectile = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblMaxHeight = new System.Windows.Forms.Label();
            this.lblLandTime = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numInitialHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numInitialVelocity)).BeginInit();
            this.SuspendLayout();

            // numInitialHeight
            this.numInitialHeight.Location = new System.Drawing.Point(160, 30);
            this.numInitialHeight.Maximum = 1000;
            this.numInitialHeight.Name = "numInitialHeight";
            this.numInitialHeight.Size = new System.Drawing.Size(150, 27);

            // numInitialVelocity
            this.numInitialVelocity.Location = new System.Drawing.Point(160, 80);
            this.numInitialVelocity.Maximum = 1000;
            this.numInitialVelocity.Name = "numInitialVelocity";
            this.numInitialVelocity.Size = new System.Drawing.Size(150, 27);

            // btnCalculateProjectile
            this.btnCalculateProjectile.Location = new System.Drawing.Point(30, 130);
            this.btnCalculateProjectile.Name = "btnCalculateProjectile";
            this.btnCalculateProjectile.Size = new System.Drawing.Size(100, 40);
            this.btnCalculateProjectile.Text = "Calculate";
            this.btnCalculateProjectile.UseVisualStyleBackColor = true;
            this.btnCalculateProjectile.Click += new System.EventHandler(this.btnCalculateProjectile_Click);

            // btnClear
            this.btnClear.Location = new System.Drawing.Point(140, 130);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(100, 40);
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);

            // btnReset
            this.btnReset.Location = new System.Drawing.Point(250, 130);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(100, 40);
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);

            // btnExit
            this.btnExit.Location = new System.Drawing.Point(360, 130);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(100, 40);
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);

            // lblMaxHeight
            this.lblMaxHeight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMaxHeight.Location = new System.Drawing.Point(30, 200);
            this.lblMaxHeight.Name = "lblMaxHeight";
            this.lblMaxHeight.Size = new System.Drawing.Size(340, 40);
            this.lblMaxHeight.Text = "Max Height:";
            this.lblMaxHeight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // lblLandTime
            this.lblLandTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLandTime.Location = new System.Drawing.Point(30, 250);
            this.lblLandTime.Name = "lblLandTime";
            this.lblLandTime.Size = new System.Drawing.Size(340, 40);
            this.lblLandTime.Text = "Land Time:";
            this.lblLandTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // Program_12Projectile Form Settings
            this.ClientSize = new System.Drawing.Size(500, 350);
            this.Controls.Add(this.numInitialHeight);
            this.Controls.Add(this.numInitialVelocity);
            this.Controls.Add(this.btnCalculateProjectile);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblMaxHeight);
            this.Controls.Add(this.lblLandTime);
            this.Name = "Program_12Projectile";
            this.Text = "Projectile Calculator";
            ((System.ComponentModel.ISupportInitialize)(this.numInitialHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numInitialVelocity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.NumericUpDown numInitialHeight;
        private System.Windows.Forms.NumericUpDown numInitialVelocity;
        private System.Windows.Forms.Button btnCalculateProjectile;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblMaxHeight;
        private System.Windows.Forms.Label lblLandTime;

        #endregion
    }
}
