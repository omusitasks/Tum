/*
 * Project:         Program 5
 * Date Created:    September 2024
 * Last Modified:   September 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      Program_5PaintJob
 * Description:     Presentation Layer class for calculating paint job costs.
 */
using System;
using System.Windows.Forms;

namespace Program_12
{
    /// <summary>
    /// Class Name:      Program_12Projectile
    /// Description:     Form class for calculating projectile max height and land time.
    /// Developer:       Pragnya Thandra
    /// Date Created:    September 2024
    /// Last Modified:   October 2024
    /// </summary>
    public partial class Program_12Projectile : Form
    {
        public Program_12Projectile()
        {
            InitializeComponent();
        }

        private void btnCalculateProjectile_Click(object sender, EventArgs e)
        {
            // Retrieve user inputs
            int initialHeight = (int)numInitialHeight.Value;
            int initialVelocity = (int)numInitialVelocity.Value;

            // Create Projectile object
            Projectile projectile = new Projectile(initialHeight, initialVelocity);

            // Display the projectile details
            lblMaxHeight.Text = $"Max Height: {projectile.MaxHeight:F2} feet";
            lblLandTime.Text = $"Land Time: {projectile.LandTime:F2} seconds";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Reset all inputs and the output labels
            numInitialHeight.Value = 0;
            numInitialVelocity.Value = 0;
            lblMaxHeight.Text = string.Empty;
            lblLandTime.Text = string.Empty;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            // Reset all inputs, outputs, and restore defaults if necessary
            numInitialHeight.Value = 0;  // Set default initial height if specified
            numInitialVelocity.Value = 0; // Set default initial velocity if specified
            lblMaxHeight.Text = "Max Height:";
            lblLandTime.Text = "Land Time:";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Exit the application
            Application.Exit();
        }
    }
}
