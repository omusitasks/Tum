namespace Program_13
{
    partial class Program13
    {
        private System.Windows.Forms.ComboBox cmbPlayers;
        private System.Windows.Forms.ComboBox cmbChampions;
        private System.Windows.Forms.Button btnShowWins;
        private System.Windows.Forms.Button btnBackToBack;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label lblTopPlayers;
        private System.Windows.Forms.Label lblChampions;

        private void InitializeComponent()
        {
            this.cmbPlayers = new System.Windows.Forms.ComboBox();
            this.cmbChampions = new System.Windows.Forms.ComboBox();
            this.btnShowWins = new System.Windows.Forms.Button();
            this.btnBackToBack = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblResult = new System.Windows.Forms.Label();
            this.lblTopPlayers = new System.Windows.Forms.Label();
            this.lblChampions = new System.Windows.Forms.Label();

            // Top Players Label
            this.lblTopPlayers.Location = new System.Drawing.Point(20, 10);
            this.lblTopPlayers.Size = new System.Drawing.Size(100, 20);
            this.lblTopPlayers.Text = "Top Players";

            // ComboBox for players
            this.cmbPlayers.Location = new System.Drawing.Point(20, 30);
            this.cmbPlayers.Size = new System.Drawing.Size(200, 30);
            this.cmbPlayers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            // Wimbledon Champions Label
            this.lblChampions.Location = new System.Drawing.Point(240, 10);
            this.lblChampions.Size = new System.Drawing.Size(200, 20);
            this.lblChampions.Text = "Wimbledon Champions (since 1968)";

            // ComboBox for champions
            this.cmbChampions.Location = new System.Drawing.Point(240, 30);
            this.cmbChampions.Size = new System.Drawing.Size(200, 30);
            this.cmbChampions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            // Show Wins button
            this.btnShowWins.Location = new System.Drawing.Point(460, 30);
            this.btnShowWins.Size = new System.Drawing.Size(120, 30);
            this.btnShowWins.Text = "How many wins?";
            this.btnShowWins.Click += new System.EventHandler(this.btnShowWins_Click);

            // Back-to-Back button
            this.btnBackToBack.Location = new System.Drawing.Point(590, 30);
            this.btnBackToBack.Size = new System.Drawing.Size(220, 30);
            this.btnBackToBack.Text = "How many times back-to-back champions?";
            this.btnBackToBack.Click += new System.EventHandler(this.btnBackToBack_Click);

            // Exit button
            this.btnExit.Location = new System.Drawing.Point(820, 30);
            this.btnExit.Size = new System.Drawing.Size(50, 30);
            this.btnExit.Text = "Exit";
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);

            // Label for result
            this.lblResult.Location = new System.Drawing.Point(20, 80);
            this.lblResult.Size = new System.Drawing.Size(500, 30);

            // Add controls to form
            this.Controls.Add(this.lblTopPlayers);
            this.Controls.Add(this.cmbPlayers);
            this.Controls.Add(this.lblChampions);
            this.Controls.Add(this.cmbChampions);
            this.Controls.Add(this.btnShowWins);
            this.Controls.Add(this.btnBackToBack);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblResult);

            this.Text = "Assignment Set 5 - Program 13";
            this.ClientSize = new System.Drawing.Size(900, 150);
        }
    }
}
