using System;
using System.Windows.Forms;
using System.Collections.Generic;

namespace Program_13
{
    public partial class Program13 : Form
    {
        // Example dictionaries to hold player win data and check for back-to-back champions
        private Dictionary<string, int> playerWins = new Dictionary<string, int>();
        private List<string> champions = new List<string>();

        public Program13()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            // Populate the combo boxes with data (replace with actual data loading from Excel)
            cmbPlayers.Items.AddRange(new string[] { "Martina Navratilova", "Roger Federer", "Serena Williams" });
            cmbChampions.Items.AddRange(new string[] { "1968 - Rod Laver", "1969 - Rod Laver", "1978 - Martina Navratilova", /*...*/ });

            // Example data
            playerWins["Martina Navratilova"] = 9;
            playerWins["Roger Federer"] = 8;
            playerWins["Serena Williams"] = 7;

            // Populate champions for back-to-back checking (populate this list fully based on the data)
            champions.AddRange(new string[] { "Rod Laver", "Martina Navratilova", "Roger Federer", "Martina Navratilova" });
        }

        private void btnShowWins_Click(object sender, EventArgs e)
        {
            string selectedPlayer = cmbPlayers.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(selectedPlayer))
            {
                MessageBox.Show("Please select a player.");
                return;
            }

            if (playerWins.ContainsKey(selectedPlayer))
            {
                lblResult.Text = $"{selectedPlayer} has won {playerWins[selectedPlayer]} Wimbledon Championship(s)";
            }
            else
            {
                lblResult.Text = $"{selectedPlayer} has no recorded wins.";
            }
        }

        private void btnBackToBack_Click(object sender, EventArgs e)
        {
            int backToBackCount = 0;
            for (int i = 1; i < champions.Count; i++)
            {
                if (champions[i] == champions[i - 1])
                {
                    backToBackCount++;
                }
            }
            lblResult.Text = $"There have been {backToBackCount} back-to-back champion(s).";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
