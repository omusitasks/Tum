namespace Program_11
{
    partial class Program_11WaterTank
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.txtRadius = new System.Windows.Forms.TextBox();
            this.txtDepth = new System.Windows.Forms.TextBox();
            this.txtWaterLevel = new System.Windows.Forms.TextBox();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.lblRadius = new System.Windows.Forms.Label();
            this.lblDepth = new System.Windows.Forms.Label();
            this.lblWaterLevel = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblTankCapacity = new System.Windows.Forms.Label();
            this.btnCreateTank = new System.Windows.Forms.Button();
            this.btnAddWater = new System.Windows.Forms.Button();
            this.btnWithdrawWater = new System.Windows.Forms.Button();
            this.btnFillTank = new System.Windows.Forms.Button();
            this.btnEmptyTank = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.numLitersToAdd = new System.Windows.Forms.NumericUpDown();
            this.numLitersToWithdraw = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numLitersToAdd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLitersToWithdraw)).BeginInit();
            this.SuspendLayout();

            // Radius Label
            this.lblRadius.AutoSize = true;
            this.lblRadius.Location = new System.Drawing.Point(30, 30);
            this.lblRadius.Name = "lblRadius";
            this.lblRadius.Size = new System.Drawing.Size(100, 20);
            this.lblRadius.Text = "Tank Radius (m):";

            // Radius TextBox
            this.txtRadius.Location = new System.Drawing.Point(160, 30);
            this.txtRadius.Size = new System.Drawing.Size(100, 27);

            // Depth Label
            this.lblDepth.AutoSize = true;
            this.lblDepth.Location = new System.Drawing.Point(30, 80);
            this.lblDepth.Name = "lblDepth";
            this.lblDepth.Size = new System.Drawing.Size(100, 20);
            this.lblDepth.Text = "Tank Depth (m):";

            // Depth TextBox
            this.txtDepth.Location = new System.Drawing.Point(160, 80);
            this.txtDepth.Size = new System.Drawing.Size(100, 27);

            // Create Tank Button
            this.btnCreateTank.Location = new System.Drawing.Point(30, 130);
            this.btnCreateTank.Name = "btnCreateTank";
            this.btnCreateTank.Size = new System.Drawing.Size(100, 30);
            this.btnCreateTank.Text = "Create Tank";
            this.btnCreateTank.UseVisualStyleBackColor = true;
            this.btnCreateTank.Click += new System.EventHandler(this.btnCreateTank_Click);

            // Water Level Label
            this.lblWaterLevel.AutoSize = true;
            this.lblWaterLevel.Location = new System.Drawing.Point(30, 180);
            this.lblWaterLevel.Name = "lblWaterLevel";
            this.lblWaterLevel.Size = new System.Drawing.Size(120, 20);
            this.lblWaterLevel.Text = "Current Water Level (L):";

            // Water Level TextBox
            this.txtWaterLevel.Location = new System.Drawing.Point(160, 180);
            this.txtWaterLevel.Size = new System.Drawing.Size(100, 27);
            this.txtWaterLevel.ReadOnly = true;

            // Tank Capacity Label
            this.lblTankCapacity.AutoSize = true;
            this.lblTankCapacity.Location = new System.Drawing.Point(30, 220);
            this.lblTankCapacity.Name = "lblTankCapacity";
            this.lblTankCapacity.Size = new System.Drawing.Size(120, 20);
            this.lblTankCapacity.Text = "Tank Capacity (L):";

            // Status Label
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(30, 260);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(50, 20);
            this.lblStatus.Text = "Status:";

            // Status TextBox
            this.txtStatus.Location = new System.Drawing.Point(30, 290);
            this.txtStatus.Size = new System.Drawing.Size(320, 100);
            this.txtStatus.Multiline = true;
            this.txtStatus.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;

            // Add Water Button
            this.btnAddWater.Location = new System.Drawing.Point(30, 420);
            this.btnAddWater.Name = "btnAddWater";
            this.btnAddWater.Size = new System.Drawing.Size(100, 30);
            this.btnAddWater.Text = "Add Water";
            this.btnAddWater.UseVisualStyleBackColor = true;
            this.btnAddWater.Click += new System.EventHandler(this.btnAddWater_Click);

            // Liters to Add NumericUpDown
            this.numLitersToAdd.Location = new System.Drawing.Point(160, 420);
            this.numLitersToAdd.Maximum = 10000;
            this.numLitersToAdd.Name = "numLitersToAdd";
            this.numLitersToAdd.Size = new System.Drawing.Size(100, 27);

            // Withdraw Water Button
            this.btnWithdrawWater.Location = new System.Drawing.Point(30, 460);
            this.btnWithdrawWater.Name = "btnWithdrawWater";
            this.btnWithdrawWater.Size = new System.Drawing.Size(100, 30);
            this.btnWithdrawWater.Text = "Withdraw Water";
            this.btnWithdrawWater.UseVisualStyleBackColor = true;
            this.btnWithdrawWater.Click += new System.EventHandler(this.btnWithdrawWater_Click);

            // Liters to Withdraw NumericUpDown
            this.numLitersToWithdraw.Location = new System.Drawing.Point(160, 460);
            this.numLitersToWithdraw.Maximum = 10000;
            this.numLitersToWithdraw.Name = "numLitersToWithdraw";
            this.numLitersToWithdraw.Size = new System.Drawing.Size(100, 27);

            // Fill Tank Button
            this.btnFillTank.Location = new System.Drawing.Point(30, 500);
            this.btnFillTank.Name = "btnFillTank";
            this.btnFillTank.Size = new System.Drawing.Size(100, 30);
            this.btnFillTank.Text = "Fill Tank";
            this.btnFillTank.UseVisualStyleBackColor = true;
            this.btnFillTank.Click += new System.EventHandler(this.btnFillTank_Click);

            // Empty Tank Button
            this.btnEmptyTank.Location = new System.Drawing.Point(160, 500);
            this.btnEmptyTank.Name = "btnEmptyTank";
            this.btnEmptyTank.Size = new System.Drawing.Size(100, 30);
            this.btnEmptyTank.Text = "Empty Tank";
            this.btnEmptyTank.UseVisualStyleBackColor = true;
            this.btnEmptyTank.Click += new System.EventHandler(this.btnEmptyTank_Click);

            // Clear Button
            this.btnClear.Location = new System.Drawing.Point(30, 540);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(100, 30);
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);

            // Exit Button
            this.btnExit.Location = new System.Drawing.Point(160, 540);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(100, 30);
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);

            // Form Settings
            this.ClientSize = new System.Drawing.Size(400, 600);
            this.Controls.Add(this.txtRadius);
            this.Controls.Add(this.txtDepth);
            this.Controls.Add(this.txtWaterLevel);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.lblRadius);
            this.Controls.Add(this.lblDepth);
            this.Controls.Add(this.lblWaterLevel);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblTankCapacity);
            this.Controls.Add(this.btnCreateTank);
            this.Controls.Add(this.btnAddWater);
            this.Controls.Add(this.btnWithdrawWater);
            this.Controls.Add(this.btnFillTank);
            this.Controls.Add(this.btnEmptyTank);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.numLitersToAdd);
            this.Controls.Add(this.numLitersToWithdraw);
            this.Name = "Program_11WaterTank";
            this.Text = "Water Tank Management";
            ((System.ComponentModel.ISupportInitialize)(this.numLitersToAdd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLitersToWithdraw)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.TextBox txtRadius;
        private System.Windows.Forms.TextBox txtDepth;
        private System.Windows.Forms.TextBox txtWaterLevel;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.Label lblRadius;
        private System.Windows.Forms.Label lblDepth;
        private System.Windows.Forms.Label lblWaterLevel;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblTankCapacity;
        private System.Windows.Forms.Button btnCreateTank;
        private System.Windows.Forms.Button btnAddWater;
        private System.Windows.Forms.Button btnWithdrawWater;
        private System.Windows.Forms.Button btnFillTank;
        private System.Windows.Forms.Button btnEmptyTank;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.NumericUpDown numLitersToAdd;
        private System.Windows.Forms.NumericUpDown numLitersToWithdraw;

        #endregion
    }
}
