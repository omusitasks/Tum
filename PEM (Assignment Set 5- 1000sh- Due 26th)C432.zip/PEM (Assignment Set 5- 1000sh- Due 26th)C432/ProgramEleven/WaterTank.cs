using System;

namespace Program_11
{
    public class WaterTank
    {
        // Properties with public getters and private setters
        public double TankRadius { get; private set; }
        public double TankDepth { get; private set; }
        public int MaxCapacity { get; private set; }
        public int CurrentLevel { get; private set; }

        // Constructor
        public WaterTank(double radius, double depth)
        {
            TankRadius = radius;
            TankDepth = depth;
            MaxCapacity = CalculateTankCapacity();
            CurrentLevel = 0; // Initialize water level to 0
        }

        /// <summary>
        /// Calculate maximum water capacity of the tank
        /// </summary>
        private int CalculateTankCapacity()
        {
            double capacity = Math.PI * Math.Pow(TankRadius, 2) * TankDepth * 1000;
            return Convert.ToInt32(Math.Floor(capacity));
        }

        /// <summary>
        /// Add water to the tank and return status message
        /// </summary>
        public string AddWater(int litersToAdd)
        {
            if (CurrentLevel + litersToAdd <= MaxCapacity)
            {
                CurrentLevel += litersToAdd;
                return $"Added {litersToAdd} liters. Current level: {CurrentLevel} liters.";
            }
            else
            {
                int availableSpace = MaxCapacity - CurrentLevel;
                return $"Cannot add {litersToAdd} liters. Max addable: {availableSpace} liters.";
            }
        }

        /// <summary>
        /// Withdraw water from the tank and return status message
        /// </summary>
        public string WithdrawWater(int litersToWithdraw)
        {
            if (CurrentLevel >= litersToWithdraw)
            {
                CurrentLevel -= litersToWithdraw;
                return $"Withdrew {litersToWithdraw} liters. Current level: {CurrentLevel} liters.";
            }
            else
            {
                return $"Cannot withdraw {litersToWithdraw} liters. Max withdrawable: {CurrentLevel} liters.";
            }
        }

        /// <summary>
        /// Fill the tank to maximum capacity
        /// </summary>
        public void FillTank()
        {
            CurrentLevel = MaxCapacity;
        }

        /// <summary>
        /// Fill the tank at a specified rate
        /// </summary>
        public bool FillTank(int litersPerSecond)
        {
            if (CurrentLevel + litersPerSecond <= MaxCapacity)
            {
                CurrentLevel += litersPerSecond;
                return true;
            }
            return false;
        }

        /// <summary>
        /// Drain the tank at a specified rate
        /// </summary>
        public bool DrainTank(int litersPerSecond)
        {
            if (CurrentLevel >= litersPerSecond)
            {
                CurrentLevel -= litersPerSecond;
                return true;
            }
            return false;
        }

        /// <summary>
        /// Empty the tank
        /// </summary>
        public void EmptyTank()
        {
            CurrentLevel = 0;
        }
    }
}
