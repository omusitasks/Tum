using System;
using System.Windows.Forms;

namespace Program_11
{
    static class Program
    {
        /// <summary>
        /// Main entry point for Program 11 - Water Tank Application
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Program_11WaterTank()); // Launch the main form
        }
    }
}
