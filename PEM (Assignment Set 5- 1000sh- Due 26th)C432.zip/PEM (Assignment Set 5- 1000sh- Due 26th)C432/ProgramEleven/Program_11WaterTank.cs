using System;
using System.Windows.Forms;

namespace Program_11
{
    public partial class Program_11WaterTank : Form
    {
        private WaterTank waterTank;

        public Program_11WaterTank()
        {
            InitializeComponent();
        }

        private void btnCreateTank_Click(object sender, EventArgs e)
        {
            // Ensure radius and depth inputs are converted correctly
            if (double.TryParse(txtRadius.Text, out double radius) && double.TryParse(txtDepth.Text, out double depth))
            {
                waterTank = new WaterTank(radius, depth);
                lblTankCapacity.Text = $"Tank Capacity: {waterTank.MaxCapacity} L";
                txtWaterLevel.Text = waterTank.CurrentLevel.ToString();
                txtStatus.Text = "Tank created successfully.";
            }
            else
            {
                MessageBox.Show("Please enter valid numeric values for radius and depth.");
            }
        }

        private void btnAddWater_Click(object sender, EventArgs e)
        {
            if (waterTank != null)
            {
                int litersToAdd = (int)numLitersToAdd.Value;
                string message = waterTank.AddWater(litersToAdd);
                txtWaterLevel.Text = waterTank.CurrentLevel.ToString();
                txtStatus.Text = message;
            }
        }

        private void btnWithdrawWater_Click(object sender, EventArgs e)
        {
            if (waterTank != null)
            {
                int litersToWithdraw = (int)numLitersToWithdraw.Value;
                string message = waterTank.WithdrawWater(litersToWithdraw);
                txtWaterLevel.Text = waterTank.CurrentLevel.ToString();
                txtStatus.Text = message;
            }
        }

        private void btnFillTank_Click(object sender, EventArgs e)
        {
            if (waterTank != null)
            {
                waterTank.FillTank();
                txtWaterLevel.Text = waterTank.CurrentLevel.ToString();
                txtStatus.Text = "Tank filled to maximum capacity.";
            }
        }

        private void btnEmptyTank_Click(object sender, EventArgs e)
        {
            if (waterTank != null)
            {
                waterTank.EmptyTank();
                txtWaterLevel.Text = waterTank.CurrentLevel.ToString();
                txtStatus.Text = "Tank emptied.";
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtRadius.Clear();
            txtDepth.Clear();
            txtWaterLevel.Clear();
            txtStatus.Clear();
            lblTankCapacity.Text = "Tank Capacity: N/A";
            waterTank = null;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
