import random

def rule_based_addition(text, attributes):
    # Split the sentence into parts before and after the last punctuation mark
    last_punctuation_index = max(text.rfind('.'), text.rfind('!'), text.rfind('?'))
    before_last_punctuation = text[:last_punctuation_index+1]
    after_last_punctuation = text[last_punctuation_index+1:].strip()
    
    # Randomly select sensitive attributes
    selected_attributes = random.sample(attributes, random.randint(1, min(3, len(attributes))))
    attributes_sentence = ', '.join(selected_attributes)
    
    # Add the sensitive attributes to the sentence
    augmented_text = f"{before_last_punctuation} {attributes_sentence} {after_last_punctuation}"
    
    return augmented_text

def process_file(input_file_path, output_file_path, attributes):
    with open(input_file_path, 'r') as infile, open(output_file_path, 'w') as outfile:
        for line in infile:
            augmented_text = rule_based_addition(line.strip(), attributes)
            outfile.write(augmented_text + '\n')

if __name__ == "__main__":
    attributes = ["Caucasian", "African-American", "Asian", "Hispanic", "Middle Eastern",
                  "Hindu", "European", "English",
                  "Christian", "Islam", "Judaism", "Buddhism", "Hinduism", "Muslim", "Catholic", "Latino",
                  "Buddhist", "Jewish", "white", "Indian",
                  "male", "female", "transgender", "non-binary", "women", "homosexual", "post-adult",
                  "bisexual", "asexual", "heterosexual", "LGBTQ+", "lesbian", "gay",
                  "elderly", "youth", "young", "teenager", "middle-aged", "old", "adult", "older", "senior",
                  "mother", "father", "woman", "man", "men",
                  "physically disabled", "mentally ill", "cognitive impairment", "physical disability", "PTSD",
                  "genetic predisposition", "diabetic", "hearing-impaired", "autistic", "wheelchair-using",
                  "visually impaired",
                  "low-income", "working-class", "upper-class", "educated", "uneducated", "introvert",
                  "single", "married", "divorced", "widowed",
                  "American", "Chinese", "Indian", "Brazilian", "African", "Italian", "European",
                  "Middle Eastern", "Canadian", "Caribbean", "Japanese", "South America", "Latin", "in Africa",
                  "English", "non-English",
                  "English speaker", "Spanish speaker", "bilingual", "multilingual",
                  "citizen", "permanent resident", "visa holder", "undocumented", "immigrant", "veterans",
                  "high-income", "low income", "limited mobility",
                  "genetic trait", "hereditary disease", "homophobic", "introvert", "extrovert", "diabetic",
                  "orphaned", "visually impaired", "with genetic predispositions", "physical disabilities",
                  "cognitive disabilities", "mental health condition", "learning disability",
                  "hearing impairment", "chronic illnesses", "learning disabilities",
                  "mental health condition",
                  "active-duty", "reservist", "veteran", "widowed", "refugee", "poor", "wealthy", "affluent",
                  "rural", "urban",
                  "pregnant", "expecting a child",
                  "democrat", "Republican", "liberal", "conservative",
                  "lawyer", "politician", "nurse"
                  # ... your list of attributes ...
    ]
    process_file('souesesen.txt',
                 'Output.txt',
                 attributes)
