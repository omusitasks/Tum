# OIDC SPA

This project is a simple single-page web app with OIDC authentication.

## Setup Instructions

1. Clone the repository:

git clone <repository-url> cd <repository-name>


2. Install dependencies:

npm install


3. Configure environment variables:
- Rename `.env.example` to `.env` and fill in your OIDC credentials.

4. Run the application:

npm start


5. Open your browser and navigate to `http://localhost:3000`.

## Features

- User login with OIDC
- Display of user demographic information
- Responsive design
