import { login, logout, isAuthenticated, getUser } from './oidcConfig.js';

const loginBtn = document.getElementById('login-btn');
const logoutBtn = document.getElementById('logout-btn');
const userInfoDiv = document.getElementById('user-info');
const statusPara = document.getElementById('status');
const userNameSpan = document.getElementById('user-name');
const userEmailSpan = document.getElementById('user-email');

loginBtn.addEventListener('click', async () => {
    await login();
});

logoutBtn.addEventListener('click', () => {
    logout();
    updateUI();
});

function updateUI() {
    if (isAuthenticated()) {
        const user = getUser();
        statusPara.textContent = 'You are logged in.';
        loginBtn.style.display = 'none';
        logoutBtn.style.display = 'inline-block';
        userInfoDiv.style.display = 'block';
        userNameSpan.textContent = user.name || 'N/A';
        userEmailSpan.textContent = user.email || 'N/A';
    } else {
        statusPara.textContent = 'You are not logged in.';
        loginBtn.style.display = 'inline-block';
        logoutBtn.style.display = 'none';
        userInfoDiv.style.display = 'none';
    }
}

// Initial UI update
updateUI();
