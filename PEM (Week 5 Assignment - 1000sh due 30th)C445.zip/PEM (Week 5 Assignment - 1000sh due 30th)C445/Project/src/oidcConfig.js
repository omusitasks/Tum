import { createAuth0Client } from '@auth0/auth0-spa-js';

let auth0 = null;

async function configureAuth() {
    auth0 = await createAuth0Client({
        domain: 'YOUR_DOMAIN', // Replace with your Auth0 domain
        client_id: 'YOUR_CLIENT_ID', // Replace with your Auth0 client ID
        redirect_uri: window.location.origin,
    });
}

export async function login() {
    await auth0.loginWithRedirect();
}

export function logout() {
    auth0.logout({ returnTo: window.location.origin });
}

export function isAuthenticated() {
    return auth0.isAuthenticated();
}

export async function getUser() {
    return auth0.getUser();
}

// Initialize the Auth0 client
configureAuth();
