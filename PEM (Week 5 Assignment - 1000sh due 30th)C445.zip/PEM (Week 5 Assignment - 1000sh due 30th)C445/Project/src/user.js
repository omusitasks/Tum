export function displayUserInfo(user) {
    const userInfoDiv = document.getElementById('user-info');
    const userNameSpan = document.getElementById('user-name');
    const userEmailSpan = document.getElementById('user-email');

    if (user) {
        userInfoDiv.style.display = 'block';
        userNameSpan.textContent = user.name || 'N/A';
        userEmailSpan.textContent = user.email || 'N/A';
    } else {
        userInfoDiv.style.display = 'none';
    }
}

export function resetUserInfo() {
    const userNameSpan = document.getElementById('user-name');
    const userEmailSpan = document.getElementById('user-email');

    userNameSpan.textContent = '';
    userEmailSpan.textContent = '';
}
