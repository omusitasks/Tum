var Age = artifacts.require("./Age.sol");

module.exports = function (deployer) {
    deployer.deploy(Age, 21);
}