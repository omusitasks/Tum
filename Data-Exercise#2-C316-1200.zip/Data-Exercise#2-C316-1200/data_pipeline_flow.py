# IMPORT REQUIRED PACKAGES
import os
import psycopg2
import csv


# Function to perform data sanitization
def sanitize_data(data):
    # Example: converting 'None' values to NULL
    for key, value in data.items():
        if value == 'None':
            data[key] = None
    return data

# Function to create table based on CSV file columns
def create_table(cursor, table_name, columns):
    # Construct CREATE TABLE query
    columns_def = ', '.join(['"{}" VARCHAR'.format(column) for column in columns])
    query = "CREATE TABLE IF NOT EXISTS {} ({}, PRIMARY KEY({}))".format(table_name, columns_def, ', '.join(['"{}"'.format(column) for column in columns]))

    # Execute query
    cursor.execute(query)

# Function to read CSV file and insert or update data into PostgreSQL database
def process_csv_and_insert(csv_file, host, database, user, password):
    # Connect to PostgreSQL
    conn = psycopg2.connect(host=host, database=database, user=user, password=password)
    cursor = conn.cursor()

    # Extract table name from CSV file
    table_name = os.path.splitext(os.path.basename(csv_file))[0]

    # Read CSV file
    with open(csv_file, 'r') as file:
        csv_reader = csv.DictReader(file)
        columns = csv_reader.fieldnames

        # Create table if it doesn't exist
        create_table(cursor, table_name, columns)

        # Insert or update data into PostgreSQL
        for row in csv_reader:
            # Sanitize data if needed
            row = sanitize_data(row)

            # Check if the row already exists
            cursor.execute("SELECT COUNT(*) FROM {} WHERE {} = %s".format(table_name, '"{}"'.format(columns[0])), [row[columns[0]]])
            row_count = cursor.fetchone()[0]

            if row_count > 0:
                # If the row already exists, update it
                update_columns = ', '.join(['{} = %s'.format('"{}"'.format(col)) for col in columns[1:]])
                query = "UPDATE {} SET {} WHERE {} = %s".format(table_name, update_columns, '"{}"'.format(columns[0]))
                cursor.execute(query, [row[col] for col in columns[1:]] + [row[columns[0]]])
                print("Data for '{}' updated in the database successfully.".format(row[columns[0]]))
            else:
                # If the row does not exist, insert it
                placeholders = ', '.join(['%s'] * len(columns))
                insert_query = "INSERT INTO {} ({}) VALUES ({})".format(table_name, ', '.join(['"{}"'.format(col) for col in columns]), placeholders)
                cursor.execute(insert_query, list(row.values()))
                print("Data for '{}' inserted into the database successfully.".format(row[columns[0]]))

    # Commit and close connection
    conn.commit()
    conn.close()

# Main function
def main():
    # Configuration
    csv_directory = 'C:/Users/user/Downloads/Data-Exercise#2-C316/'
    host = 'localhost'
    database = 'data_pipeline_db'
    user = 'postgres'
    password = 'password'

    # Process each CSV file in the directory
    for filename in os.listdir(csv_directory):
        if filename.endswith('.csv'):
            csv_file = os.path.join(csv_directory, filename)
            process_csv_and_insert(csv_file, host, database, user, password)

if __name__ == "__main__":
    main()
