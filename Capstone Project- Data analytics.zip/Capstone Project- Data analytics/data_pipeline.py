import matplotlib.pyplot as plt
import os
import pyodbc
import pandas as pd
import csv
import seaborn as sns

# Function to perform data cleansing
def data_preprocessing(data):
    try:
        # Fill missing values with 0 for numeric columns
        for key, value in data.items():
            if value == '':
                data[key] = 0.0

        # Convert dictionary to DataFrame
        df = pd.DataFrame([data])

        # Convert numeric columns to appropriate data types
        numeric_columns = ['price', 'area', 'bedrooms', 'bathrooms', 'stories', 'parking']
        for column in numeric_columns:
            df[column] = pd.to_numeric(df[column], errors='coerce')

        # Check for null values and remove them if necessary
        df = df.dropna()  # Remove rows with null values

        # Perform additional data cleaning tasks as needed
        df = df.drop_duplicates()  # Remove duplicate rows

        # Convert DataFrame back to dictionary
        cleansed_data = df.to_dict(orient='records')[0]

        return cleansed_data
    except Exception as e:
        print("Error cleansing data:")
        print(e)
        print("Data:")
        print(data)
        return None


# Function to create table based on CSV file columns
def create_table(cursor, table_name, columns):
    # Define data types for each column explicitly
    data_types = {
        'price': 'FLOAT',
        'area': 'FLOAT',
        'bedrooms': 'FLOAT',
        'bathrooms': 'FLOAT',
        'stories': 'FLOAT',
        'parking': 'FLOAT',
        'mainroad': 'VARCHAR(3)',
        'guestroom': 'VARCHAR(3)',
        'basement': 'VARCHAR(3)',
        'hotwaterheating': 'VARCHAR(3)',
        'airconditioning': 'VARCHAR(3)',
        'prefarea': 'VARCHAR(3)',
        'furnishingstatus': 'VARCHAR(50)'
    }

    # Construct CREATE TABLE query
    column_defs = ['{} {}'.format(column, data_types.get(column, 'VARCHAR(3)')) for column in columns]
    query = "IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = '{}') CREATE TABLE {} ({})".format(
        table_name, table_name, ', '.join(column_defs))

    # Execute query
    cursor.execute(query)


# Function to read CSV file and insert or update data into SQL Server database
def load_preprocessed_data_into_database(csv_file, server, database):
    try:
        # Connection string with Windows authentication
        conn_str = 'DRIVER={SQL Server};SERVER=' + server + ';DATABASE=' + database + ';Trusted_Connection=yes;'
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        # Get table name from CSV file
        table_name = os.path.splitext(os.path.basename(csv_file))[0]

        # Read CSV file
        with open(csv_file, 'r') as file:
            csv_reader = csv.DictReader(file)
            columns = csv_reader.fieldnames

            # Create table if not exists
            create_table(cursor, table_name, columns)

            # Insert data into SQL Server
            for row in csv_reader:
                # Cleanse data if needed
                row = data_preprocessing(row)

                # Prepare columns and values for insertion
                placeholders = ', '.join(['?'] * len(row))
                insert_query = "INSERT INTO {} ({}) VALUES ({})".format(table_name, ', '.join(row.keys()),
                                                                        placeholders)
                values = list(row.values())

                # Execute insert query
                cursor.execute(insert_query, values)
                print("Data inserted into the database successfully.")

        # Commit and close connection
        conn.commit()
        conn.close()
        print("Processed:", csv_file)
    except Exception as e:
        print("Error processing:", csv_file)
        print(e)


# Function to create histogram
def histogram(data, save_path):
    plt.figure(figsize=(10, 6))
    plt.hist(data['price'], bins=20, color='skyblue', edgecolor='black')
    plt.title('Price Distribution')
    plt.xlabel('Price')
    plt.ylabel('Frequency')
    plt.grid(True)
    plt.savefig(os.path.join(save_path, 'histogram.png'))
    plt.close()


# Function to create bar plot
def bar_plot(data, save_path):
    plt.figure(figsize=(10, 6))
    data['furnishingstatus'].value_counts().plot(kind='bar', color='skyblue')
    plt.title('Distribution of Furnishing Status')
    plt.xlabel('Furnishing Status')
    plt.ylabel('Count')
    plt.grid(True)
    plt.savefig(os.path.join(save_path, 'bar_plot.png'))
    plt.close()


# Function to create scatter plot matrix
def scatter_matrix(data, save_path):
    sns.pairplot(data)
    plt.suptitle('Pair Plot of Housing Features', y=1.02)
    plt.savefig(os.path.join(save_path, 'scatter_matrix.png'))
    plt.close()


# Main function
def main():
    csv_file = 'C:/Users/user/Downloads/Capstone Project- Data analytics/Housing.csv'
    server = 'MY-DESKTOP'
    database = 'data_pipeline_database'
    save_path = 'C:/Users/user/Downloads/Capstone Project- Data analytics/'

    # Load data from the CSV file
    data = pd.read_csv(csv_file)

    # Visualization methods
    histogram(data, save_path)
    bar_plot(data, save_path)
    scatter_matrix(data, save_path)

    # Insert data into the database
    load_preprocessed_data_into_database(csv_file, server, database)


if __name__ == "__main__":
    main()
