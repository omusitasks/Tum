#!/bin/bash

# Create DynamoDB table
aws dynamodb create-table \
    --table-name ProductInventory \
    --attribute-definitions AttributeName=productID,AttributeType=S \
    --key-schema AttributeName=productID,KeyType=HASH \
    --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5

# Put (Insert) item into DynamoDB
aws dynamodb put-item \
    --table-name ProductInventory \
    --item '{
        "productID": {"S": "P001"},
        "name": {"S": "Wireless Mouse"},
        "category": {"S": "Electronics"},
        "price": {"N": "29.99"},
        "stockQuantity": {"N": "150"}
    }'

# Get item by productID from DynamoDB
aws dynamodb get-item \
    --table-name ProductInventory \
    --key '{"productID": {"S": "P001"}}'

# Delete item from DynamoDB
aws dynamodb delete-item \
    --table-name ProductInventory \
    --key '{"productID": {"S": "P001"}}'
