import pandas as pd

# Define customer demographics data
data = {
    "Customer ID": ["CUST021", "CUST022", "CUST023", "CUST024", "CUST025", 
                    "CUST026", "CUST027", "CUST028", "CUST029", "CUST030"],
    "Age": [65, 33, 19, 48, 27, 70, 52, 14, 31, 20],
    "Location": ["Seattle", "Miami", "Atlanta", "Dallas", "San Francisco", 
                 "Houston", "Phoenix", "Austin", "Denver", "Boston"],
    "Gender": ["Male", "Female", "Male", "Female", "Male", 
               "Male", "Female", "Male", "Female", "Male"],
    "Purchase History (Sample)": [
        "Golf Clubs (Senior Flex), Golf Balls",
        "Running Shoes (Women's), Fitness Tracker",
        "Basketball (Men's), Basketball Shorts",
        "Tennis Apparel, Tennis Racket",
        "Baseball Bat (Composite), Baseball Cleats",
        "Walking Shoes, Comfortable Clothing",
        "Yoga Mat, Resistance Bands (Light)",
        "Baseball Jersey (Youth), Baseball Hat",
        "Hiking Boots, Backpack",
        "Bicycle (Adult), Bicycle Helmet, Cycling Shorts"
    ]
}

# Create a DataFrame
df = pd.DataFrame(data)

# Export to CSV
df.to_csv("customer.csv", index=False)

print("customer.csv file has been successfully created!")
