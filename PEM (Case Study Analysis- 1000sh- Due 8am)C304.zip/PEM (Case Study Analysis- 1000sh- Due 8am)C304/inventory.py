import pandas as pd

# Define the inventory data
data = {
    "Product ID": [
        "ABC001", "ABC002", "ABC003", "ABC004", "ABC005", "ABC006", "ABC007", "ABC008", "ABC009", "ABC010",
        "ABC011", "ABC012", "ABC013", "ABC014", "ABC015", "ABC016", "ABC017", "ABC018", "ABC019", "ABC020"
    ],
    "Product Name": [
        "Running Shoes (Men's)", "Tennis Racket", "Baseball Jersey (Youth)", "Yoga Pants (Women's)", "Basketball (Men's)",
        "Sports Bra (Women's)", "Baseball Bat (Aluminum)", "Baseball Glove (Youth)", "Soccer Ball", "Yoga Mat",
        "Water Bottle (Stainless Steel)", "Running Shorts (Men's)", "Tennis Balls (Can)", "Badminton Racket", "Fitness Tracker",
        "Hiking Backpack", "Camping Tent", "Sleeping Bag", "Bicycle Helmet", "Bicycle (Adult)"
    ],
    "Units on Hand": [
        25, 10, 40, 15, 32, 20, 18, 25, 48, 12,
        35, 17, 85, 6, 22, 10, 5, 8, 14, 3
    ],
    "Purchase Price": [
        75.00, 120.00, 25.00, 40.00, 85.00, 30.00, 55.00, 22.00, 38.00, 45.00,
        15.00, 28.00, 5.00, 60.00, 99.00, 130.00, 180.00, 125.00, 50.00, 450.00
    ],
    "Lead Time (Days)": [
        30, 45, 20, 15, 40, 25, 35, 15, 20, 10,
        20, 18, 15, 40, 30, 50, 60, 45, 25, 90
    ]
}

# Create a DataFrame
df = pd.DataFrame(data)

# Export to CSV
df.to_csv("inventory.csv", index=False)

print("inventory.csv has been created successfully!")
