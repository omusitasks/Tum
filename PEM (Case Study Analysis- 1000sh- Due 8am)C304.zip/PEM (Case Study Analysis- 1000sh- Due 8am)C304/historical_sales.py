import pandas as pd

# Define the data as a list of dictionaries
data = [
    {"Month": "Jan-2023", "Product Category": "Apparel", "Brand": "Nike", "Store Location": "Chicago", "Units Sold": 120},
    {"Month": "Jan-2023", "Product Category": "Footwear", "Brand": "Adidas", "Store Location": "New York", "Units Sold": 80},
    {"Month": "Jan-2023", "Product Category": "Equipment", "Brand": "Wilson", "Store Location": "Los Angeles", "Units Sold": 50},
    {"Month": "Feb-2023", "Product Category": "Apparel", "Brand": "Under Armour", "Store Location": "Chicago", "Units Sold": 100},
    {"Month": "Feb-2023", "Product Category": "Footwear", "Brand": "New Balance", "Store Location": "New York", "Units Sold": 75},
    {"Month": "Feb-2023", "Product Category": "Equipment", "Brand": "Spalding", "Store Location": "Los Angeles", "Units Sold": 40},
    {"Month": "Mar-2023", "Product Category": "Apparel", "Brand": "The North Face", "Store Location": "Chicago", "Units Sold": 85},
    {"Month": "Mar-2023", "Product Category": "Footwear", "Brand": "Brooks", "Store Location": "New York", "Units Sold": 60},
    {"Month": "Mar-2023", "Product Category": "Equipment", "Brand": "Rawlings", "Store Location": "Los Angeles", "Units Sold": 35},
    {"Month": "Apr-2023", "Product Category": "Apparel", "Brand": "Columbia", "Store Location": "Chicago", "Units Sold": 110},
    {"Month": "Apr-2023", "Product Category": "Footwear", "Brand": "Asics", "Store Location": "New York", "Units Sold": 90},
    {"Month": "Apr-2023", "Product Category": "Equipment", "Brand": "Easton", "Store Location": "Los Angeles", "Units Sold": 65},
    {"Month": "May-2023", "Product Category": "Apparel", "Brand": "Patagonia", "Store Location": "Chicago", "Units Sold": 70},
    {"Month": "May-2023", "Product Category": "Footwear", "Brand": "Saucony", "Store Location": "New York", "Units Sold": 55},
    {"Month": "May-2023", "Product Category": "Equipment", "Brand": "Marucci", "Store Location": "Los Angeles", "Units Sold": 42},
    {"Month": "Jun-2023", "Product Category": "Apparel", "Brand": "Arc'teryx", "Store Location": "Chicago", "Units Sold": 95},
    {"Month": "Jun-2023", "Product Category": "Footwear", "Brand": "Hoka One One", "Store Location": "New York", "Units Sold": 82},
    {"Month": "Jun-2023", "Product Category": "Equipment", "Brand": "Mizuno", "Store Location": "Los Angeles", "Units Sold": 58},
    {"Month": "Jul-2023", "Product Category": "Apparel", "Brand": "Outdoor Research", "Store Location": "Chicago", "Units Sold": 68},
    {"Month": "Jul-2023", "Product Category": "Footwear", "Brand": "Altra", "Store Location": "New York", "Units Sold": 48},
    {"Month": "Jul-2023", "Product Category": "Equipment", "Brand": "Louisville Slugger", "Store Location": "Los Angeles", "Units Sold": 30},
    {"Month": "Aug-2023", "Product Category": "Apparel", "Brand": "Mountain Hardwear", "Store Location": "Chicago", "Units Sold": 102},
    {"Month": "Aug-2023", "Product Category": "Footwear", "Brand": "On Running", "Store Location": "New York", "Units Sold": 79},
    {"Month": "Aug-2023", "Product Category": "Equipment", "Brand": "DeMarini", "Store Location": "Los Angeles", "Units Sold": 61},
    {"Month": "Sep-2023", "Product Category": "Apparel", "Brand": "Marmot", "Store Location": "Chicago", "Units Sold": 80},
    {"Month": "Sep-2023", "Product Category": "Footwear", "Brand": "Salomon", "Store Location": "New York", "Units Sold": 65},
    {"Month": "Sep-2023", "Product Category": "Equipment", "Brand": "Victrix", "Store Location": "Los Angeles", "Units Sold": 45},
    {"Month": "Oct-2023", "Product Category": "Apparel", "Brand": "Patagonia", "Store Location": "Chicago", "Units Sold": 98},
    {"Month": "Oct-2023", "Product Category": "Footwear", "Brand": "Hoka One One", "Store Location": "New York", "Units Sold": 87},
    {"Month": "Oct-2023", "Product Category": "Equipment", "Brand": "Easton", "Store Location": "Los Angeles", "Units Sold": 62},
    {"Month": "Nov-2023", "Product Category": "Apparel", "Brand": "The North Face", "Store Location": "Chicago", "Units Sold": 115},
    {"Month": "Nov-2023", "Product Category": "Footwear", "Brand": "Brooks", "Store Location": "New York", "Units Sold": 92},
    {"Month": "Nov-2023", "Product Category": "Equipment", "Brand": "Rawlings", "Store Location": "Los Angeles", "Units Sold": 70},
    {"Month": "Dec-2023", "Product Category": "Apparel", "Brand": "Columbia", "Store Location": "Chicago", "Units Sold": 89},
    {"Month": "Dec-2023", "Product Category": "Footwear", "Brand": "Asics", "Store Location": "New York", "Units Sold": 71},
    {"Month": "Dec-2023", "Product Category": "Equipment", "Brand": "Spalding", "Store Location": "Los Angeles", "Units Sold": 53}
]

# Convert to DataFrame
df = pd.DataFrame(data)

# Export to CSV
csv_filename = "historical_sales.csv"
df.to_csv(csv_filename, index=False)

print(f"CSV file '{csv_filename}' has been created successfully.")
