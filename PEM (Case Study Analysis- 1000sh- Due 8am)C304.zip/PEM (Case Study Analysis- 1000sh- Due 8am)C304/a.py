import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load datasets
customer_df = pd.read_csv("customer.csv")
sales_df = pd.read_csv("historical_sales.csv")
inventory_df = pd.read_csv("inventory.csv")

# Data Cleaning & Preparation
## Check for missing values
print("Missing Values in Customer Data:\n", customer_df.isnull().sum())
print("Missing Values in Sales Data:\n", sales_df.isnull().sum())
print("Missing Values in Inventory Data:\n", inventory_df.isnull().sum())

## Convert Month column to datetime
sales_df['Month'] = pd.to_datetime(sales_df['Month'], format='%b-%Y')

## Ensure numeric data types
customer_df['Age'] = pd.to_numeric(customer_df['Age'], errors='coerce')
inventory_df['Units on Hand'] = pd.to_numeric(inventory_df['Units on Hand'], errors='coerce')
inventory_df['Purchase Price'] = pd.to_numeric(inventory_df['Purchase Price'], errors='coerce')
inventory_df['Lead Time (Days)'] = pd.to_numeric(inventory_df['Lead Time (Days)'], errors='coerce')

# Exploratory Data Analysis (EDA)

## Sales Analysis
### Top-selling product categories & brands
top_selling_products = sales_df.groupby(['Product Category', 'Brand'])['Units Sold'].sum().reset_index()
top_selling_products = top_selling_products.sort_values(by='Units Sold', ascending=False)

plt.figure(figsize=(8, 5))
sns.barplot(x='Units Sold', y='Brand', data=top_selling_products, hue='Product Category')
plt.title("Top-Selling Product Categories & Brands")
plt.show()

### Sales trends over time
plt.figure(figsize=(8, 5))
sns.lineplot(x='Month', y='Units Sold', data=sales_df, hue='Product Category', marker='o')
plt.title("Sales Trends Over Time")
plt.xticks(rotation=45)
plt.show()

## Inventory Analysis
### Stock Levels vs. Sales
sales_by_product = sales_df.groupby('Product Category')['Units Sold'].sum()
inventory_by_product = inventory_df.groupby('Product Name')['Units on Hand'].sum()

inventory_vs_sales = pd.DataFrame({'Units Sold': sales_by_product, 'Units on Hand': inventory_by_product}).fillna(0)

plt.figure(figsize=(8, 5))
inventory_vs_sales.plot(kind='bar', stacked=True)
plt.title("Stock Levels vs. Sales")
plt.show()

### Lead Time Impact on Stockouts
plt.figure(figsize=(8, 5))
sns.scatterplot(x='Lead Time (Days)', y='Units on Hand', data=inventory_df)
plt.title("Lead Time vs. Stock Levels")
plt.show()

## Customer Segmentation
### Age-wise purchases
plt.figure(figsize=(8, 5))
sns.histplot(customer_df['Age'], bins=5, kde=True)
plt.title("Customer Age Distribution")
plt.show()

### Gender-based purchase patterns
plt.figure(figsize=(8, 5))
sns.countplot(x='Gender', data=customer_df)
plt.title("Gender Distribution of Customers")
plt.show()
