import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load datasets
historical_sales = pd.read_csv("historical_sales.csv")
inventory = pd.read_csv("inventory.csv")
customer = pd.read_csv("customer.csv")

# Data Cleaning & Preparation
## Checking for missing values
# print("Missing values in sales data:\n", historical_sales.isnull().sum())
# print("Missing values in inventory data:\n", inventory.isnull().sum())
# print("Missing values in customer data:\n", customer.isnull().sum())

## Convert data types
customer['Age'] = pd.to_numeric(customer['Age'], errors='coerce')
historical_sales['Month'] = pd.to_datetime(historical_sales['Month'], format='%b-%Y')
inventory['Purchase Price'] = pd.to_numeric(inventory['Purchase Price'], errors='coerce')

# Standardizing categorical values
historical_sales['Product Category'] = historical_sales['Product Category'].str.title()
historical_sales['Brand'] = historical_sales['Brand'].str.title()
historical_sales['Store Location'] = historical_sales['Store Location'].str.title()
customer['Gender'] = customer['Gender'].str.title()
customer['Location'] = customer['Location'].str.title()
inventory['Product Name'] = inventory['Product Name'].str.title()

# Exploratory Data Analysis (EDA)
## Sales & Demand Analysis
# Top-selling product categories & brands
category_sales = historical_sales.groupby('Product Category')['Units Sold'].sum().sort_values(ascending=False)
brand_sales = historical_sales.groupby('Brand')['Units Sold'].sum().sort_values(ascending=False)

# Seasonality & trends in sales
monthly_sales = historical_sales.groupby('Month')['Units Sold'].sum()
plt.figure(figsize=(12,9))
sns.lineplot(x=monthly_sales.index.astype(str), y=monthly_sales.values)
plt.xticks(rotation=45)
plt.title("Monthly Sales Trend")
plt.savefig("seasonality.png")  # Save the figure instead


# Store-level demand differences
store_sales = historical_sales.groupby('Store Location')['Units Sold'].sum().sort_values(ascending=False)

# Product-category sales distribution
plt.figure(figsize=(10,9))
sns.boxplot(x='Product Category', y='Units Sold', data=historical_sales)
plt.xticks(rotation=45)
plt.title("Sales Distribution by Product Category")
plt.savefig("product_category_sales.png")

## Inventory Management Analysis
# Stock Levels vs. Sales
total_inventory_sales = inventory.merge(historical_sales, left_on='Product Name', right_on='Product Category', how='left')

overstocked = total_inventory_sales[(total_inventory_sales['Units on Hand'] > 100) & (total_inventory_sales['Units Sold'] < 50)]
stockout_prone = total_inventory_sales[(total_inventory_sales['Units on Hand'] < 10) & (total_inventory_sales['Units Sold'] > 50)]

# Lead Time Impact
lead_time_impact = total_inventory_sales.groupby('Product Name')[['Lead Time (Days)', 'Units Sold']].mean()

# Cost of Inventory
inventory['Total Inventory Cost'] = inventory['Units on Hand'] * inventory['Purchase Price']

## Customer Segmentation & Buying Patterns
# Age-wise & gender-based purchases
customer_sales = customer.merge(historical_sales, left_on='Location', right_on='Store Location', how='left')
age_sales = customer_sales.groupby('Age')['Units Sold'].sum()
gender_sales = customer_sales.groupby('Gender')['Units Sold'].sum()

# Regional buying behavior
region_sales = historical_sales.groupby('Store Location')['Units Sold'].sum()

# Customer retention
customer_purchase_counts = customer_sales.groupby('Customer ID').size()
repeat_customers = customer_purchase_counts[customer_purchase_counts > 1]

# Display results
print("Top-selling product categories:\n", category_sales.head())
print("Top-selling brands:\n", brand_sales.head())
print("Store-wise sales:\n", store_sales)

