import os
import csv
import pyodbc
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Function to perform data cleansing
def cleanse_data(data):
    # Convert dictionary to DataFrame
    df = pd.DataFrame([data])

    # Convert numeric columns to appropriate data types
    numeric_columns = ['fixed_acidity', 'volatile_acidity', 'citric_acid', 'residual_sugar', 'chlorides', 'free_sulfur_dioxide', 'total_sulfur_dioxide', 'density', 'pH', 'sulphates', 'alcohol', 'quality', 'Id']
    for column in numeric_columns:
        df[column] = pd.to_numeric(df[column], errors='coerce')

    # Convert non-numeric columns to string
    string_columns = []
    for column in string_columns:
        df[column] = df[column].astype(str)

    # Check for null values and remove them if necessary
    df = df.dropna()  # Remove rows with null values

    # Perform additional data cleaning tasks as needed
    df = df.drop_duplicates()  # Remove duplicate rows

    # Convert DataFrame back to dictionary
    cleansed_data = df.to_dict(orient='records')[0]

    return cleansed_data

# Function to create table based on CSV file columns
def create_table(cursor, table_name, columns):
    # Define data types for each column explicitly
    data_types = {
        'Id': 'INT IDENTITY(1,1) PRIMARY KEY',
        'fixed_acidity': 'FLOAT',
        'volatile_acidity': 'FLOAT',
        'citric_acid': 'FLOAT',
        'residual_sugar': 'FLOAT',
        'chlorides': 'FLOAT',
        'free_sulfur_dioxide': 'FLOAT',
        'total_sulfur_dioxide': 'FLOAT',
        'density': 'FLOAT',
        'pH': 'FLOAT',
        'sulphates': 'FLOAT',
        'alcohol': 'FLOAT',
        'quality': 'INT'
    }

    # Construct CREATE TABLE query
    column_defs = ['{} {}'.format(column, data_types[column]) for column in columns]
    query = "IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = '{}') CREATE TABLE {} ({})".format(table_name, table_name, ', '.join(column_defs))

    # Execute query
    cursor.execute(query)

# Function to read CSV file and insert or update data into SQL Server database
def process_csv_and_insert(csv_file, server, database):
    try:
        # Connection string with Windows authentication
        conn_str = 'DRIVER={SQL Server};SERVER='+server+';DATABASE='+database+';Trusted_Connection=yes;'
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        # Get table name from CSV file
        table_name = os.path.splitext(os.path.basename(csv_file))[0]

        # Read CSV file
        with open(csv_file, 'r') as file:
            csv_reader = csv.DictReader(file)
            columns = csv_reader.fieldnames

            # Create table if not exists
            create_table(cursor, table_name, columns)

            # Insert data into SQL Server
            for row in csv_reader:
                # Cleanse data if needed
                row = cleanse_data(row)

                # Prepare columns and values for insertion
                placeholders = ', '.join(['?'] * len(row))
                insert_query = "INSERT INTO {} ({}) VALUES ({})".format(table_name, ', '.join(row.keys()), placeholders)
                values = list(row.values())

                # Enable IDENTITY_INSERT
                cursor.execute("SET IDENTITY_INSERT {} ON".format(table_name))

                # Execute insert query
                cursor.execute(insert_query, values)
                print("Data inserted into the database successfully.")

                # Disable IDENTITY_INSERT
                cursor.execute("SET IDENTITY_INSERT {} OFF".format(table_name))

        # Commit and close connection
        conn.commit()
        conn.close()
        print("Processed:", csv_file)
    except Exception as e:
        print("Error processing:", csv_file)
        print(e)

# Function to create scatter plot
def scatter_plot(data, save_path):
    plt.figure(figsize=(10, 6))
    plt.scatter(data['fixed_acidity'], data['volatile_acidity'], c=data['quality'], cmap='viridis', alpha=0.5)
    plt.title('Fixed Acidity vs Volatile Acidity')
    plt.xlabel('Fixed Acidity')
    plt.ylabel('Volatile Acidity')
    plt.colorbar(label='Quality')
    plt.grid(True)
    plt.savefig(os.path.join(save_path, 'scatter_plot.png'))
    plt.close()

# Function to create histogram
def histogram(data, save_path):
    plt.figure(figsize=(10, 6))
    plt.hist(data['alcohol'], bins=20, color='skyblue', edgecolor='black')
    plt.title('Alcohol Content Distribution')
    plt.xlabel('Alcohol')
    plt.ylabel('Frequency')
    plt.grid(True)
    plt.savefig(os.path.join(save_path, 'histogram.png'))
    plt.close()

# Function to create box plot
def box_plot(data, save_path):
    plt.figure(figsize=(10, 6))
    sns.boxplot(x='quality', y='citric_acid', data=data, palette='viridis')
    plt.title('Box Plot of Citric Acid Content by Quality')
    plt.xlabel('Quality')
    plt.ylabel('Citric Acid')
    plt.grid(True)
    plt.savefig(os.path.join(save_path, 'box_plot.png'))
    plt.close()

# Function to create pair plot
def pair_plot(data, save_path):
    sns.pairplot(data, vars=['fixed_acidity', 'volatile_acidity', 'citric_acid', 'alcohol'], hue='quality', palette='viridis')
    plt.suptitle('Pair Plot of Wine Features by Quality', y=1.02)
    plt.savefig(os.path.join(save_path, 'pair_plot.png'))
    plt.close()

# Main function
def main():
    # Configuration
    csv_directory = 'C:/Users/user/Downloads/Capstone project/'
    server = 'DESKTOP-CUAKVNF'
    database = 'etl_pipeline_db'
    save_path = 'C:/Users/user/Downloads/Capstone project/'

    # Process each CSV file in the directory
    for filename in os.listdir(csv_directory):
        if filename.endswith('.csv'):
            csv_file = os.path.join(csv_directory, filename)
            process_csv_and_insert(csv_file, server, database)
            # Load data from the inserted CSV file
            data = pd.read_csv(csv_file)
            # Visualization methods
            scatter_plot(data, save_path)
            histogram(data, save_path)
            box_plot(data, save_path)
            pair_plot(data, save_path)
            # Stop processing after inserting/updating data and generating visualizations
            break

if __name__ == "__main__":
    main()
