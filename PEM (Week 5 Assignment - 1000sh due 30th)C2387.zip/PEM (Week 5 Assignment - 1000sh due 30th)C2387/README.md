# OIDC Single-Page Application (SPA)

## Description
This is a simple SPA that uses OpenID Connect (OIDC) for authentication with a chosen provider (e.g., Google). After login, it displays basic demographic information about the user.

## Setup Instructions
1. Clone the repository.
2. Navigate to the project directory.
3. Run `npm install` to install dependencies.
4. Replace `YOUR_CLIENT_ID` in `src/oidcConfig.js` with your OIDC client credentials.
5. Run the app using `npm start`.

## Features
- OIDC authentication
- User info display
- Responsive design
