import { oidcClient } from './oidcConfig.js';

document.getElementById('login-button').addEventListener('click', () => {
  oidcClient.signinRedirect();
});

document.getElementById('logout-button').addEventListener('click', () => {
  oidcClient.signoutRedirect();
});

oidcClient.events.addUserLoaded(user => {
  document.getElementById('login-button').style.display = 'none';
  document.getElementById('logout-button').style.display = 'block';
  document.getElementById('user-info').style.display = 'block';

  document.getElementById('user-name').innerText = `Name: ${user.profile.name}`;
  document.getElementById('user-email').innerText = `Email: ${user.profile.email}`;
});

oidcClient.events.addUserUnloaded(() => {
  document.getElementById('login-button').style.display = 'block';
  document.getElementById('logout-button').style.display = 'none';
  document.getElementById('user-info').style.display = 'none';
});
