import { UserManager } from 'oidc-client';

const oidcConfig = {
  authority: 'https://accounts.google.com', // Replace with your OIDC provider
  client_id: 'YOUR_CLIENT_ID',
  redirect_uri: window.location.origin,
  response_type: 'id_token token',
  scope: 'openid profile email',
};

export const oidcClient = new UserManager(oidcConfig);
