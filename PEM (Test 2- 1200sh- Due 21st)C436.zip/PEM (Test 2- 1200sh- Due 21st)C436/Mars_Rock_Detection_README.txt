
# Mars Rock Detection Using YOLO and ROS

## Installation Steps

### 1. Install WSL and Ubuntu
```bash
wsl --install -d Ubuntu
```

### 2. Install ROS 2
Follow the [ROS 2 Installation Guide](https://docs.ros.org/en/humble/Installation.html).
```bash
sudo apt install ros-humble-desktop
```

### 3. Install Python and Required Libraries
```bash
sudo apt install python3 python3-pip
pip install ultralytics opencv-python rclpy
```

### 4. Install YOLO and Model
- Clone YOLO:
  ```bash
  git clone https://github.com/ultralytics/ultralytics.git
  cd ultralytics
  pip install -e .
  ```
- Download Mars Rock Detection Dataset from [RoboFlow](https://universe.roboflow.com/ritesh-laf7m/mars-rocks-detection).
- Train the YOLO model on the dataset.

### 5. Setup Turtlesim
```bash
sudo apt install ros-humble-turtlesim
```

---

## How to Run

### 1. Start ROS Core
```bash
source /opt/ros/humble/setup.bash
```

### 2. Run Input Node
```bash
python3 input_node.py
```

### 3. Run Detection Node
```bash
python3 detection_node.py
```

### 4. Run Turtlesim Node
```bash
ros2 run turtlesim turtlesim_node
python3 turtlesim_node.py
```

---

## System Flow

1. **Input Node**: Captures frames from webcam or video and publishes them to the `camera_feed` topic.
2. **Detection Node**: Subscribes to `camera_feed`, detects rocks using YOLO, and publishes rock positions to `rock_positions`.
3. **Turtlesim Node**: Subscribes to `rock_positions` and moves toward the largest rock.

---

## Dataset and Model Information

### 1. Dataset
- Download Mars Rock Detection Dataset from [RoboFlow](https://universe.roboflow.com/ritesh-laf7m/mars-rocks-detection).
- Follow RoboFlow instructions to preprocess the dataset.

### 2. Model
- Use YOLO v8.
- Train the model with:
  ```bash
  yolo train model=yolov8n.pt data=path_to_dataset.yaml epochs=50 imgsz=640
  ```
- Save the trained model as `best.pt`.
