import rclpy
from rclpy.node import Node
from turtlesim.srv import SetPen
from geometry_msgs.msg import Twist

class TurtlesimNode(Node):
    def __init__(self):
        super().__init__('turtlesim_node')
        self.subscription = self.create_subscription(String, 'rock_positions', self.move_turtle, 10)
        self.publisher = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)

    def move_turtle(self, msg):
        # Parse rock position and move the turtle
        position = eval(msg.data)  # Example: [x_min, y_min, x_max, y_max, confidence, class]
        x_center = (position[0] + position[2]) / 2
        y_center = (position[1] + position[3]) / 2

        twist = Twist()
        twist.linear.x = 0.5  # Move forward
        twist.angular.z = 0.5 * (x_center - 640) / 640  # Adjust angular velocity
        self.publisher.publish(twist)

def main(args=None):
    rclpy.init(args=args)
    turtlesim_node = TurtlesimNode()
    rclpy.spin(turtlesim_node)
    turtlesim_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
