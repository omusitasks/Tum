import rclpy
from rclpy.node import Node
from ultralytics import YOLO
from std_msgs.msg import String

class DetectionNode(Node):
    def __init__(self):
        super().__init__('detection_node')
        self.subscription = self.create_subscription(
            String,
            'camera_feed',
            self.detect_rocks,
            10
        )
        self.publisher = self.create_publisher(String, 'rock_positions', 10)
        self.yolo = YOLO('yolov8n.pt')  # Load YOLO model

    def detect_rocks(self, msg):
        frame = np.frombuffer(msg.data, dtype=np.uint8).reshape((720, 1280, 3))  # Adjust dimensions
        results = self.yolo(frame)
        for result in results.xyxy:
            self.publisher.publish(str(result.tolist()))

def main(args=None):
    rclpy.init(args=args)
    detection_node = DetectionNode()
    rclpy.spin(detection_node)
    detection_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
