import rclpy
from rclpy.node import Node
import cv2

class InputNode(Node):
    def __init__(self):
        super().__init__('input_node')
        self.publisher = self.create_publisher(String, 'camera_feed', 10)
        self.timer = self.create_timer(0.1, self.capture_frame)
        self.cap = cv2.VideoCapture(0)  # 0 for webcam, or provide a video file path

    def capture_frame(self):
        ret, frame = self.cap.read()
        if ret:
            # Publish the frame
            msg = String()
            msg.data = frame.tobytes()
            self.publisher.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    input_node = InputNode()
    rclpy.spin(input_node)
    input_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
