#ifndef PRO_OS_H
#define PRO_OS_H

#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/signal.h>
#include <pthread.h>

#include <fcntl.h> 
#define NUM_FLAVORS 4
#define RING_BUFFER_SIZE 100

typedef struct {
  int in;
  int out;
  int donuts[RING_BUFFER_SIZE];
} RingBuffer;

typedef struct {
  RingBuffer buffers[NUM_FLAVORS];
  sem_t mutexes[NUM_FLAVORS];
} SharedMemory;

SharedMemory *get_shared_memory();
void free_shared_memory(SharedMemory *shm);
void Prod(SharedMemory *shm);
void Cons(SharedMemory *shm);
void readAndOutputFile(const char *filename);

#endif
