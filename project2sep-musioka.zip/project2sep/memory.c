#include "pro_Os.h"

SharedMemory *get_shared_memory() {
    SharedMemory *shm = (SharedMemory *)shmat(shmget(IPC_PRIVATE, sizeof(SharedMemory), 0666), NULL, 0);
    if (shm == (SharedMemory *)-1) {
        perror("shmat");
        exit(1);
    }

    for (int i = 0; i < NUM_FLAVORS; i++) {
        shm->buffers[i].in = 0;
        shm->buffers[i].out = 0;
        sem_init(&shm->mutexes[i], 1, 1);
    }

    return shm;
}

void free_shared_memory(SharedMemory *shm) {
    shmdt(shm);
}

// Function to read and output the contents of a file
void readAndOutputFile(const char *filename) {
    char buffer[1024];
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("fopen");
        exit(1);
    }

    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        printf("%s", buffer);
    }

    fclose(file);
}
