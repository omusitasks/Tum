
#include "pro_Os.h"
#define SEMKEY 549351763
#define MEMKEY 549351763
#define NUMFLAVORS 4
#define NUMSLOTS 100
#define NUMSEMIDS 3
#define NUMDZ 50
#define PROD 0
#define CONSUMER 1

#define OUTPTR 2

struct donut_ring {
    int flavor[NUMFLAVORS][NUMSLOTS];
    int outptr[NUMFLAVORS];
};

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short int *array;
};

int shmid, semid[3];
struct donut_ring *shared_ring;

void sig_handler(int sig) {
    int i, j, k;

    printf("In signal handler with signal # %d\n", sig);

    if (shmctl(shmid, IPC_RMID, 0) == -1) {
        perror("handler failed shm RMID: ");
    }
    for (i = 0; i < NUMSEMIDS; i++) {
        if (semctl(semid[i], 0, IPC_RMID) == -1) {
            perror("handler failed sem RMID: ");
        }
    }
    exit(5);
}

int p(int semidgroup, int donut_type) {
    struct sembuf semopbuf;
    semopbuf.sem_num = donut_type;
    semopbuf.sem_op = -1; // P operation
    semopbuf.sem_flg = 0;

    if (semop(semidgroup, &semopbuf, 1) == -1) {
        return -1;
    }
    return 0;
}

int v(int semidgroup, int donut_type) {
    struct sembuf semopbuf;
    semopbuf.sem_num = donut_type;
    semopbuf.sem_op = 1; // V operation
    semopbuf.sem_flg = 0;

    if (semop(semidgroup, &semopbuf, 1) == -1) {
        return -1;
    }
    return 0;
}

int semsetall(int semgroup, int number_in_group, int set_all_value) {
    int i;
    union semun sem_ctl_un;

    sem_ctl_un.val = set_all_value; // for command SETVAL
    for (i = 0; i < number_in_group; i++) {
        if (semctl(semgroup, i, SETVAL, sem_ctl_un) == -1) {
            return -1;
        }
    }
    return 0;
}

void *producer(void *arg) {
    int in_ptr[NUMFLAVORS];
    int serial[NUMFLAVORS];
    int i, j, k;
    struct timeval randtime;

    // Initialize in_ptr and serial counters
    for (i = 0; i < NUMFLAVORS; i++) {
        in_ptr[i] = 0;
        serial[i] = 0;
    }

    // Initialize signal handling
    void sig_handler(int);
    sigset_t mask_sigs;
    int nsigs;
    struct sigaction new_action;
    int sigs[] = {SIGHUP, SIGINT, SIGQUIT, SIGBUS, SIGTERM, SIGSEGV, SIGFPE};

    nsigs = sizeof(sigs) / sizeof(int);
    sigemptyset(&mask_sigs);
    for (i = 0; i < nsigs; i++) {
        sigaddset(&mask_sigs, sigs[i]);
    }
    for (i = 0; i < nsigs; i++) {
        new_action.sa_handler = sig_handler;
        new_action.sa_mask = mask_sigs;
        new_action.sa_flags = 0;
        if (sigaction(sigs[i], &new_action, NULL) == -1) {
            perror("can't set signals: ");
            exit(1);
        }
    }

    // Initialize shared memory
    if ((shmid = shmget(MEMKEY, sizeof(struct donut_ring), IPC_CREAT | 0600)) == -1) {
        perror("shared get failed: ");
        exit(1);
    }

    // Attach shared memory
    if ((shared_ring = shmat(shmid, NULL, 0)) == (void *) -1) {
        perror("shared attach failed: ");
        sig_handler(-1);
    }

    while (1) {
        // Generate a random flavor to produce (0 to NUMFLAVORS-1)
        int flavor = rand() % NUMFLAVORS;
        
        // Attempt to acquire a slot in the ring buffer for the selected flavor
        if (p(semid[flavor], PROD) == -1) {
            perror("Producer failed to acquire slot semaphore");
            exit(1);
        }

        // Check if there's room to produce a donut of the selected flavor
        if (shared_ring->outptr[flavor] >= NUMSLOTS) {
    // No room to produce, release the semaphore
    v(semid[flavor], PROD);
} else {
    // Produce a donut of the selected flavor
    int donut = ++serial[flavor];
    shared_ring->flavor[flavor][shared_ring->outptr[flavor]] = donut;
    shared_ring->outptr[flavor]++; // Corrected member name here

    // Release the semaphore to indicate that a donut is available
    v(semid[flavor], PROD);

    // Sleep for a while to simulate the production process
    usleep(100000); // Sleep for 100 milliseconds
}

    }

    pthread_exit(NULL);
}

void *consumer(void *arg) {
    int consumer_id = *((int *)arg); // Unique identifier for this consumer

    while (1) {
        // Generate a random flavor to consume (0 to NUMFLAVORS-1)
        int flavor = rand() % NUMFLAVORS;

        // Attempt to acquire a donut of the selected flavor
        if (p(semid[flavor], CONSUMER) == -1) {
            perror("Consumer failed to acquire donut semaphore");
            exit(1);
        }

        // Check if there's a donut of the selected flavor in the ring buffer
        if (shared_ring->outptr[flavor] >= NUMSLOTS) {
    // No donuts of this flavor available, release the semaphore
    v(semid[flavor], CONSUMER);
} else {
    // Consume the donut
    int donut = shared_ring->flavor[flavor][shared_ring->outptr[flavor]];
    shared_ring->outptr[flavor]++; // Use outptr here

    // Release the semaphore to indicate that one slot is free
    v(semid[flavor], CONSUMER);

    // Process the consumed donut (e.g., print it)
    printf("Consumer %d consumed donut of flavor %d with serial number %d\n", consumer_id, flavor, donut);
}

        // Sleep for a while to simulate the consumption process
        usleep(100000); // Sleep for 100 milliseconds
    }

    pthread_exit(NULL);
}


    
int main() {
    pthread_t producer_thread;
    pthread_t consumer_threads[NUMFLAVORS];

    // Create or get the shared memory and semaphores here.
    // Create shared memory (uncomment this section)
    if ((shmid = shmget(MEMKEY, sizeof(struct donut_ring), IPC_CREAT | 0600)) == -1) {
        perror("shared get failed: ");
        exit(1);
    }

    // Attach shared memory (uncomment this section)
    if ((shared_ring = shmat(shmid, NULL, 0)) == (void *) -1) {
        perror("shared attach failed: ");
        sig_handler(-1);
    }

    // Initialize semaphores
    for (int i = 0; i < NUMFLAVORS; i++) {
    union semun sem_ctl_un;
    sem_ctl_un.val = 1; // Set the initial value of the semaphore to 1
    printf("Initializing semaphore %d\n", i); // Debugging output
    if (semctl(semid[i], i, SETVAL, sem_ctl_un) == -1) {
        // Redirect stdout to the "output.txt" file for writing
    int fd = open("output.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd == -1) {
        perror("open");
        return 1;
    }
    if (dup2(fd, STDOUT_FILENO) == -1) {
        perror("dup2");
        return 1;
    }
    close(fd);

    SharedMemory *shm = get_shared_memory();

    // Initialize random number generator with seed
    srand(time(NULL));

    // Create a producer process
    pid_t producer_pid = fork();
    if (producer_pid == 0) {
        Prod(shm);
        exit(0);
    }

    // Create 5 consumer processes
    for (int i = 0; i < 5; i++) {
        pid_t consumer_pid = fork();
        if (consumer_pid == 0) {
            Cons(shm);
            exit(0);
        }
    }

    int total_dozen_orders = 0;

    // Wait for all child processes to exit
    for (int i = 0; i < 6; i++) {
        // wait(NULL);
        total_dozen_orders++;
        if (total_dozen_orders == 30) {
            // If the desired number of dozens is reached, terminate the program
            break;
        }
    }

    // Free the shared memory
    free_shared_memory(shm);

    // Close the file descriptor
    fclose(stdout);

    // Read and output the contents of the "output.txt" file
    printf("\nContents of the 'output.txt' file:\n");
    readAndOutputFile("output.txt");

        exit(1);
    }
}


    // Create producer thread
    if (pthread_create(&producer_thread, NULL, producer, NULL) != 0) {
        perror("pthread_create failed for producer");
        exit(1);
    }

    // Create consumer threads
    for (int i = 0; i < NUMFLAVORS; i++) {
        if (pthread_create(&consumer_threads[i], NULL, consumer, &i) != 0) {
            perror("pthread_create failed for consumer");
            exit(1);
        }
    }

    // Join consumer threads
    for (int i = 0; i < NUMFLAVORS; i++) {
        pthread_join(consumer_threads[i], NULL);
    }

    return 0;
}