
#include "pro_Os.h"

void Cons(SharedMemory *shm) {
    int dozen = 0;
    while (dozen < 10) {
        // Generate a random donut flavor
        int flavor = rand() % NUM_FLAVORS;

        // Wait for exclusive access to the ring buffer for the specified flavor
        sem_wait(&shm->mutexes[flavor]);

        // Remove a donut from the ring buffer
        int donut = shm->buffers[flavor].donuts[shm->buffers[flavor].out];
        shm->buffers[flavor].out = (shm->buffers[flavor].out + 1) % RING_BUFFER_SIZE;

        // Signal that the ring buffer is now available for producers
        sem_post(&shm->mutexes[flavor]);

        // Print the consumed donut information
        printf("consumer process PID: %d dozen #: %d flavor: %d donut: %d\n",
               getpid(), dozen + 1, flavor, donut);

        dozen++;
    }
}

