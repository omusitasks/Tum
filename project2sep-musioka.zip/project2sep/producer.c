
#include "pro_Os.h"

void Prod(SharedMemory *shm) {
    while (1) {
        // Generate a random donut flavor
        int flavor = rand() % NUM_FLAVORS;

        // Wait for exclusive access to the ring buffer for the specified flavor
        sem_wait(&shm->mutexes[flavor]);

        // Add a donut to the ring buffer
        shm->buffers[flavor].donuts[shm->buffers[flavor].in] = flavor;
        shm->buffers[flavor].in = (shm->buffers[flavor].in + 1) % RING_BUFFER_SIZE;

        // Signal that the ring buffer is now available for consumers
        sem_post(&shm->mutexes[flavor]);
    }
}


