using System;
using System.Windows.Forms;

namespace Program_16
{
    public partial class MainForm : Form
    {
        private OrderManager orderManager;

        public MainForm()
        {
            InitializeComponent();
            InitializePizzaTypeComboBox();
            InitializePizzaChoiceComboBox();
        }

        private void InitializePizzaTypeComboBox()
        {
            pizzaTypeComboBox.DataSource = Enum.GetValues(typeof(CrustAndSize));
        }

        private void InitializePizzaChoiceComboBox()
        {
            pizzaChoiceComboBox.Items.AddRange(new string[]
            {
                "Jalapeno Popper", "Sweet n Spicy", "Krazy Hawaiian",
                "Buffalo Chicken", "Double Pepperoni", "Mile High",
                "South of Border"
            });
        }

        private void AddOrderButton_Click(object sender, EventArgs e)
        {
            if (ValidateInputs())
            {
                if (orderManager == null)
                {
                    orderManager = new OrderManager();
                }

                string customerName = customerNameTextBox.Text;
                string pizzaChoice = pizzaChoiceComboBox.SelectedItem.ToString();
                CrustAndSize pizzaType = (CrustAndSize)pizzaTypeComboBox.SelectedItem;
                int quantity = int.Parse(quantityTextBox.Text);

                orderManager.AddOrder(customerName, pizzaChoice, pizzaType, quantity);
                EnableMenuItems();
                MessageBox.Show("Order added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(customerNameTextBox.Text))
            {
                MessageBox.Show("Customer name is required.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (pizzaChoiceComboBox.SelectedItem == null)
            {
                MessageBox.Show("Please select a pizza choice.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (pizzaTypeComboBox.SelectedItem == null)
            {
                MessageBox.Show("Please select a pizza type.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (!int.TryParse(quantityTextBox.Text, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Quantity must be a positive integer.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void EnableMenuItems()
        {
            allOrdersMenuItem.Enabled = true;
            totalOrderAmountMenuItem.Enabled = true;
            orderCountMenuItem.Enabled = true;
            ordersSummaryMenuItem.Enabled = true;
        }

        private void AllOrdersMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(orderManager?.GetAllOrdersSummary() ?? "No orders found.", "All Orders", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void TotalOrderAmountMenuItem_Click(object sender, EventArgs e)
        {
            string pizzaChoice = pizzaChoiceComboBox.SelectedItem?.ToString();
            if (pizzaChoice == null)
            {
                MessageBox.Show("Please select a pizza choice from the combo box.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            decimal total = orderManager.GetOrderTotalForPizzaChoice(pizzaChoice);
            MessageBox.Show($"Total order amount for {pizzaChoice}: {total:C}", "Order Total", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void OrderCountMenuItem_Click(object sender, EventArgs e)
        {
            CrustAndSize? selectedType = (CrustAndSize?)pizzaTypeComboBox.SelectedItem;
            if (selectedType == null)
            {
                MessageBox.Show("Please select a pizza type from the combo box.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int count = orderManager.GetOrderCountForPizzaType(selectedType.Value);
            MessageBox.Show($"Number of orders for {selectedType}: {count}", "Order Count", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void OrdersSummaryMenuItem_Click(object sender, EventArgs e)
        {
            decimal average = orderManager.GetAverageOrderTotal();
            decimal lowest = orderManager.FindLowestOrderTotal();
            MessageBox.Show($"Average Order Total: {average:C}\nLowest Order Total: {lowest:C}", "Orders Summary", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
