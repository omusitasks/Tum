using System;
using System.Collections.Generic;
using System.Linq;

namespace Program_16
{
    public class OrderManager
    {
        public List<Order> OrderList { get; private set; }

        public OrderManager()
        {
            OrderList = new List<Order>();
        }

        public void AddOrder(string customerName, string pizzaChoice, CrustAndSize pizzaType, int quantity)
        {
            Order newOrder = new Order(customerName, pizzaChoice, pizzaType, quantity);
            OrderList.Add(newOrder);
        }

        public decimal FindLowestOrderTotal()
        {
            return OrderList.Min(order => order.OrderTotal);
        }

        public decimal GetOrderTotalForPizzaChoice(string pizzaChoice)
        {
            return OrderList.Where(order => order.PizzaChoice == pizzaChoice)
                            .Sum(order => order.OrderTotal);
        }

        public decimal GetAverageOrderTotal()
        {
            return OrderList.Count > 0 ? OrderList.Average(order => order.OrderTotal) : 0;
        }

        public int GetOrderCountForPizzaType(CrustAndSize crustAndSize)
        {
            return OrderList.Count(order => order.PizzaType == crustAndSize);
        }

        public string GetAllOrdersSummary()
        {
            if (OrderList.Count == 0)
                return "No orders available.";

            return string.Join("\n", OrderList.Select(order => $"{order.CustomerName} ordered {order.Quantity} x {order.PizzaChoice} ({order.PizzaType}) - Total: {order.OrderTotal:C}"));
        }
    }
}
