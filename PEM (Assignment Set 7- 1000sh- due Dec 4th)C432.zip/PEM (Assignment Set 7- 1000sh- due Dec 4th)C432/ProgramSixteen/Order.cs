using System;

namespace Program_16
{
    public class Order
    {
        public string CustomerName { get; private set; }
        public string PizzaChoice { get; private set; }
        public CrustAndSize PizzaType { get; private set; }
        public int Quantity { get; private set; }
        public decimal OrderTotal { get; private set; }

        public Order(string customerName, string pizzaChoice, CrustAndSize pizzaType, int quantity)
        {
            CustomerName = customerName;
            PizzaChoice = pizzaChoice;
            PizzaType = pizzaType;
            Quantity = quantity;
            OrderTotal = CalculateOrderTotal();
        }

        private decimal CalculateOrderTotal()
        {
            decimal price = PizzaType switch
            {
                CrustAndSize.CrunchyThin10 => 15.99m,
                CrustAndSize.DeepDish11 => 16.89m,
                CrustAndSize.HandTossed12 => 17.79m,
                CrustAndSize.GlutenFree13 => 18.69m,
                CrustAndSize.Italiano14 => 19.59m,
                CrustAndSize.NYStyle15 => 20.49m,
                CrustAndSize.BigKahuna16 => 21.39m,
                _ => 0
            };
            return price * Quantity;
        }
    }
}
