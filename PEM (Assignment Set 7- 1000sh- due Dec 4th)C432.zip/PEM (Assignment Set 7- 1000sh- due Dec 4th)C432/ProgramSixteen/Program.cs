/*
 * Project:         Program_9Conference.Designer.cs
 * Date Created:    October 2024
 * Last Modified:   October 2024
 * Developed By:    Pragnya Thandra
 * Class Name:      Program
 * Description:     Main entry point for the Conference application.
 */



using System;
using System.Windows.Forms;

namespace Program_16
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
