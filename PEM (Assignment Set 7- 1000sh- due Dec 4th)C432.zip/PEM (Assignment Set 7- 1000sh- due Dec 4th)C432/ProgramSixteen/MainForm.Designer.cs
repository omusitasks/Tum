using System.Windows.Forms;

namespace Program_16
{
    partial class MainForm
    {
        private MenuStrip menuStrip;
        private ToolStripMenuItem displayMenu;
        private ToolStripMenuItem allOrdersMenuItem;
        private ToolStripMenuItem totalOrderAmountMenuItem;
        private ToolStripMenuItem orderCountMenuItem;
        private ToolStripMenuItem ordersSummaryMenuItem;
        private ToolStripMenuItem exitMenuItem;
        private ToolStripMenuItem editMenu;
        private ToolStripMenuItem resetForNextOrderMenuItem;
        private ToolStripMenuItem addPizzaChoiceMenuItem;
        private ToolStripMenuItem removePizzaChoiceMenuItem;
        private TextBox customerNameTextBox;
        private ComboBox pizzaChoiceComboBox;
        private ComboBox pizzaTypeComboBox;
        private TextBox quantityTextBox;
        private Button addOrderButton;
        private ContextMenuStrip pizzaChoiceContextMenu;
        private ToolStripMenuItem contextAddPizzaChoiceMenuItem;
        private ToolStripMenuItem contextRemovePizzaChoiceMenuItem;
        private Label customerNameLabel;
        private Label pizzaChoiceLabel;
        private Label pizzaTypeLabel;
        private Label quantityLabel;

        private void InitializeComponent()
        {
            // Initialize components
            menuStrip = new MenuStrip();
            displayMenu = new ToolStripMenuItem("Display");
            allOrdersMenuItem = new ToolStripMenuItem("All Orders");
            totalOrderAmountMenuItem = new ToolStripMenuItem("Total Order Amount for a Pizza Choice");
            orderCountMenuItem = new ToolStripMenuItem("Number of Orders for a Pizza Type");
            ordersSummaryMenuItem = new ToolStripMenuItem("Orders Summary");
            exitMenuItem = new ToolStripMenuItem("Exit");
            editMenu = new ToolStripMenuItem("Edit");
            resetForNextOrderMenuItem = new ToolStripMenuItem("Reset for Next Order");
            addPizzaChoiceMenuItem = new ToolStripMenuItem("Add Pizza Choice");
            removePizzaChoiceMenuItem = new ToolStripMenuItem("Remove Pizza Choice");
            customerNameTextBox = new TextBox();
            pizzaChoiceComboBox = new ComboBox();
            pizzaTypeComboBox = new ComboBox();
            quantityTextBox = new TextBox();
            addOrderButton = new Button();
            pizzaChoiceContextMenu = new ContextMenuStrip();
            contextAddPizzaChoiceMenuItem = new ToolStripMenuItem("Add Pizza Choice");
            contextRemovePizzaChoiceMenuItem = new ToolStripMenuItem("Remove Pizza Choice");
            customerNameLabel = new Label();
            pizzaChoiceLabel = new Label();
            pizzaTypeLabel = new Label();
            quantityLabel = new Label();

            // Configure MenuStrip
            menuStrip.Items.AddRange(new ToolStripItem[] { displayMenu, editMenu });

            // Display Menu
            displayMenu.DropDownItems.AddRange(new ToolStripItem[]
            {
                allOrdersMenuItem,
                totalOrderAmountMenuItem,
                orderCountMenuItem,
                ordersSummaryMenuItem,
                new ToolStripSeparator(),
                exitMenuItem
            });
            allOrdersMenuItem.Enabled = false;
            totalOrderAmountMenuItem.Enabled = false;
            orderCountMenuItem.Enabled = false;
            ordersSummaryMenuItem.Enabled = false;
            exitMenuItem.Click += (sender, e) => Application.Exit();

            // Edit Menu
            editMenu.DropDownItems.AddRange(new ToolStripItem[]
            {
                resetForNextOrderMenuItem,
                new ToolStripSeparator(),
                addPizzaChoiceMenuItem,
                removePizzaChoiceMenuItem
            });
            resetForNextOrderMenuItem.Click += (sender, e) => ResetForNextOrder();

            // Context Menu for Pizza Choice ComboBox
            pizzaChoiceContextMenu.Items.AddRange(new ToolStripItem[]
            {
                contextAddPizzaChoiceMenuItem,
                contextRemovePizzaChoiceMenuItem
            });
            contextAddPizzaChoiceMenuItem.Click += (sender, e) => AddPizzaChoice();
            contextRemovePizzaChoiceMenuItem.Click += (sender, e) => RemovePizzaChoice();
            pizzaChoiceComboBox.ContextMenuStrip = pizzaChoiceContextMenu;

            // Labels
            customerNameLabel.Text = "Customer Name:";
            customerNameLabel.Location = new System.Drawing.Point(20, 40);
            customerNameLabel.AutoSize = true;

            pizzaChoiceLabel.Text = "Pizza Choice:";
            pizzaChoiceLabel.Location = new System.Drawing.Point(20, 80);
            pizzaChoiceLabel.AutoSize = true;

            pizzaTypeLabel.Text = "Pizza Type:";
            pizzaTypeLabel.Location = new System.Drawing.Point(20, 120);
            pizzaTypeLabel.AutoSize = true;

            quantityLabel.Text = "Quantity:";
            quantityLabel.Location = new System.Drawing.Point(20, 160);
            quantityLabel.AutoSize = true;

            // TextBox for Customer Name
            customerNameTextBox.Location = new System.Drawing.Point(150, 40);
            customerNameTextBox.Width = 200;

            // ComboBox for Pizza Choice
            pizzaChoiceComboBox.Location = new System.Drawing.Point(150, 80);
            pizzaChoiceComboBox.Width = 200;
            pizzaChoiceComboBox.DropDownStyle = ComboBoxStyle.DropDown;

            // ComboBox for Pizza Type
            pizzaTypeComboBox.Location = new System.Drawing.Point(150, 120);
            pizzaTypeComboBox.Width = 200;
            pizzaTypeComboBox.DropDownStyle = ComboBoxStyle.DropDownList;

            // TextBox for Quantity
            quantityTextBox.Location = new System.Drawing.Point(150, 160);
            quantityTextBox.Width = 100;

            // Add Order Button
            addOrderButton.Text = "Add Order";
            addOrderButton.Location = new System.Drawing.Point(150, 200);
            addOrderButton.Click += AddOrderButton_Click;

            // Configure Form
            this.Controls.AddRange(new Control[]
            {
                menuStrip,
                customerNameLabel,
                customerNameTextBox,
                pizzaChoiceLabel,
                pizzaChoiceComboBox,
                pizzaTypeLabel,
                pizzaTypeComboBox,
                quantityLabel,
                quantityTextBox,
                addOrderButton
            });

            this.MainMenuStrip = menuStrip;
            this.Text = "Pizza Order Manager";
            this.ClientSize = new System.Drawing.Size(400, 300);

            // Attach event handlers to menu items
            allOrdersMenuItem.Click += AllOrdersMenuItem_Click;
            totalOrderAmountMenuItem.Click += TotalOrderAmountMenuItem_Click;
            orderCountMenuItem.Click += OrderCountMenuItem_Click;
            ordersSummaryMenuItem.Click += OrdersSummaryMenuItem_Click;
        }

        private void ResetForNextOrder()
        {
            customerNameTextBox.Clear();
            pizzaChoiceComboBox.SelectedIndex = -1;
            pizzaTypeComboBox.SelectedIndex = -1;
            quantityTextBox.Clear();
        }

        private void AddPizzaChoice()
        {
            string newChoice = pizzaChoiceComboBox.Text;
            if (!pizzaChoiceComboBox.Items.Contains(newChoice))
            {
                pizzaChoiceComboBox.Items.Add(newChoice);
                MessageBox.Show($"Added new pizza choice: {newChoice}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Pizza choice already exists!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RemovePizzaChoice()
        {
            if (pizzaChoiceComboBox.SelectedItem != null)
            {
                string choiceToRemove = pizzaChoiceComboBox.SelectedItem.ToString();
                pizzaChoiceComboBox.Items.Remove(choiceToRemove);
                MessageBox.Show($"Removed pizza choice: {choiceToRemove}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("No pizza choice selected!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
