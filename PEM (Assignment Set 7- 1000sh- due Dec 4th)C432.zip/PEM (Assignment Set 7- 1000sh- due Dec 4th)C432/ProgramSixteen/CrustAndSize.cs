namespace Program_16
{
    public enum CrustAndSize
    {
        CrunchyThin10,
        DeepDish11,
        HandTossed12,
        GlutenFree13,
        Italiano14,
        NYStyle15,
        BigKahuna16
    }
}
