# A/B Testing Web App

This project implements a simple web application with A/B testing functionality using Flask.

## Features

- Static intro page linking to A/B tested pages.
- Random assignment of users to either version A or B of the home page.
- Session-based "stickiness" to ensure consistent page version.
- Interaction tracking (button clicks) with data stored in memory.

## Setup and Run Instructions

1. **Clone the repository**:
   ```bash
   git clone https://github.com/your-repo/ab_test_app.git
   cd ab_test_app

2. **Set up the MySQL database:**:
   Create a database and table using the database.sql SQL script

3. **Install dependencies**:
   pip install -r requirements.txt

4. **Configure database credentials**:
   Update the db_config dictionary in app.py with your MySQL username, password, and host.

5. **Run the app**:
   python app.py

6. **Access the app**:
   Open a browser and navigate to http://127.0.0.1:5000.

7. **Testing Analytics**:
   Visit the /analytics endpoint to view recorded interactions.