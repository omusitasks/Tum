from flask import Flask, render_template, redirect, session, request, jsonify
import random
import datetime
import mysql.connector

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a secure key in production

# Database connection settings
db_config = {
    'host': 'localhost',
    'user': 'root',  # Replace with your MySQL username
    'password': 'your_password',  # Replace with your MySQL password
    'database': 'ab_test'
}

def get_db_connection():
    """
    Establish and return a MySQL database connection.
    """
    return mysql.connector.connect(**db_config)

@app.route('/')
def intro():
    """
    Static intro page.
    """
    return render_template('intro.html')

@app.route('/home')
def home():
    """
    Route for serving the A/B test pages.
    """
    if 'version' not in session:
        # Randomly assign version A or B
        session['version'] = 'A' if random.random() < 0.5 else 'B'
    
    version = session['version']
    if version == 'A':
        return render_template('home_a.html')
    elif version == 'B':
        return render_template('home_b.html')
    else:
        return render_template('error.html'), 500

@app.route('/track_interaction', methods=['POST'])
def track_interaction():
    """
    Capture button interactions and save them to the database.
    """
    data = request.json
    interaction = {
        'ip_address': request.remote_addr,
        'timestamp': datetime.datetime.now(),
        'page_version': session.get('version', 'Unknown'),
        'button_id': data.get('button_id', 'Unknown')
    }

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO interactions (ip_address, timestamp, page_version, button_id)
            VALUES (%s, %s, %s, %s)
        """, (interaction['ip_address'], interaction['timestamp'], interaction['page_version'], interaction['button_id']))
        conn.commit()
        cursor.close()
        conn.close()
    except Exception as e:
        return jsonify({'message': 'Error saving interaction', 'error': str(e)}), 500

    return jsonify({'message': 'Interaction recorded', 'interaction': interaction}), 200

@app.route('/analytics', methods=['GET'])
def analytics():
    """
    Retrieve and display interaction data from the database.
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM interactions")
        rows = cursor.fetchall()
        cursor.close()
        conn.close()
    except Exception as e:
        return jsonify({'message': 'Error retrieving analytics', 'error': str(e)}), 500

    return jsonify({'interactions': rows})

if __name__ == '__main__':
    app.run(debug=True)
