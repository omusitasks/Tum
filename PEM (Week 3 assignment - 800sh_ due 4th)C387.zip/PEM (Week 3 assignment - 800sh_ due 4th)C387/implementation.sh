#!/bin/bash

# Set up your DynamoDB Table
import boto3

# Initialize a session using DynamoDB
dynamodb = boto3.resource('dynamodb', region_name='your-region')  # e.g., 'us-west-2'

# Create the DynamoDB table
table = dynamodb.create_table(
    TableName='GamingLeaderboard',
    KeySchema=[
        {
            'AttributeName': 'PlayerID',
            'KeyType': 'HASH'  # Partition key
        },
        {
            'AttributeName': 'GameID',
            'KeyType': 'RANGE'  # Sort key
        }
    ],
    AttributeDefinitions=[
        {
            'AttributeName': 'PlayerID',
            'AttributeType': 'S'  # String type
        },
        {
            'AttributeName': 'GameID',
            'AttributeType': 'S'  # String type
        }
    ],
    ProvisionedThroughput={
        'ReadCapacityUnits': 5,
        'WriteCapacityUnits': 5
    }
)

# Wait until the table exists
table.meta.client.get_waiter('table_exists').wait(TableName='GamingLeaderboard')

print("Table status:", table.table_status)




# Insert Data (Put Operation) 
# Insert data into the GamingLeaderboard table

table = dynamodb.Table('GamingLeaderboard')

def put_item(player_id, game_id, score, player_name):
    response = table.put_item(
       Item={
            'PlayerID': player_id,
            'GameID': game_id,
            'Score': score,
            'PlayerName': player_name,
        }
    )
    return response

# Example data
put_item('P001', 'G001', 1500, 'JohnDoe')
put_item('P002', 'G001', 1700, 'JaneDoe')
put_item('P003', 'G001', 2000, 'AliceSmith')

print("Data inserted successfully")





# Retrieve Data (Get Operation)

def get_item(player_id, game_id):
    response = table.get_item(
        Key={
            'PlayerID': player_id,
            'GameID': game_id
        }
    )
    item = response.get('Item')
    return item

# Retrieve John's score for GameID G001
player_data = get_item('P001', 'G001')
print("Player data retrieved:", player_data)





# Delete Data (Delete Operation)

def delete_item(player_id, game_id):
    response = table.delete_item(
        Key={
            'PlayerID': player_id,
            'GameID': game_id
        }
    )
    return response

# Delete Alice's score
delete_item('P003', 'G001')
print("Data deleted successfully")



# Update Data
def update_item(player_id, game_id, new_score):
    response = table.update_item(
        Key={
            'PlayerID': player_id,
            'GameID': game_id
        },
        UpdateExpression='SET Score = :new_score',
        ExpressionAttributeValues={
            ':new_score': new_score
        },
        ReturnValues="UPDATED_NEW"
    )
    return response

# Update John's score to 1800
update_item('P001', 'G001', 1800)
print("Player's score updated successfully")
