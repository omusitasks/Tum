import csv
import random

# Define sample product IDs and review text for Student 2
product_ids = [f'S2P{i:03}' for i in range(1, 21)]  # Create 20 product IDs: S2P001, S2P002, ..., S2P020
ratings = [1, 2, 3, 4, 5]  # Rating from 1 (worst) to 5 (best)
reviews = [
    "Excellent product!", "Not what I expected.", "Great quality.", 
    "Very poor experience.", "I would buy again.", "Absolutely terrible.", 
    "Really enjoyed it!", "Worst experience ever.", "Highly recommend this!", 
    "Completely disappointed.", "Fantastic product!", "Item was defective.", 
    "Works like a charm.", "Not worth the money.", "Incredible performance.", 
    "Quality is lacking.", "Amazing value!", "Poor design.", 
    "Just as described.", "Worst customer service."
]

# Generate mock data for 20 reviews for Student 2
data = []
for i in range(20):
    product_id = random.choice(product_ids)
    rating = random.choice(ratings)
    review = random.choice(reviews)
    data.append([product_id, rating, review])

# Export the data to a CSV file for Student 2
with open('data.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["Product ID", "Rating", "Review Text"])  # Write headers
    writer.writerows(data)

print("Data exported to data.csv")
