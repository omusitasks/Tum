document.getElementById('registrationForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    const fullName = formData.get('fullName');
    const address = formData.get('address');
    const dob = formData.get('dob');
    const password = formData.get('password');
    
    const response = await fetch('/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ fullName, address, dob, password })
    });
    
    const data = await response.json();
    
    if (data.success) {
        swal("Registration Successful!", `User ID: ${data.userId}\nEthereum ID: ${data.ethereumId}`, "success");
    } else {
        swal("Registration Failed!", "Please try again later.", "error");
    }
});
