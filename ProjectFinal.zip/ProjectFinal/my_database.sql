CREATE TABLE users (
    userId VARCHAR(255) PRIMARY KEY,
    fullName VARCHAR(255),
    address VARCHAR(255),
    dob DATE,
    ethereumId VARCHAR(42)
);
