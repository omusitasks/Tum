// server.js
const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const crypto = require('crypto');
const app = express();
const port = 3000;

app.use(bodyParser.json());

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'password',
    database: 'my_database'
});

connection.connect(err => {
    if (err) {
        console.error('Error connecting to database: ', err);
        return;
    }
    console.log('Connected to MySQL database');
});

app.post('/register', (req, res) => {
    const { fullName, address, dob, password } = req.body;
    const userId = crypto.randomBytes(8).toString('hex');
    const ethereumId = crypto.randomBytes(21).toString('hex');

    const sql = `INSERT INTO users (userId, fullName, address, dob, ethereumId) VALUES (?, ?, ?, ?, ?)`;
    connection.query(sql, [userId, fullName, address, dob, ethereumId], (err, result) => {
        if (err) {
            console.error('Error registering user: ', err);
            res.json({ success: false });
            return;
        }
        res.json({ success: true, userId, ethereumId });
    });
});

app.post('/login', (req, res) => {
    const { userId, ethereumId } = req.body;
    const sql = `SELECT * FROM users WHERE userId = ? AND ethereumId = ?`;
    connection.query(sql, [userId, ethereumId], (err, result) => {
        if (err) {
            console.error('Error logging in: ', err);
            res.json({ success: false });
            return;
        }
        if (result.length > 0) {
            res.json({ success: true });
        } else {
            res.json({ success: false });
        }
    });
});

app.listen(port, () => {
    console.log(`Server is listening at http://localhost:${port}`);
});
