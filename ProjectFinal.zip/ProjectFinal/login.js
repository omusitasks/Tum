document.getElementById('loginForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    const userId = formData.get('userId');
    const ethereumId = formData.get('ethereumId');
    
    const response = await fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ userId, ethereumId })
    });
    
    const data = await response.json();
    
    if (data.success) {
        swal("Login Successful!", "You are now logged in.", "success");
    } else {
        swal("Login Failed!", "Please check your User ID or Ethereum ID and try again.", "error");
    }
});
