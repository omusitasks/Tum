#!/bin/bash

# Create PlayerLeaderboard table
aws dynamodb create-table \
    --table-name PlayerLeaderboard \
    --attribute-definitions \
        AttributeName=playerID,AttributeType=S \
        AttributeName=score,AttributeType=N \
    --key-schema \
        AttributeName=playerID,KeyType=HASH \
        AttributeName=score,KeyType=RANGE \
    --provisioned-throughput \
        ReadCapacityUnits=5,WriteCapacityUnits=5



# Insert player data into PlayerLeaderboard table
aws dynamodb put-item \
    --table-name PlayerLeaderboard \
    --item '{
        "playerID": {"S": "P001"},
        "name": {"S": "John Doe"},
        "score": {"N": "1200"},
        "rank": {"N": "1"}
    }'




# Retrieve player data by playerID
aws dynamodb get-item \
    --table-name PlayerLeaderboard \
    --key '{
        "playerID": {"S": "P001"},
        "score": {"N": "1200"}
    }'



# Delete player from PlayerLeaderboard table
aws dynamodb delete-item \
    --table-name PlayerLeaderboard \
    --key '{
        "playerID": {"S": "P001"},
        "score": {"N": "1200"}
    }'




# Update player score and rank
aws dynamodb update-item \
    --table-name PlayerLeaderboard \
    --key '{
        "playerID": {"S": "P001"},
        "score": {"N": "1200"}
    }' \
    --update-expression "SET score = :newScore, rank = :newRank" \
    --expression-attribute-values '{
        ":newScore": {"N": "1300"},
        ":newRank": {"N": "1"}
    }'
