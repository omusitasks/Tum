# Feature Prioritization for Trello Using the KANO Model

## Project Overview
This project focuses on prioritizing features for Trello using the KANO Model, based on customer feedback. The goal is to enhance user satisfaction by categorizing and addressing user needs effectively.

## Repository Structure
- **Feedback_Analysis**: Contains the feedback questions and summarized insights.
- **Prioritization_Model**: Includes the KANO Model table and analysis report.
- **Presentation**: PowerPoint presentation with detailed speaker notes.
- **References**: APA citations and references for the project.

## How to Use
1. Review the `Feedback_Analysis` folder for feedback insights.
2. Open the `Prioritization_Model` folder for the KANO Model table and analysis.
3. Access the `Presentation` folder for the final presentation slides and speaker notes.

## Tools and Techniques
- **Prioritization Framework**: KANO Model.
- **Tool Analyzed**: Trello.
- **Feedback Analysis**: Based on hypothetical customer insights.
