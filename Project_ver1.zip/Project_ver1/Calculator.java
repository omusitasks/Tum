// Calculator.java
import java.util.List;  // Add this import statement

public class Calculator {
    public static int evaluateExpression(String expression) {
        Tokenizer tokenizer = new Tokenizer(expression);
        List<Token> tokens = tokenizer.tokenize();
        Parser parser = new Parser(tokens);
        ParseTreeNode root = parser.parseExpression();
        return root.evaluate();
    }

    public static void main(String[] args) {
        String expression = "3 * (2 + 5) - 4 / 2";
        int result = evaluateExpression(expression);
        System.out.println("Result: " + result);
    }
}
