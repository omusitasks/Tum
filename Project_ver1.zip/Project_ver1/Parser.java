// // Parser.java
// import java.util.List;

// public class Parser {
//     private List<Token> tokens;
//     private int currentTokenIndex = 0;

//     public Parser(List<Token> tokens) {
//         this.tokens = tokens;
//     }

//     public ParseTreeNode parseExpression() {
//         return parseAdditionSubtraction();
//     }

//     private ParseTreeNode parseAdditionSubtraction() {
//         ParseTreeNode left = parseMultiplicationDivision();
//         while (match(TokenType.OPERATOR, "+") || match(TokenType.OPERATOR, "-")) {
//             char operator = tokens.get(currentTokenIndex - 1).getValue().charAt(0);
//             ParseTreeNode right = parseMultiplicationDivision();
//             left = new BinaryOperatorNode(operator, left, right);
//         }
//         return left;
//     }

//     private ParseTreeNode parseMultiplicationDivision() {
//         ParseTreeNode left = parsePrimary();
//         while (match(TokenType.OPERATOR, "*") || match(TokenType.OPERATOR, "/")) {
//             char operator = tokens.get(currentTokenIndex - 1).getValue().charAt(0);
//             ParseTreeNode right = parsePrimary();
//             left = new BinaryOperatorNode(operator, left, right);
//         }
//         return left;
//     }

//     private ParseTreeNode parsePrimary() {
//         if (match(TokenType.NUMBER)) {
//             return new NumberNode(Integer.parseInt(tokens.get(currentTokenIndex - 1).getValue()));
//         } else if (match(TokenType.OPERATOR, "-")) {
//             ParseTreeNode operand = parsePrimary();
//             return new UnaryOperatorNode('-', operand);
//         } else if (match(TokenType.LEFT_PAREN)) {
//             ParseTreeNode expression = parseAdditionSubtraction();
//             if (!match(TokenType.RIGHT_PAREN)) {
//                 throw new IllegalArgumentException("Missing closing parenthesis");
//             }
//             return expression;
//         } else {
//             throw new IllegalArgumentException("Invalid expression");
//         }
//     }

//     private boolean match(TokenType type) {
//         return match(type, null);
//     }

//     private boolean match(TokenType type, String value) {
//         if (currentTokenIndex < tokens.size()) {
//             Token token = tokens.get(currentTokenIndex);
//             if (token.getType() == type && (value == null || token.getValue().equals(value))) {
//                 currentTokenIndex++;
//                 return true;
//             }
//         }
//         return false;
//     }
// }



// Parser.java
import java.util.List;

public class Parser {
    private List<Token> tokens;
    private int currentTokenIndex = 0;

    public Parser(List<Token> tokens) {
        this.tokens = tokens;
    }

    public ParseTreeNode parseExpression() {
        ParseTreeNode result = parseAdditionSubtraction();
        if (match(TokenType.EOF)) {
            return result; // Expression parsed successfully
        } else {
            throw new IllegalArgumentException("Invalid expression");
        }
    }

    private ParseTreeNode parseAdditionSubtraction() {
        ParseTreeNode left = parseMultiplicationDivision();
        while (match(TokenType.OPERATOR, "+") || match(TokenType.OPERATOR, "-")) {
            char operator = tokens.get(currentTokenIndex - 1).getValue().charAt(0);
            ParseTreeNode right = parseMultiplicationDivision();
            left = new BinaryOperatorNode(operator, left, right);
        }
        return left;
    }

    private ParseTreeNode parseMultiplicationDivision() {
        ParseTreeNode left = parsePrimary();
        while (match(TokenType.OPERATOR, "*") || match(TokenType.OPERATOR, "/")) {
            char operator = tokens.get(currentTokenIndex - 1).getValue().charAt(0);
            ParseTreeNode right = parsePrimary();
            left = new BinaryOperatorNode(operator, left, right);
        }
        return left;
    }

    private ParseTreeNode parsePrimary() {
        if (match(TokenType.NUMBER)) {
            return new NumberNode(Integer.parseInt(tokens.get(currentTokenIndex - 1).getValue()));
        } else if (match(TokenType.OPERATOR, "-")) {
            ParseTreeNode operand = parsePrimary();
            return new UnaryOperatorNode('-', operand);
        } else if (match(TokenType.LEFT_PAREN)) {
            ParseTreeNode expression = parseAdditionSubtraction();
            if (match(TokenType.RIGHT_PAREN)) {
                return expression;
            } else {
                throw new IllegalArgumentException("Missing closing parenthesis");
            }
        } else {
            throw new IllegalArgumentException("Invalid expression");
        }
    }

    private boolean match(TokenType type) {
        return match(type, null);
    }

    private boolean match(TokenType type, String value) {
        if (currentTokenIndex < tokens.size()) {
            Token token = tokens.get(currentTokenIndex);
            if (token.getType() == type && (value == null || token.getValue().equals(value))) {
                currentTokenIndex++;
                return true;
            }
        }
        return false;
    }
}
