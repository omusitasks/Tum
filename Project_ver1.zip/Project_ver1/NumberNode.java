// NumberNode.java
public class NumberNode implements ParseTreeNode {
    private int value;

    public NumberNode(int value) {
        this.value = value;
    }

    @Override
    public int evaluate() {
        return value;
    }
}
