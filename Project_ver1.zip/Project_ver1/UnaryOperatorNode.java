// UnaryOperatorNode.java
public class UnaryOperatorNode implements ParseTreeNode {
    private char operator;
    private ParseTreeNode operand;

    public UnaryOperatorNode(char operator, ParseTreeNode operand) {
        this.operator = operator;
        this.operand = operand;
    }

    @Override
    public int evaluate() {
        int operandValue = operand.evaluate();

        if (operator == '-') {
            return -operandValue;
        }

        throw new IllegalArgumentException("Invalid operator: " + operator);
    }
}

