// Tokenizer.java
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Tokenizer {
    private String input;
    private int position = 0;

    public Tokenizer(String input) {
        this.input = input;
    }

    public List<Token> tokenize() {
        List<Token> tokens = new ArrayList<>();

        Pattern pattern = Pattern.compile("\\d+|[-+*/()]");
        Matcher matcher = pattern.matcher(input);

        while (matcher.find()) {
            String match = matcher.group();
            if (match.matches("\\d+")) {
                tokens.add(new Token(TokenType.NUMBER, match));
            } else {
                tokens.add(new Token(TokenType.OPERATOR, match));
            }
        }

        tokens.add(new Token(TokenType.EOF, ""));
        return tokens;
    }
}
