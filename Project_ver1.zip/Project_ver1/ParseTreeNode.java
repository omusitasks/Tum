// ParseTreeNode.java
public interface ParseTreeNode {
    int evaluate();
}
