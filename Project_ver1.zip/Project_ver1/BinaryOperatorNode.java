// BinaryOperatorNode.java
public class BinaryOperatorNode implements ParseTreeNode {
    private char operator;
    private ParseTreeNode left;
    private ParseTreeNode right;

    public BinaryOperatorNode(char operator, ParseTreeNode left, ParseTreeNode right) {
        this.operator = operator;
        this.left = left;
        this.right = right;
    }

    @Override
    public int evaluate() {
        int leftValue = left.evaluate();
        int rightValue = right.evaluate();

        switch (operator) {
            case '+':
                return leftValue + rightValue;
            case '-':
                return leftValue - rightValue;
            case '*':
                return leftValue * rightValue;
            case '/':
                if (rightValue == 0) {
                    throw new ArithmeticException("Division by zero");
                }
                return leftValue / rightValue;
            default:
                throw new IllegalArgumentException("Invalid operator: " + operator);
        }
    }
}
