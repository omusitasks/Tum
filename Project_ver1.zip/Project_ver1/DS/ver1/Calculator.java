public class Calculator {
    public static int evaluateExpression(String expression) throws LexicalError {
        LexicalAnalyzer lex = new LexicalAnalyzer(expression);
        Token tok = lex.getToken();
        // Add code to parse and evaluate the expression
        return 0; // Replace with the actual result
    }

    public static void main(String[] args) {
        String expression = "3 * (2 + 5) - 4 / 2";
        try {
            int result = evaluateExpression(expression);
            System.out.println("Result: " + result);
        } catch (LexicalError e) {
            System.err.println(e.getMessage());
        }
    }
}
