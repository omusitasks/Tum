
// public class LexicalAnalyzer 
// {

//  // instance fields

// // constructor


// 	/**
// 	 * @return next toxen - EOS token if no more tokens exist
// 	 * @throws LexicalError if any error occurs when determining the next token
// 	 */
// 	public Token getToken() throws LexicalError
// 	{
// 		// need to write this
// 	}


import java.util.ArrayList;
import java.util.List;

public class LexicalAnalyzer {
    private String input;
    private int position;

    public LexicalAnalyzer(String input) {
        this.input = input;
        this.position = 0;
    }

    public Token getToken() throws LexicalError {
        if (position >= input.length()) {
            return new Token(TokenType.EOS, "", 0, 0);
        }

        char currentChar = input.charAt(position);
        int lineNum = 1; // You may need to maintain line and column numbers

        if (Character.isDigit(currentChar)) {
            StringBuilder lexeme = new StringBuilder();
            while (position < input.length() && Character.isDigit(currentChar)) {
                lexeme.append(currentChar);
                position++;
                if (position < input.length()) {
                    currentChar = input.charAt(position);
                }
            }
            return new Token(TokenType.INT_LIT, lexeme.toString(), lineNum, position);
        } else if (currentChar == '+') {
            position++;
            return new Token(TokenType.ADD, "+", lineNum, position);
        } else if (currentChar == '-') {
            position++;
            return new Token(TokenType.SUB, "-", lineNum, position);
        } else if (currentChar == '*') {
            position++;
            return new Token(TokenType.MUL, "*", lineNum, position);
        } else if (currentChar == '/') {
            position++;
            return new Token(TokenType.DIV, "/", lineNum, position);
        } else if (currentChar == '(') {
            position++;
            return new Token(TokenType.L_PAREN, "(", lineNum, position);
        } else if (currentChar == ')') {
            position++;
            return new Token(TokenType.R_PAREN, ")", lineNum, position);
        } else if (currentChar == ' ') {
            position++; // Skip spaces
            return getToken(); // Get the next token
        } else {
            throw new LexicalError("Invalid character: " + currentChar + " at line " + lineNum + ", position " + position);
        }
    }
}
