public class Token
{

	/**
	 * token type of token
	 */
	private TokenType tokType;
	
	/**
	 * lexeme for token
	 */
	private String lexeme;
	
	/**
	 * line number where lexeme occurs
	 */
	private int lineNum;
	
	/**
	 * column number where lexeme occurs
	 */
	private int colNum;

	/**
	 * @param tokType type of token
	 * @param lexeme - lexeme for token
	 * @param lineNum - line number where token occurred - must be positive
	 * @param colNum - column number where token occurred - must be positive
	 * @throws LexicalError if lineNum or colNum argument is invalid
	 */
	public Token(TokenType tokType, String lexeme, int lineNum, int colNum) throws LexicalError
	{
		this.tokType = tokType;
		this.lexeme = lexeme;
		if (lineNum <= 0)
			throw new LexicalError ("invalid line number argument in token constructor");
		this.lineNum = lineNum;
		this.colNum = colNum;
	}

	public TokenType getTokType()
	{
		return tokType;
	}

	public String getLexeme()
	{
		return lexeme;
	}

	public int getLineNum()
	{
		return lineNum;
	}

	public int getColNum()
	{
		return colNum;
	}

	@Override
	public String toString()
	{
		return tokType + " " + lexeme + " row: " + lineNum + " col: " + colNum;
	}
		
	
}
