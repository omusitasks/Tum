public class LexicalError extends Exception
{

	/**
	 * @param message error message to be displayed
	 */
	public LexicalError(String message)
	{
		super(message);
	}

}
