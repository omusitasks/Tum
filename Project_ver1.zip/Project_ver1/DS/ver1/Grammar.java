/**
 * tokens in calculator grammar
 */
enum TokenType
{
	ADD, SUB, MUL, DIV, L_PAREN, R_PAREN, INT_LIT, EOS
}
