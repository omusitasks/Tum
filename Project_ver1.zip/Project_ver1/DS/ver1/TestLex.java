// import java.io.IOException;
// import java.util.Scanner;
// import java.io.File;
// import java.io.FileNotFoundException;

// public class TestLex
// {

// 	public static void main(String[] args)
// 	{
// 		try
// 		{
// 			if (args.length != 1)
// 				throw new IOException("file name command line argument expected");
// 			String code = getCode(args[0]);
// 			LexicalAnalyzer lex = new LexicalAnalyzer(code);
// 			Token tok = lex.getToken();
// 			while (tok.getTokType() != TokenType.EOS)
// 			{
// 				System.out.println (tok);
// 				tok = lex.getToken();
// 			}
// 		} 
// 		catch (FileNotFoundException e)
// 		{
// 			System.err.println(e.getMessage());
// 		}
// 		catch (IOException e)
// 		{
// 			System.err.println (e.getMessage());
// 		}
// 		catch (LexicalError e)
// 		{
// 			System.err.println (e.getMessage());
// 		}
// 		catch (Exception e)
// 		{
// 			System.err.println ("unknown error occurred - program terminating");
// 		}
// 	}

// 	/**
// 	 * @param fileName is the name of the file containing the arithmetic expression 
// 	 * arithmetic expression is on one line
// 	 * @return contents of the line in the file
// 	 * @throws FileNotFoundException if fileName cannot be found
// 	 */
// 	private static String getCode(String fileName) throws FileNotFoundException
// 	{
// 		// need to write this code
// 	}

// }


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class TestLex {
    public static void main(String[] args) {
        try {
            if (args.length != 1) {
                throw new IOException("File name command line argument expected");
            }
            String fileName = args[0];
            String expression = getCode(fileName);
            LexicalAnalyzer lex = new LexicalAnalyzer(expression);
            Token tok = lex.getToken();
            while (tok.getTokType() != TokenType.EOS) {
                System.out.println(tok);
                tok = lex.getToken();
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        } catch (LexicalError e) {
            System.err.println(e.getMessage());
        }
    }

    private static String getCode(String fileName) throws IOException {
        StringBuilder code = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                code.append(line).append("\n");
            }
        }
        return code.toString();
    }
}

