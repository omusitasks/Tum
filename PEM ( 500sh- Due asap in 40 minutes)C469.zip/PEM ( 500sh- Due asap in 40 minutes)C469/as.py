# import pandas as pd
# import numpy as np
# from scipy.stats import pearsonr

# def cronbach_alpha(df):
#     """Compute Cronbach's Alpha for internal consistency."""
#     items = df.shape[1]
#     variances = df.var(axis=0, ddof=1)
#     total_variance = df.sum(axis=1).var(ddof=1)
#     alpha = (items / (items - 1)) * (1 - variances.sum() / total_variance)
#     return alpha

# # Sample Data (Replace with actual dataset)
# data = {
#     "Q01": [4, 5],
#     "Q06": [4, 4],
#     "Q11": [5, 4],
#     "Q16": [3, 3],
#     "Q21": [4, 2]
# }

# # Convert to DataFrame
# df = pd.DataFrame(data)

# # Compute Cronbach's Alpha
# alpha_value = cronbach_alpha(df)

# # JASP-style output
# print("=== Reliability Statistics ===")
# print(f"Cronbach’s Alpha: {alpha_value:.3f}")
# print(f"Number of Items: {df.shape[1]}")

# # Interpretation (APA Style)
# if alpha_value >= 0.9:
#     interpretation = "Excellent internal consistency."
# elif alpha_value >= 0.8:
#     interpretation = "Good internal consistency."
# elif alpha_value >= 0.7:
#     interpretation = "Acceptable internal consistency."
# elif alpha_value >= 0.6:
#     interpretation = "Questionable internal consistency."
# else:
#     interpretation = "Poor internal consistency."

# print("\n=== Interpretation ===")
# print(f"The Cronbach's Alpha for the 'Statistics makes me cry' subscale is {alpha_value:.3f}, indicating {interpretation}.")



import pandas as pd

def cronbach_alpha(df):
    """Compute Cronbach's Alpha for internal consistency."""
    items = df.shape[1]
    variances = df.var(axis=0, ddof=1)
    total_variance = df.sum(axis=1).var(ddof=1)
    alpha = (items / (items - 1)) * (1 - variances.sum() / total_variance)
    return alpha

# Load dataset from CSV file
file_path = "Anxiety_Questionnaire.csv"  # Update with correct path if needed
df = pd.read_csv(file_path)

# Compute Cronbach's Alpha
alpha_value = cronbach_alpha(df)

# Get actual number of observations
num_observations = df.shape[0]

# Generate formatted output
bold_line = "==================================="  # Bold-style separator

print(f"\033[1m{bold_line}\033[0m\n")  # First bold break line
print("\033[1mResults\033[0m\n")  # Bold "Results"
print("\033[1mReliability Analysis\033[0m\n")  # Bold "Reliability Analysis"
print("Scale Reliability Statistics")
print("___________________________________")
print(f"{'':<20} Cronbach’s α")
print("___________________________________\n")
print(f"{'scale':<25} {alpha_value:.3f}")
print("___________________________________\n")
print(f"Note. Of the observations, {num_observations} were\n"
      f"used, 0 were excluded listwise, and\n"
      f"{num_observations} were provided.\n")
print(f"\033[1m{bold_line}\033[0m")  # Last bold break line
